---
name: "inu-print-annual"
description: "INU 지면 패밀리 · 성과보고서형 — 큰 숫자·하이라이트·타임라인으로 한 해나 사업 성과를 보여 주는 A4 매거진형 성과집(HTML·PDF). '성과보고서형', '성과 하이라이트', '연차보고서', '성과집' 요청에 사용."
---

# INU 성과보고서형 (INU 지면 패밀리)

한 해 또는 한 사업의 성과를 **매거진형 성과집**으로 만든다. A4 세로, 큰 숫자·섹션 번호·하이라이트 카드·타임라인으로 "무엇을 이뤤는지"를 한눈에 보여 준다. 연간 성과 하이라이트, 사업 성과집, 연말 실적 정리, 대외 소개용 성과 자료에 쓴다. 지면형 보고서(inu-print-report)와 같은 바탕을 쓴다.

시작점: 2026. 10. 「산학협력 성과 하이라이트 2026」(템플릿 = 그 실제 문서, 6쪽).

산출물: 완성 HTML, 같은 HTML을 A4로 인쇄한 PDF.

## 쪽 구성 (보통 6쪽)

1. **표지**(`.sheet.ar.cov`)
   - 네이비 면(`.nv`): 종이 끝에서 6mm 안쪽, 아래 66mm는 흰 영역(`inset:6mm 6mm 66mm 6mm`). 네이비 면은 `overflow:hidden`.
   - 흰 로고 + 팀명, 오른쪽 위 `ANNUAL HIGHLIGHTS` + 기간.
   - 거대한 연도 숫자(168pt, 골드 외곽선만): 장식이라 `data-bleed`를 달고 네이비 면 안에서 잘려도 된다.
   - pill + 제목 2줄(36pt) + 부제(하이라이트 이름을 '·'로 나열), 골드 꺾쇠 두 개.
   - 아래 흰 영역: 대표 숫자 3칸(`.trio`) + 발행일·팀명.
2. **숫자로 보는 ○○**: 섹션 번호는 연도 뒤 두 자리('26'). 리드 1문단, 숫자 타일 8개(4×2, 칸 높이 46mm 고정, 대표 하나 `.hero` 네이비, 강조 `.g` 골드 선, 위에 영문 분류 라벨), 아래 흐름 카드 4개(`.flows`: 번호·제목·한 줄·작은 목록 3개·쪽 링크).
3. **하이라이트 쪽 01~03**: `.sx` 큰 골드 번호 + `HIGHLIGHT 0N` + 제목(23pt), 리드 1문단, 블록 2~3개.
4. **다음 걸음(NEXT STEPS)**: 로드맵 행(`.rd`) 5개 내외 + 마무리 바(`.close`: 흰 로고, 팀명, 연락처) + `— 끝 —`.

- 꼬리말: 섹션 영문 이름 + 쪽 번호(예: `HIGHLIGHT 01 - 3 -`). 머리말은 패밀리 공통.
- 흐름 카드의 쪽 링크는 `a.lk href="#s1"`, 각 하이라이트 `section`에 `id="s1"`.

## 블록 라이브러리 (템플릿에 들어 있는 것)

| 블록 | 클래스 | 쓰는 곳 |
|---|---|---|
| 숫자 타일 | `.nums` | 8개 핵심 숫자, 큰 숫자는 아래쪽에 붙임(`margin-top:auto`) |
| 흐름 카드 | `.flows` | 숫자 쪽 아래, 섹션 안내와 쪽 링크 |
| 구성 막대 | `.bar` + `.scale` | 전체 중 구성(폭 %는 실제 비율) |
| 가로 타임라인 | `.tl` | 기간 안의 일정. 아래 월 띠 `.months`, 오늘 선 `.today`, 위쪽 이벤트 `.ev.up`(골드 계열 `.gold`), 아래쪽 이벤트 `.ev.dn`(네이비), 지난 일정 `.past`(채운 점). 양 끝 이벤트는 `.l2`(왼쪽 기준)·`.r`(오른쪽 기준)로 종이 안쪽에 맞춤 |
| 카드 2칸 | `.cards2` + `.cd` | 대표 프로그램·기반 확충 등. `dl` 또는 `ul.l`, 아래 골드 강조 한 줄 `.hl` |
| 세로 연혁 + 옆 칸 | `.net` = `.vt` + `.side` | 협력 일정. 중요한 일정 `.key`(골드 점·태그), 옆 칸 큰 숫자 `.big8` + 분류 `.grp` |
| 도구·서비스 카드 6칸 | `.tools` + `.tool` | 단순 선 아이콘(SVG 24 viewBox, 선 2) + 제목 + 설명 + 작은 목록 + 아래 숫자 `.fact`. 대표 하나 `.hero` |
| 띠 | `.news` | 뉴스레터처럼 구성 요소 4개를 한 줄로 |
| 로드맵 행 | `.rd` | 번호 칸 + 제목·설명 + 오른쪽 STATUS. 첫 행 `.g` 골드 |
| 마무리 바 | `.close` | 마지막 쪽 흰 로고·팀명·연락처 |

## 성과 표현 규칙

- 성과 수치는 원문에 있는 것만 쓴다. 예정·예상치는 '예상', '예정'을 붙인다('연간 319명 예상').
- 진행 중인 일은 상태를 정확히 쓴다: '추진', '검토', '예정', '완료'. 계획을 성과처럼 쓰지 않는다.
- 리드 문단(10.6pt)은 큰 글씨라 왼쪽 정렬로 둔다(양쪽 정렬하면 띄어쓰기가 벌어져 보인다).
- 협약 표현은 사실대로: 이미 체결한 협약의 후속 방문을 '재체결'처럼 쓰지 않는다.

## 쪽 맞추기

- 본문 쪽 채움 85% 이상(검사).
- **넘치면:** 카드 안 목록을 줄이거나 아이콘·제목 크기를 한 단계 줄인다.
- **비면:** 카드 안에 원고에서 나온 세부 목록을 더하거나(도구 카드의 작은 목록처럼), 숫자·아이콘·행 높이를 키운다. 그리드 칸이 늘어나 휑해지면 칸 높이를 고정(`grid-auto-rows`)하고 남는 높이를 아래 블록에 준다.

## 어떤 스킬을 쓸까 (INU 지면 패밀리)

같은 바탕(네이비 색, 서체, 로고, 머리말, 어절 줄바꿈, 출력 여백)을 쓰는 형제 스킬이 넷이다. 사용자는 스킬 이름을 외우지 않아도 된다. "팩트시트로", "컨설팅형으로", "성과보고서형으로"라고 하거나 용도만 말해도 아래 표로 고른다. 두 가지 이상이 맞을 만큼 애매하면 한 줄로 묻는다.

| 사용자가 원하는 것 | 스킬 | 판형 |
|---|---|---|
| 결재용 장문 보고서(Ⅰ~Ⅵ장 구조, 결과·출장·간담회 보고) | inu-print-report (지면형 보고서) | A4 세로, 여러 쪽 |
| 교육·사업·행사를 한 장에 담은 안내·배포물 | inu-print-factsheet (팩트시트) | A4 세로 1장 |
| 결정을 받아야 하는 검토·건의 보고(단장님·부총장 보고 등) | inu-print-consult (컨설팅형) | A4 가로, 5~8쪽 |
| 한 해 또는 한 사업의 성과를 보여 주는 성과집 | inu-print-annual (성과보고서형) | A4 세로, 6쪽 내외 |
| 워드(.docx) 파일이 꼭 필요할 때 | inu-report-master | DOCX |
| 3단 접지 홍보 브로셔(펼친 크기 360×240mm) | 이 패밀리 범위 밖 — 면 배치가 다르므로 디자인 요소만 빌려 쓴다 | — |

## 패밀리 공통 규칙

### 출력 여백 [필수] (사용자 결정, 2026. 10. 22.)
- 사무실 프린터는 종이 가장자리 4~5mm를 찍지 못한다. 색 면을 종이 끝까지 채우면 그 부분이 잘려 흰 테두리가 생긴다. 특히 세로로 선 덩어리 면은 종이 위에 놓인 "세로로 긴 사각형 박스"처럼 출력된다(컨설팅형 표지를 사용자가 실제로 출력해 발견).
- 그래서 배경색·그라데이션이 있는 모든 요소는 **종이 끝에서 6mm 안쪽**에 둔다. 화면에서도 처음부터 흰 여백이 고르게 보이므로 화면과 출력 모양이 같다.
- 글자도 종이 끝 5mm 안쪽에만 둔다. 예외: 색 면 안에서 잘리도록 둔 장식 글자(성과보고서형 표지의 큰 연도)는 `data-bleed`를 단다.
- `check2.py`가 둘 다 검사한다(5mm 기준이라 6mm로 두면 1mm 여유).
- 참고: 지면형 보고서(inu-print-report) 표지의 위쪽 가로 띠도 종이 끝에 닿지만, 가로 띠는 출력해도 머리 띠로 읽혀 자연스러우므로 그 스킬은 그대로 둔다.

### 표기 규칙 (지면형 보고서와 같음 — 반드시 지킴)
- **개조식 명사형 종결, 끝 마침표 없음:** 목록·카드·주석·제목 모두 '~함', '~발표', '~필요', '~추진'으로 끝낸다. 한 항목 안에서 문장이 둘로 나뉠 때만 중간 마침표를 쓴다.
- **따옴표:** 굽은 따옴표 ‘ ’ “ ”를 쓴다. 문서·행사·법령·사업 이름은 「 」로 감싼다.
- **날짜:** 공문서식 '2026. 10. 14.(수)'(점 뒤 띄움). 기간은 '2026. 1.~6.'.
- **단위:** 숫자와 단위를 붙인다('19개사', '46명'). 큰 숫자는 천 단위 쉼표('1,534').
- **'평생교육' 금지:** 재직자 계속교육, 직무역량 강화, 기업 맞춤형 인력양성 등으로 바꾼다(고칠 수 없는 원문 인용만 예외).
- **로고:** 모든 산출물에 넣는다. 밝은 바탕은 네이비 로고, 어두운 바탕은 흰 글자 + 골드 심볼(build2.py가 만들어 넣음).
- 동그라미 숫자(①②③)를 제목·목록 머리에 쓰지 않는다. 번호가 필요하면 네모 칸 숫자나 '01'처럼 쓴다.

### 조판 규칙 (fit.js·build2.py에 구현 — 끄지 말 것)
- **줄바꿈:** 어절 단위(`word-break:keep-all`) + `line-break:strict`(쉼표·닫는 괄호·가운뎃점이 줄 첫머리에 오지 않음).
- **build2.py 줄바꿈 보조:** '간담회(제5차)'처럼 괄호 붙은 말은 한 단어로 묶고, 가운뎃점은 앞에 붙이고 뒤에서만 줄바꿈을 허용하며, '2-1' 같은 숫자 번호는 줄에서 떼지 않는다.
- **마지막 줄 한 단어 금지:** 자간을 최대 -0.03em 줄여 끌어올리고, 안 되면 마지막 두 단어를 붙여 함께 내린다. 대상은 `p, li, td, td>div, dd, .fx`. 일부러 빼려면 `data-nowidow`.
- **띄어쓰기 고르기:** 양쪽 정렬 문단의 띄어쓰기가 0.55em보다 넓게 벌어지면 자간을 -0.045~+0.03em 안에서 다시 고른다. 10.5pt 이상 큰 글씨, 좁은 칸, 카드 안 설명은 양쪽 정렬 대신 왼쪽 정렬로 둔다(벌어짐 방지).
- **한 줄 제목:** `h2`와 `data-oneline` 요소는 자간을 최대 -0.04em까지 줄여 한 줄로 맞춘다. 그래도 넘치면 문구를 줄인다.
- **줄 판정:** 높이 차이가 글자 크기의 60%를 넘을 때만 줄이 바뀐 것으로 본다(큰 숫자 옆 작은 단위 글자 때문에 줄이 바뀐 것으로 잘못 보지 않게).
- **글자:** 기본 자간 -0.02em. 서체는 Noto Sans KR(웹 폰트), 안 되면 설치된 Noto Sans CJK KR·맑은 고딕.
- **표:** 머리 #D9E2F3 + 네이비 위 선, 짝수 행 #F2F2F2, 첫 열 `td.h`, 숫자 열 `td.c`, 합계 `tr.sum`. 한 칸 안 여러 줄은 `<div>`로 한 줄씩 쓰고 글머리 기호(•)는 쓰지 않는다.
- **종이:** 늘 흰색이고 종이 뒤 배경만 다크 모드를 따른다. 화면 폭이 좁으면 종이째 축소한다(인쇄 때는 1배).

### 화면 = 인쇄 [필수]
- 인쇄물이 A4 규격과 디자인 그대로 나와야 하고, 인쇄 전 화면에서도 같아야 한다. `check2.py`가 PDF를 그림으로 그려 화면 지면과 쪽마다 대조한다(다른 면적이 0.5%를 넘으면 실패). `@media print`에서 모양을 바꾸는 규칙을 넣지 않는다.
- **PDF가 정본이다.** HTML을 다른 PC에서 열면 그 PC의 서체로 줄바꿈이 조금 달라질 수 있으므로 결재·배포·인쇄는 PDF로 한다.

### 사실만 쓴다
- 사용자가 준 자료와 대화에서 나온 사실·수치만 쓴다. 수치를 지어내지 않는다.
- 양식의 칸을 채우려고 쓴 예시 문구나 판단(평가, 일정(안), 슬로건, 단계 설명 등)이 있으면 전달할 때 "확인이 필요한 문구"로 따로 알린다.

## 공통 작업 순서

1. **원고 확보:** 사용자가 준 자료(PDF·DOCX·엑셀·메모·대화)에서 내용을 뽑는다.
2. **도구 파일 만들기:** 작업 폴더에 아래 「파일 1~5」를 글자 하나 바꾸지 말고 그대로 저장한다: `common.css`, `fit.js`, `build2.py`, `check2.py`, `template.html`. build2.py는 원고와 같은 폴더의 common.css·fit.js를 읽는다.
3. **로고:** 인천대 로고 이미지(흰 배경 JPG/PNG)가 필요하다.
   - `/mnt/user-data/uploads/INU_로고.jpg`나 첨부 파일에서 찾는다.
   - 팀 가족회사 검색기 저장소(`inusanhak5/inu-family-search`, 공개)의 `inu_logo.png`도 공식 로고다(`https://raw.githubusercontent.com/inusanhak5/inu-family-search/main/inu_logo.png`).
   - **투명 배경 PNG는 흰 배경에 합쳐 JPG로 저장한 뒤 쓴다**(투명 부분이 검게 처리되는 것을 막음).
   - 어디에도 없으면 한 줄로 첨부를 요청한다.
4. **원고 HTML 작성:** `template.html`을 복사해 내용만 바꾼다. 템플릿은 실제로 쓴 예시 문서다. 구조와 블록은 그대로 따르고 글과 숫자를 바꾼다. 블록은 아래 「블록 라이브러리」에서 고르고, 새 블록이 필요하면 같은 토큰(색 변수, 선 두께, 글자 크기 위계)으로 만든다.
5. **빌드:** `python3 build2.py 원고.html INU_logo.jpg out 파일이름`
6. **검사:** `python3 check2.py out/파일이름.html out/검사`
   - "결과: 통과"가 나올 때까지 고치고 5~6을 반복한다.
7. **눈으로 확인:** `out/검사/contact.png`(전체 쪽 한눈에)와 쪽별 `s#.png`를 연다. 검사가 못 잡는 것을 본다: 꺾쇠·장식이 글자를 덮는지, 블록 사이가 휑하게 벌어졌는지, 큰 숫자와 설명이 어긋났는지.
8. **전달:** PDF는 미리보기(render)로, HTML은 첨부(attach)로 보낸다. 답변에는 쪽 수, (해당하면) 쪽별 채움, 확인이 필요한 문구만 짧게 쓴다.

**검사 환경**
- `pip install playwright pypdfium2 pypdf qrcode --break-system-packages`
- 브라우저가 없을 때만 `playwright install chromium`(이미 `/opt/pw-browsers`가 있으면 하지 않는다).
- `pypdfium2`·`pypdf`가 설치되지 않으면 화면·인쇄 대조와 PDF 링크 확인만 건너뛰었다고 전달할 때 말한다.

### 검사 기준 (check2.py가 판정)
- 넘침 0: `.body`와 `data-box`를 단 칸
- 본문 쪽 채움 85% 이상(`.body`가 있는 쪽만, 마지막 쪽 50% 이상, `data-nofill` 쪽은 제외하고 눈으로 확인)
- 색 면이 종이 끝 5mm 안까지 닿지 않음, 글자가 종이 끝 5mm 안에 없음
- 단어 중간 줄바꿈 0, 마지막 줄 한 단어 0, 개조식 끝 마침표 0, 벌어진 띄어쓰기(0.6em 초과) 0, 두 줄 제목 0
- 이동할 곳 없는 링크 0, PDF 링크가 맞는 쪽으로 감
- 인쇄(PDF) 쪽 수 = 지면 수, 화면과 인쇄 모양 차이 0.5% 이하

## 파일 1: common.css

````css
/* ===== INU 보고서 패밀리 공통 바탕 (지면형 보고서와 같은 토큰·서체·머리말·인쇄 규칙) ===== */
:root{
  --navy:#1F4E79; --deep:#163A5C; --blue:#2E75B6; --sky:#9DC3E6; --steel:#5B8DC9; --gray:#8A97A8;
  --mist:#D9E2F3; --pale:#EEF3FA; --gold:#FCB01B; --goldpale:#FFF4DC;
  --ink:#1B2330; --sub:#4A5566; --rule:#BFCBDA; --zebra:#F2F2F2; --paper:#FFFFFF;
  --desk:#E4E8EE; --desk-fg:#4A5566;
  --f:'Noto Sans KR','Noto Sans CJK KR','Malgun Gothic','맑은 고딕',sans-serif;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}}
:root[data-theme="dark"]{--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}
*{box-sizing:border-box}
body{background:var(--desk);color:var(--ink);font-family:var(--f);margin:0;word-break:keep-all;overflow-wrap:break-word;line-break:strict;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.doc{padding-block:24px 40px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
.stack{zoom:var(--z,1);display:flex;flex-direction:column;align-items:center;gap:10mm}
.sheet{position:relative;width:210mm;height:297mm;letter-spacing:-.02em;background:var(--paper);color:var(--ink);overflow:hidden;box-shadow:0 1px 2px rgba(20,30,50,.12),0 8px 24px rgba(20,30,50,.10);flex:none}
.sheet.land{width:297mm;height:210mm}
.sheet p{margin:0}
.sheet em{font-style:normal}

/* 머리말·꼬리말: 왼쪽 네이비 로고 + 오른쪽 팀명 + 파란 선 / "- N -" */
.hd{position:absolute;top:10mm;left:16mm;right:16mm;height:8mm;display:flex;align-items:flex-end;justify-content:space-between;border-bottom:.45mm solid var(--blue);padding-bottom:1.4mm}
.hd img{height:5.2mm;display:block}
.hd span{font-size:8pt;color:var(--sub);letter-spacing:.02em}
.ft{position:absolute;bottom:8mm;left:0;right:0;text-align:center;font-size:8.5pt;color:var(--sub)}
.cx{position:absolute;display:block;pointer-events:none}
a.lk{text-decoration:none;color:inherit;-webkit-tap-highlight-color:transparent}
a.lk:focus:not(:focus-visible){outline:none}

/* 표(지면형 보고서와 동일) */
table{width:100%;border-collapse:collapse;font-size:9pt;line-height:1.45;font-variant-numeric:tabular-nums}
thead th{background:var(--mist);color:var(--navy);font-weight:800;padding:1.3mm 1.6mm;border-top:.5mm solid var(--navy);border-bottom:.25mm solid var(--navy);letter-spacing:.04em}
td{padding:1.15mm 1.8mm;border-bottom:.2mm solid var(--rule);vertical-align:middle}
tbody tr:nth-child(even) td{background:var(--zebra)}
td.h{font-weight:700;text-align:center;color:var(--ink);white-space:nowrap}
td.c{text-align:center}
td div+div{margin-top:.5mm}
tr.sum td{background:var(--pale)!important;font-weight:800;color:var(--navy);border-top:.3mm solid var(--navy)}
.note{font-size:8.5pt;color:var(--sub);line-height:1.5;margin:0;padding-left:3.4mm;text-indent:-3.4mm;text-align:justify}
.end{text-align:center;font-size:10pt;font-weight:700;color:var(--navy);letter-spacing:.3em}

@media print{
  @page{size:A4;margin:0}
  body{background:#fff}
  .doc{padding:0}
  .stack{zoom:1!important;gap:0}
  .sheet{box-shadow:none;break-after:page}
}
````

## 파일 2: fit.js

원고의 `<!--{{FIT_JS}}-->` 자리에 build2.py가 넣는다.

````html
<script>
/* 화면 맞춤: 종이 폭(세로 210mm / 가로 297mm)에 맞춰 축소, 인쇄 때는 1배 */
(function(){
  function fitz(){var s=document.querySelector('.sheet');if(!s)return;var w=document.documentElement.clientWidth-32;document.documentElement.style.setProperty('--z',Math.min(1,w/s.offsetWidth).toFixed(4));}
  fitz();addEventListener('resize',fitz);
  addEventListener('beforeprint',function(){document.documentElement.style.setProperty('--z','1');});
  addEventListener('afterprint',fitz);
})();
</script>
<script>
/* 조판 보정(패밀리 공통, 수정 금지): ① 마지막 줄 한 단어 금지 ② 벌어진 띄어쓰기 고르기 ③ 한 줄 제목 유지. 문서별 추가 보정은 window.FIT_EXTRA. 끝나면 html[data-fit=done] */
(function(){
  function chars(el){var a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n;while(n=w.nextNode())for(var i=0;i<n.data.length;i++)a.push([n,i]);return a;}
  var rg=document.createRange();
  function top(c){rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);var r=rg.getClientRects();return r.length?r[r.length-1].top:null;}
  function info(el){var A=chars(el),txt=A.map(function(c){return c[0].data[c[1]];}).join('');var e=txt.replace(/\s+$/,'').length-1;if(e<1)return{lines:1,widow:false};var th=parseFloat(getComputedStyle(el).fontSize)*.6;
    var lt=top(A[e]),s=e;while(s>0){var ch=txt[s-1];if(/\s/.test(ch)){s--;continue;}var t=top(A[s-1]);if(t===null||Math.abs(t-lt)>th)break;s--;}
    var first=top(A[0]),lines=1,prev=first;for(var i=1;i<=e;i++){if(/\s/.test(txt[i]))continue;var t=top(A[i]);if(t!==null&&t-prev>th){lines++;prev=t;}}
    return{lines:lines,widow:lines>1&&!/\s/.test(txt.slice(s,e+1).trim()),A:A,txt:txt,s:s};}
  function em(el){return parseFloat(getComputedStyle(el).letterSpacing)/parseFloat(getComputedStyle(el).fontSize)||0;}
  function glue(el,I){var k=I.txt.slice(0,I.s).replace(/\s+$/,'').length;var c=I.A[k];if(c&&c[0].data[c[1]]===' '){c[0].data=c[0].data.slice(0,c[1])+String.fromCharCode(160)+c[0].data.slice(c[1]+1);}}
  window.FIT={info:info,em:em};
  var WID='.sheet :is(p,li,td,td>div,dd,.fx):not([data-nowidow])';
  function run(){
    document.querySelectorAll(WID).forEach(function(el){
      if(el.querySelector('br,div,ul,p,li'))return;
      var I=info(el);if(!I.widow)return;var base=em(el),L=I.lines;
      for(var d=.005;d<=.0301;d+=.005){el.style.letterSpacing=(base-d).toFixed(3)+'em';var J=info(el);if(!J.widow&&J.lines<=L)return;}
      el.style.letterSpacing='';glue(el,info(el));});
    function gap(el){var fs=parseFloat(getComputedStyle(el).fontSize),w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n,sp=[];
      while(n=w.nextNode())for(var i=0;i<n.data.length;i++){if(n.data[i]!==' ')continue;rg.setStart(n,i);rg.setEnd(n,i+1);var rc=rg.getClientRects()[0];if(rc&&rc.width>0)sp.push([rc.width/fs,rc.top]);}
      if(!sp.length)return 0;var lt=Math.max.apply(null,sp.map(function(x){return x[1];})),m=0;sp.forEach(function(x){if(Math.abs(x[1]-lt)>2&&x[0]>m)m=x[0];});return m;}
    document.querySelectorAll('.sheet :is(p,li,dd,.fx)').forEach(function(el){
      if(getComputedStyle(el).textAlign!=='justify'||el.querySelector('ul,div,p,li')||gap(el)<=.55)return;
      var cur=el.style.letterSpacing,base=em(el),L=info(el).lines,best=[gap(el),cur];
      for(var d=-.045;d<=.0301;d+=.005){el.style.letterSpacing=(base+d).toFixed(3)+'em';var I=info(el);if(I.widow||I.lines>L)continue;var g=gap(el);if(g<best[0])best=[g,el.style.letterSpacing];}
      el.style.letterSpacing=best[1];});
    document.querySelectorAll('.sheet :is(h2,[data-oneline])').forEach(function(h){var base=em(h);for(var d=0;d<=.0401&&info(h).lines>1;d+=.005)h.style.letterSpacing=(base-d).toFixed(3)+'em';});
    (window.FIT_EXTRA||[]).forEach(function(f){f();});
    document.documentElement.dataset.fit='done';}
  (document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve()).then(function(){requestAnimationFrame(run);});
})();
</script>
````

## 파일 3: build2.py

````python
"""INU 보고서 패밀리 빌드: python3 build2.py 원고.html INU_로고.jpg 출력폴더 파일이름
- 원고의 /*{{COMMON_CSS}}*/ 자리에 common.css, <!--{{FIT_JS}}--> 자리에 fit.js를 넣음(원고와 같은 폴더)
- 로고(흰 배경 JPG)에서 네이비·흰색 로고와 골드 꺾쇠(CHEV_TR/CHEV_BL)를 만들어 data URI로 넣음 — 지면형 보고서 build.py와 같은 방식
- {{QR:주소}} → 네이비 QR 코드(SVG data URI)
- 본문 글자 줄바꿈 보조: 글자+( / )+글자는 붙이고(WJ), 가운뎃점은 앞에 붙이고 뒤에서만 줄바꿈 허용(ZWSP)
- 출력: <이름>.html(완성 문서), <이름>_artifact.html(아티팩트 게시용)"""
import re, sys, os, io, base64
import numpy as np
from PIL import Image
src_path, logo_path, out_dir, name = sys.argv[1:5]
os.makedirs(out_dir, exist_ok=True)
here = os.path.dirname(os.path.abspath(src_path))

def logo_variants(path):
    im = np.asarray(Image.open(path).convert('RGB')).astype(float)
    r, g, b = im[..., 0], im[..., 1], im[..., 2]
    warm = (r > g) & (r > b + 30)
    alpha = np.clip((255 - im.min(axis=2)) / 228, 0, 1)
    GOLD = im[warm & (alpha > .9)].mean(0) if (warm & (alpha > .9)).any() else np.array([252, 176, 27])
    def png(img, w):
        img = img.resize((w, max(1, int(img.height * w / img.width))), Image.LANCZOS)
        buf = io.BytesIO(); img.save(buf, 'PNG', optimize=True)
        return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()
    def make(letter, sym_only=False):
        out = np.zeros(im.shape[:2] + (4,), np.uint8)
        out[..., :3] = np.where(warm[..., None], GOLD, letter)
        out[..., 3] = (alpha * 255).astype(np.uint8)
        if sym_only: out[~warm, 3] = 0
        img = Image.fromarray(out, 'RGBA'); return img.crop(img.getbbox())
    def chevron(sym, part):
        a = np.asarray(sym).copy(); H, W = a.shape[:2]
        yy, xx = np.mgrid[0:H, 0:W]; upper = xx / W > yy / H
        a[(~upper) if part == 'tr' else upper, 3] = 0
        p = Image.fromarray(a, 'RGBA'); return p.crop(p.getbbox())
    sym = make(np.array([0, 0, 0]), sym_only=True)
    return {'LOGO_NAVY': png(make(np.array([0x1F, 0x4E, 0x79])), 270), 'LOGO_WHITE': png(make(np.array([255, 255, 255])), 270),
            'CHEV_TR': png(chevron(sym, 'tr'), 220), 'CHEV_BL': png(chevron(sym, 'bl'), 220)}

def qr(url):
    import qrcode, qrcode.image.svg
    q = qrcode.QRCode(border=0, error_correction=qrcode.constants.ERROR_CORRECT_M); q.add_data(url); q.make(fit=True)
    m = q.get_matrix(); n = len(m)
    d = ''.join(f'M{x} {y}h1v1h-1z' for y, row in enumerate(m) for x, v in enumerate(row) if v)
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n} {n}" shape-rendering="crispEdges"><path fill="#1F4E79" d="{d}"/></svg>'
    return 'data:image/svg+xml;base64,' + base64.b64encode(svg.encode()).decode()

src = open(src_path, encoding='utf-8').read()
src = src.replace('/*{{COMMON_CSS}}*/', open(os.path.join(here, 'common.css'), encoding='utf-8').read())
src = src.replace('<!--{{FIT_JS}}-->', open(os.path.join(here, 'fit.js'), encoding='utf-8').read())
src = re.sub(r'\{\{QR:([^}]+)\}\}', lambda m: qr(m.group(1)), src)
for k, v in logo_variants(logo_path).items():
    src = src.replace('{{' + k + '}}', v)

WJ, ZW = chr(0x2060), chr(0x200B)
def tx(t):
    t = re.sub(r'([가-힣A-Za-z0-9])\(', lambda m: m.group(1) + WJ + '(', t)
    t = re.sub(r'\)([가-힣A-Za-z0-9])', lambda m: ')' + WJ + m.group(1), t)
    t = re.sub(r'([가-힣A-Za-z0-9])·([가-힣A-Za-z0-9])', lambda m: m.group(1) + WJ + '·' + ZW + m.group(2), t)
    t = re.sub(r'(\d)-(\d)', lambda m: m.group(1) + WJ + '-' + WJ + m.group(2), t)   # 2-1 같은 번호는 줄에서 떼지 않음
    return t
a = src.index('</style>'); b = src.index('<script>')
src = src[:a] + re.sub(r'>([^<]+)<', lambda m: '>' + tx(m.group(1)) + '<', src[a:b]) + src[b:]

open(os.path.join(out_dir, name + '_artifact.html'), 'w', encoding='utf-8').write(src)
m = re.search(r'</style>', src)
full = ('<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        + src[:m.end()] + '\n</head>\n<body>' + src[m.end():] + '\n</body>\n</html>\n')
open(os.path.join(out_dir, name + '.html'), 'w', encoding='utf-8').write(full)
print('OK', os.path.join(out_dir, name + '.html'))
````

## 파일 4: check2.py

````python
"""INU 보고서 패밀리 검사 + PDF: python3 check2.py 완성문서.html 출력폴더
통과 기준(지면형 보고서 check.py와 같은 원칙):
  넘침 0(.body·[data-box]) · 본문 쪽 채움 85% 이상(.body가 있는 쪽, data-nofill 제외, 마지막 쪽 50%)
  · 인쇄 안전 여백(종이 끝 5mm) 안쪽에만 글자 · 단어 중간 줄바꿈 0 · 마지막 줄 한 단어 0 · 개조식 끝 마침표 0
  · 벌어진 띄어쓰기(0.6em 초과) 0 · 한 줄 제목(h2·[data-oneline]) · 링크 대상 있음
  · 인쇄(PDF) 쪽 수 = 지면 수 · PDF 링크 도착 쪽 일치 · 화면과 인쇄 모양 일치(차이 0.5% 이하)
출력: 쪽별 PNG(s1.png…), 한눈에 보기(contact.png), PDF, 결과"""
import sys, os, re
from playwright.sync_api import sync_playwright
from PIL import Image
html, out = os.path.abspath(sys.argv[1]), sys.argv[2]
os.makedirs(out, exist_ok=True)
JS = r"""() => {
 const rg=document.createRange(), MM=96/25.4, R={pages:[],boxes:[],bleed:[],safe:[],midword:[],widow:[],period:[],gaps:[],titles:[],links:[],nlinks:0,dest:{}};
 const chars=el=>{const a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode())for(let i=0;i<n.data.length;i++)a.push([n,i]);return a;};
 const top=c=>{rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);const r=rg.getClientRects();return r.length?r[r.length-1].top:null;};
 document.querySelectorAll('.sheet').forEach(s=>{const p=+s.dataset.page,b=s.querySelector('.body');
   if(b){const br=b.getBoundingClientRect();let last=0;b.querySelectorAll(':scope>*').forEach(c=>{if(c.classList.contains('end'))return;last=Math.max(last,c.getBoundingClientRect().bottom);});
     R.pages.push({p,overflow:b.scrollHeight-b.clientHeight,fill:Math.round((last-br.top)/br.height*100),nofill:s.hasAttribute('data-nofill')});}
   else R.pages.push({p,nofill:true,overflow:0});
   s.querySelectorAll('[data-box]').forEach(x=>{const o=Math.max(x.scrollHeight-x.clientHeight,x.scrollWidth-x.clientWidth);if(o>1)R.boxes.push(p+'쪽 '+(x.dataset.box||x.className)+' '+o+'px');});
   const S0=s.getBoundingClientRect();s.querySelectorAll('*').forEach(x=>{const cs=getComputedStyle(x),bg=cs.backgroundColor,img=cs.backgroundImage;
     const colored=(img&&img!=='none')||(bg&&!/rgba\(\s*0,\s*0,\s*0,\s*0\)|transparent/.test(bg)&&!/rgb\(255,\s*255,\s*255\)/.test(bg));if(!colored)return;
     const r=x.getBoundingClientRect();if(!r.width||!r.height)return;const m=5*MM;
     if(r.left<S0.left+m||r.right>S0.right-m||r.top<S0.top+m||r.bottom>S0.bottom-m)R.bleed.push(p+'쪽 '+(x.className||x.tagName));});
   const S=s.getBoundingClientRect(),w=document.createTreeWalker(s,NodeFilter.SHOW_TEXT);let n;
   while(n=w.nextNode()){if(!n.data.trim()||n.parentElement.closest('[data-bleed]'))continue;rg.selectNodeContents(n);
     for(const r of rg.getClientRects()){if(!r.width)continue;if(r.left<S.left+5*MM||r.right>S.right-5*MM||r.top<S.top+5*MM||r.bottom>S.bottom-5*MM){R.safe.push(p+'쪽 '+n.data.trim().slice(0,12));break;}}}});
 const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
 while(n=w.nextNode()){if(n.data.trim().length<2)continue;let pt=null;
   for(let i=0;i<n.length;i++){const t=top([n,i]);if(t===null)continue;if(pt!==null&&t>pt+3){const a=n.data[i-1],c=n.data[i];if(/[가-힣A-Za-z0-9]/.test(a)&&/[가-힣A-Za-z0-9]/.test(c))R.midword.push(n.data.slice(Math.max(0,i-8),i)+'|'+n.data.slice(i,i+6));}pt=t;}}
 document.querySelectorAll('.sheet :is(p,li,td,td>div,dd,.fx):not([data-nowidow])').forEach(el=>{
   if(el.querySelector('br,div,ul,p,li'))return;const A=chars(el),txt=A.map(c=>c[0].data[c[1]]).join(''),e=txt.replace(/\s+$/,'').length-1;if(e<1)return;
   const th=parseFloat(getComputedStyle(el).fontSize)*.6,lt=top(A[e]);let s=e;while(s>0){if(/\s/.test(txt[s-1])){s--;continue;}const t=top(A[s-1]);if(t===null||Math.abs(t-lt)>th)break;s--;}
   if(s>0&&Math.abs(top(A[0])-lt)>th&&!/\s/.test(txt.slice(s,e+1).trim()))R.widow.push(txt.slice(s,e+1));});
 document.querySelectorAll('.sheet :is(li,.note,td>div,td:not(:has(div)),dd,[data-np])').forEach(el=>{let t='';el.childNodes.forEach(c=>{if(c.nodeName!=='UL')t+=c.textContent;});if(/[가-힣)]\.\s*$/.test(t))R.period.push(t.trim().slice(-20));});
 document.querySelectorAll('.sheet :is(p,li,dd,.fx)').forEach(el=>{if(getComputedStyle(el).textAlign!=='justify'||el.querySelector('ul,div,p,li'))return;const fs=parseFloat(getComputedStyle(el).fontSize),sp=[];const w2=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let m;
   while(m=w2.nextNode())for(let i=0;i<m.length;i++){if(m.data[i]!==' ')continue;rg.setStart(m,i);rg.setEnd(m,i+1);const rc=rg.getClientRects()[0];if(rc&&rc.width>0)sp.push([rc.width/fs,rc.top,m.data.slice(Math.max(0,i-10),i+10)]);}
   if(!sp.length)return;const lt=Math.max(...sp.map(x=>x[1]));sp.forEach(x=>{if(Math.abs(x[1]-lt)>2&&x[0]>.6)R.gaps.push(x[0].toFixed(2)+' '+x[2]);});});
 document.querySelectorAll('.sheet :is(h2,[data-oneline])').forEach(h=>{const A=chars(h).filter(c=>!/\s/.test(c[0].data[c[1]]));const T=A.map(top).filter(x=>x!==null);if(T.length&&Math.max(...T)-Math.min(...T)>parseFloat(getComputedStyle(h).fontSize)*.6)R.titles.push(h.textContent.trim().slice(0,40));});
 document.querySelectorAll('a[href^="#"]').forEach(a=>{R.nlinks++;const id=a.getAttribute('href').slice(1),t=document.getElementById(id);if(!t)R.links.push(a.textContent.trim()+' → #'+id);else R.dest[id]=+t.closest('.sheet').dataset.page;});
 return R;}"""
with sync_playwright() as p:
    try: br = p.chromium.launch()
    except Exception:
        br = p.chromium.launch(executable_path=next((x for x in ['/opt/pw-browsers/chromium', '/usr/bin/chromium', '/usr/bin/chromium-browser'] if os.path.exists(x)), None))
    pg = br.new_page(viewport={'width': 1300, 'height': 1200}, device_scale_factor=1.5)
    pg.goto('file://' + html); pg.wait_for_function("document.documentElement.dataset.fit==='done'", timeout=30000); pg.wait_for_timeout(250)
    R = pg.evaluate(JS)
    sheets = pg.query_selector_all('.sheet')
    for i, s in enumerate(sheets, 1): s.screenshot(path=f'{out}/s{i}.png')
    pdf = os.path.join(out, os.path.splitext(os.path.basename(html))[0] + '.pdf')
    pg.pdf(path=pdf, format='A4', print_background=True, prefer_css_page_size=True)
    br.close()
raw = open(pdf, 'rb').read()
pdf_links = len(re.findall(rb'/Subtype\s*/Link', raw))
pdf_pages, diffs = None, []
try:
    import pypdfium2 as pdfium
    from PIL import ImageChops, ImageFilter
    doc = pdfium.PdfDocument(pdf); pdf_pages = len(doc)
    for i in range(min(pdf_pages, len(sheets))):
        a = Image.open(f'{out}/s{i+1}.png').convert('L')
        b = doc[i].render(scale=a.width / doc[i].get_width()).to_pil().convert('L').resize(a.size)
        a2, b2 = [x.resize((x.width // 3, x.height // 3)).filter(ImageFilter.GaussianBlur(1)) for x in (a, b)]
        d = ImageChops.difference(a2, b2).point(lambda v: 255 if v > 48 else 0)
        diffs.append(round(d.histogram()[255] / (d.width * d.height) * 100, 3))
except ImportError:
    pdf_pages = len(re.findall(rb'/Type\s*/Page[^s]', raw))
ims = [Image.open(f'{out}/s{i}.png') for i in range(1, len(sheets) + 1)]
sc = 0.3; ims = [im.resize((int(im.width * sc), int(im.height * sc))) for im in ims]; w, h = ims[0].size
cols = min(3 if w > h else 4, len(ims)); rows = -(-len(ims) // cols)
sheet = Image.new('RGB', (cols * w + (cols - 1) * 10, rows * h + (rows - 1) * 10), '#777')
for i, im in enumerate(ims): sheet.paste(im, ((i % cols) * (w + 10), (i // cols) * (h + 10)))
sheet.save(f'{out}/contact.png')
fails = []
body = [x for x in R['pages'] if not x['nofill']]
for x in R['pages']:
    if x['overflow'] > 0: fails.append(f"{x['p']}쪽 넘침 {x['overflow']}px")
for i, x in enumerate(body):
    lim = 50 if x is R['pages'][-1] else 85
    if x['fill'] < lim: fails.append(f"{x['p']}쪽 채움 {x['fill']}% (<{lim}%)")
try:
    from pypdf import PdfReader
    rd = PdfReader(pdf); nd = {k.lstrip('/'): rd.get_destination_page_number(v) + 1 for k, v in rd.named_destinations.items()}
    for k, v in R['dest'].items():
        if nd.get(k) != v: fails.append(f"PDF 링크 {k}가 {nd.get(k)}쪽으로 감 (맞는 쪽 {v})")
except ImportError: pass
if pdf_pages != len(sheets): fails.append(f"인쇄 쪽 수 {pdf_pages} ≠ 지면 {len(sheets)}쪽")
if R['nlinks'] and pdf_links < R['nlinks']: fails.append(f"PDF 링크 {pdf_links}개 < 문서 링크 {R['nlinks']}개")
for i, v in enumerate(diffs, 1):
    if v > 0.5: fails.append(f"{i}쪽 화면과 인쇄 모양 다름 ({v}%)")
for k, label in [('boxes', '칸 넘침'), ('bleed', '색 면이 종이 끝 5mm 안까지 닿음(사무실 프린터에서 흰 테두리 박스로 출력됨)'), ('safe', '인쇄 안전 여백(5mm) 침범'), ('links', '이동할 곳 없는 링크'), ('midword', '단어 중간 줄바꿈'), ('widow', '마지막 줄 한 단어'), ('period', '끝 마침표'), ('gaps', '벌어진 띄어쓰기'), ('titles', '두 줄 제목')]:
    if R[k]: fails.append(f"{label} {len(R[k])}곳: {R[k][:6]}")
print('쪽별 채움:', ' '.join(f"{x['p']}쪽 {x['fill']}%" for x in body) or '(디자인 쪽만 있음)')
print('PDF:', pdf, '| 지면', len(sheets), '쪽 · 인쇄', pdf_pages, '쪽 · 링크', pdf_links, '개 · 화면/인쇄 차이(%)', diffs)
print('결과: 통과' if not fails else '결과: 고칠 곳\n - ' + '\n - '.join(fails))
````

## 파일 5: template.html

실제로 만든 예시 문서다. 구조·클래스·블록은 그대로 두고 제목·글·숫자만 바꾼다.

````html
<title>산학협력 성과 하이라이트</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700;800;900&display=swap">
<style>
/*{{COMMON_CSS}}*/
/* ===== ③ 연차 성과보고서형: 매거진식 A4 세로, 큰 숫자·섹션 번호·하이라이트 카드 ===== */
.ar .body{position:absolute;left:16mm;right:16mm;top:24mm;bottom:17mm;display:flex;flex-direction:column;gap:6mm}
.ar .ft{color:var(--sub)}
.ar .ft b{color:var(--navy);margin-right:3mm;letter-spacing:.14em;font-size:7.4pt}

/* 섹션 머리: 큰 번호 + 제목 + 리드 */
.sx{display:grid;grid-template-columns:auto 1fr;column-gap:5mm;align-items:end;padding-bottom:4mm;border-bottom:.7mm solid var(--navy)}
.sx .no{font-size:62pt;font-weight:900;line-height:.8;color:var(--gold);letter-spacing:-.04em;font-variant-numeric:tabular-nums}
.sx .tt{display:flex;flex-direction:column;gap:1.4mm;padding-bottom:.6mm}
.sx .tt i{font-style:normal;font-size:7.8pt;font-weight:800;color:var(--blue);letter-spacing:.22em}
.sx h1{margin:0;font-size:23pt;font-weight:900;letter-spacing:-.03em;line-height:1.1;color:var(--ink)}
.lead{font-size:10.6pt;line-height:1.7;color:var(--sub);font-weight:500;text-align:left}
.lead b{color:var(--navy);font-weight:800}
.ar h2{margin:0 0 2.8mm;font-size:11.5pt;font-weight:800;color:var(--ink);display:flex;align-items:center;gap:2mm;padding-bottom:1.2mm;border-bottom:.25mm solid var(--rule)}
.ar h2::before{content:"";width:2.6mm;height:2.6mm;background:var(--navy);flex:none}
.ar h2 small{font-size:8.4pt;font-weight:500;color:var(--sub);margin-left:auto}
ul.l{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:1.8mm;font-size:9.6pt;line-height:1.55}
ul.l li{padding-left:4mm;position:relative;text-align:left}
ul.l li::before{content:"";position:absolute;left:.5mm;top:.62em;width:1.4mm;height:1.4mm;background:var(--navy)}
ul.l b{color:var(--navy);font-weight:800}

/* 표지 */
.cov{background:#fff}
.cov .nv{position:absolute;inset:6mm 6mm 66mm 6mm;background:var(--navy);color:#fff;overflow:hidden}
.cov .brand{position:absolute;left:12mm;top:10mm;display:flex;align-items:center;gap:3.4mm}
.cov .brand img{height:11mm;display:block}
.cov .brand span{font-size:9.4pt;font-weight:700;letter-spacing:.05em;border-left:.3mm solid rgba(255,255,255,.5);padding-left:3.4mm;line-height:1.4}
.cov .kick{position:absolute;right:12mm;top:12mm;text-align:right;font-size:8pt;font-weight:800;letter-spacing:.26em;color:var(--sky)}
.cov .kick b{display:block;color:#fff;font-size:13pt;letter-spacing:.04em;margin-top:1mm}
.cov .yr{position:absolute;left:6mm;top:38mm;font-size:168pt;font-weight:900;line-height:.82;letter-spacing:-.06em;color:transparent;-webkit-text-stroke:.55mm var(--gold);font-variant-numeric:tabular-nums}
.cov .ttl{position:absolute;left:12mm;right:12mm;top:122mm}
.cov .pill{display:inline-block;background:var(--gold);color:var(--navy);font-size:9pt;font-weight:800;padding:1mm 3mm;letter-spacing:.08em}
.cov h1{margin:5mm 0 0;font-size:36pt;font-weight:900;line-height:1.16;letter-spacing:-.03em}
.cov .subt{margin:5mm 0 0;font-size:12pt;color:var(--sky);font-weight:500;letter-spacing:-.01em}
.cov .cx.tr{width:30mm;right:12mm;top:116mm}
.cov .cx.bl{width:22mm;left:3mm;top:190mm}
.cov .low{position:absolute;left:0;right:0;bottom:0;height:66mm;background:#fff;color:var(--ink);padding:9mm 18mm 0;display:flex;flex-direction:column;gap:6mm}
.cov .trio{display:grid;grid-template-columns:repeat(3,1fr);border-top:.6mm solid var(--navy)}
.cov .trio div{padding:3.4mm 4mm 0 0;display:flex;flex-direction:column;gap:1mm;border-right:.2mm solid var(--rule);padding-left:4mm}
.cov .trio div:first-child{padding-left:0}
.cov .trio div:last-child{border-right:0}
.cov .trio strong{font-size:28pt;font-weight:900;color:var(--navy);line-height:1;letter-spacing:-.03em}
.cov .trio strong small{font-size:11pt;margin-left:.8mm}
.cov .trio span{font-size:9pt;font-weight:800}
.cov .trio em{font-size:7.8pt;color:var(--sub)}
.cov .foot{margin-top:auto;margin-bottom:12mm;display:flex;justify-content:space-between;align-items:flex-end;font-size:8.6pt;color:var(--sub);border-top:.25mm solid var(--rule);padding-top:2.4mm}
.cov .foot b{color:var(--navy);font-size:10pt}

/* 숫자로 보는 2026 */
.nums{display:grid;grid-template-columns:repeat(4,1fr);grid-auto-rows:46mm;gap:3.4mm}
.nums > div{border-top:.9mm solid var(--navy);background:var(--pale);padding:4mm 4mm 3.6mm;display:flex;flex-direction:column;gap:1.2mm}
.nums > div.hero{background:var(--navy);color:#fff;border-top-color:var(--gold)}
.nums > div.g{border-top-color:var(--gold)}
.nums strong{font-size:33pt;font-weight:900;color:var(--navy);line-height:1;letter-spacing:-.035em;font-variant-numeric:tabular-nums;margin-top:auto}
.nums .hero strong{color:#fff}
.nums strong small{font-size:10.5pt;font-weight:800;margin-left:.6mm;letter-spacing:-.01em}
.nums span{font-size:9.4pt;font-weight:800}
.nums em{font-size:7.8pt;color:var(--sub);line-height:1.45}
.nums .hero em{color:var(--sky)}
.nums i{font-style:normal;font-size:7.2pt;font-weight:800;letter-spacing:.18em;color:var(--blue)}
.nums .hero i{color:var(--gold)}
.flows{display:grid;grid-template-columns:repeat(4,1fr);gap:3.4mm;flex:1}
.flows ul.l{font-size:8.6pt;gap:1.3mm;margin-top:1mm;border-top:.2mm dashed var(--rule);padding-top:2mm}
.flows ul.l li{padding-left:3.4mm}
.flows ul.l li::before{width:1.2mm;height:1.2mm}
.flows a{display:flex;flex-direction:column;gap:1.4mm;border:.25mm solid var(--rule);padding:3.4mm 3.6mm;color:inherit}
.flows b{font-size:20pt;font-weight:900;color:var(--gold);line-height:1;letter-spacing:-.03em}
.flows span{font-size:10.4pt;font-weight:900;color:var(--navy)}
.flows em{font-size:8.2pt;color:var(--sub);line-height:1.5}
.flows small{margin-top:auto;font-size:7.8pt;font-weight:700;color:var(--blue);letter-spacing:.06em}

/* 01 AI 인재 양성 */
.bar{display:flex;height:12mm;font-size:8.6pt;font-weight:800;color:#fff}
.bar div{display:flex;align-items:center;justify-content:center;white-space:nowrap;border-right:.4mm solid #fff;gap:1.2mm}
.bar div b{font-size:10.4pt;font-weight:900}
.bar div:last-child{border-right:0}
.scale{display:flex;justify-content:space-between;font-size:7.8pt;color:var(--sub);margin-top:1.4mm}
.tl{position:relative;height:54mm}
.tl .ax{position:absolute;left:0;right:0;top:25mm;height:.8mm;background:var(--rule)}
.tl .done{position:absolute;left:0;top:25mm;height:.8mm;background:var(--navy)}
.tl .mo{position:absolute;top:21.2mm;font-size:7.4pt;font-weight:800;color:var(--sub);transform:translateX(-50%);background:#fff;padding:0 1.4mm;letter-spacing:.06em}
.tl .tk{position:absolute;top:23.6mm;width:.3mm;height:3.6mm;background:var(--gray)}
.tl .ev{position:absolute;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;text-align:center;width:40mm}
.tl .ev.up{bottom:calc(54mm - 24.6mm)}
.tl .ev.dn{top:26.2mm}
.tl .ev .dot{width:4mm;height:4mm;border-radius:50%;background:#fff;border:.7mm solid var(--navy)}
.tl .ev.past .dot{background:var(--navy)}
.tl .ev.gold .dot{border-color:var(--gold)}
.tl .ev.gold.past .dot{background:var(--gold)}
.tl .ev b{font-size:11pt;font-weight:900;color:var(--navy);line-height:1.1}
.tl .ev span{font-size:8.2pt;font-weight:700;line-height:1.35}
.tl .ev em{font-size:7.4pt;color:var(--sub);line-height:1.3}
.tl .ev.up{flex-direction:column-reverse}
.tl .ev.up .dot{margin-top:1.4mm}
.tl .ev.dn .dot{margin-bottom:1.4mm}
.tl .ev.r{transform:translateX(-95%)}
.tl .ev.l2{transform:translateX(-8%);align-items:flex-start;text-align:left}
.tl .ev.l2 .dot{margin-left:1.2mm}
.tl .ev.r{align-items:flex-end;text-align:right}
.tl .ev.r .dot{margin-right:1.2mm}
.tl .today{position:absolute;top:9mm;height:22mm;width:.5mm;background:var(--gold)}
.tl .today i{position:absolute;top:0;right:1.2mm;font-style:normal;font-size:7pt;font-weight:800;color:var(--navy);background:var(--gold);padding:.2mm 1.4mm;white-space:nowrap}
.tl .months{position:absolute;left:0;right:0;bottom:0;display:flex;height:5.4mm}
.tl .months span{display:flex;align-items:center;justify-content:center;font-size:7.6pt;font-weight:800;color:var(--navy);letter-spacing:.08em;background:var(--pale);border-right:.4mm solid #fff}
.tl .months span:nth-child(even){background:var(--mist)}
.tlg{display:flex;gap:5mm;font-size:7.8pt;color:var(--sub);margin-top:1mm}
.tlg span{display:flex;align-items:center;gap:1.4mm}
.tlg i{width:3mm;height:3mm;border-radius:50%;border:.6mm solid var(--navy);display:inline-block}
.cards2{display:grid;grid-template-columns:1fr 1fr;gap:5mm;flex:1}
.cd{border:.25mm solid var(--rule);border-top:.9mm solid var(--navy);padding:4mm 4.6mm 4.4mm;display:flex;flex-direction:column;gap:2.8mm}
.cd ul.l{font-size:9.6pt;gap:2.4mm}
.cd.g{border-top-color:var(--gold)}
.cd i.k{font-style:normal;font-size:7.4pt;font-weight:800;color:var(--blue);letter-spacing:.2em}
.cd h3{margin:0;font-size:12pt;font-weight:900;color:var(--ink);letter-spacing:-.02em}
.cd dl{margin:0;display:grid;grid-template-columns:14mm 1fr;row-gap:2.2mm;font-size:9.6pt;line-height:1.5}
.cd dt{font-weight:800;color:var(--navy)}
.cd dd{margin:0}
.cd .hl{margin-top:auto;background:var(--goldpale);border-left:1mm solid var(--gold);padding:2.2mm 3mm;font-size:9pt;font-weight:700;line-height:1.5}

/* 02 협력 네트워크 */
.net{display:grid;grid-template-columns:1fr 64mm;gap:7mm;flex:1}
.vt{position:relative;display:flex;flex-direction:column;justify-content:space-between;padding-left:6mm}
.vt::before{content:"";position:absolute;left:1.6mm;top:2mm;bottom:2mm;width:.6mm;background:var(--rule)}
.vt > div{position:relative;display:grid;grid-template-columns:25mm 1fr;column-gap:3mm}
.vt > div::before{content:"";position:absolute;left:-6mm;top:1.2mm;width:3.8mm;height:3.8mm;border-radius:50%;background:#fff;border:.7mm solid var(--navy);box-sizing:border-box}
.vt > div.key::before{background:var(--gold);border-color:var(--gold)}
.vt time{font-size:9.4pt;font-weight:900;color:var(--navy);font-variant-numeric:tabular-nums;white-space:nowrap}
.vt p{font-size:9.8pt;font-weight:800;line-height:1.45}
.vt p span{display:block;font-size:8.6pt;font-weight:500;color:var(--sub);margin-top:.4mm}
.vt .tg{display:inline-block;font-size:7.2pt;font-weight:800;color:var(--navy);border:.25mm solid var(--navy);padding:0 1.2mm;margin-left:1.4mm;vertical-align:.3mm;letter-spacing:.04em}
.vt .key .tg{background:var(--gold);border-color:var(--gold)}
.side{display:flex;flex-direction:column;gap:3.4mm}
.big8{background:var(--navy);color:#fff;padding:4.4mm 4.6mm;display:flex;flex-direction:column;gap:1mm}
.big8 strong{font-size:40pt;font-weight:900;line-height:1;letter-spacing:-.04em}
.big8 strong small{font-size:13pt;margin-left:.8mm}
.big8 span{font-size:9.2pt;font-weight:800}
.big8 em{font-size:7.8pt;color:var(--sky);line-height:1.45}
.grp{border:.25mm solid var(--rule);padding:2.8mm 3.6mm;display:flex;flex-direction:column;gap:1.2mm;flex:1;justify-content:center}
.grp i{font-style:normal;font-size:7.2pt;font-weight:800;color:var(--blue);letter-spacing:.18em}
.grp b{font-size:10pt;font-weight:900;color:var(--navy);line-height:1.4}
.grp span{font-size:8.2pt;color:var(--sub);line-height:1.45}

/* 03 일하는 방식의 전환 */
.tools{display:grid;grid-template-columns:repeat(3,1fr);grid-auto-rows:1fr;gap:3.6mm;flex:1}
.tool{border:.25mm solid var(--rule);padding:4mm 4.4mm 3.6mm;display:flex;flex-direction:column;gap:1.5mm;position:relative}
.tool svg{width:9mm;height:9mm;display:block;margin-bottom:.2mm}
.tool h3{margin:0;font-size:11.8pt;font-weight:900;color:var(--ink);letter-spacing:-.02em}
.tool p{font-size:9.2pt;line-height:1.55;color:var(--sub);text-align:left}
.tool ul.l{font-size:8.6pt;gap:1.3mm;line-height:1.5;margin-top:.6mm}
.tool ul.l li{padding-left:3.4mm}
.tool ul.l li::before{width:1.2mm;height:1.2mm}
.tool.hero ul.l li{color:#fff}
.tool.hero ul.l li::before{background:var(--gold)}
.tool .fact{margin-top:auto;font-size:8.8pt;font-weight:800;color:var(--navy);border-top:.2mm dashed var(--rule);padding-top:1.8mm}
.tool .fact strong{font-size:17pt;font-weight:900;letter-spacing:-.02em;margin-right:.6mm}
.tool.hero{background:var(--navy);border-color:var(--navy)}
.tool.hero h3{color:#fff}.tool.hero p{color:var(--sky)}.tool.hero .fact{color:#fff;border-top-color:rgba(255,255,255,.35)}
.news{display:grid;grid-template-columns:40mm 1fr;border:.3mm solid var(--gold);background:linear-gradient(90deg,var(--goldpale),#fff 70%)}
.news > b{display:flex;flex-direction:column;justify-content:center;padding:3.4mm 4mm;font-size:11pt;font-weight:900;color:var(--navy);border-right:.25mm solid var(--gold);gap:.6mm}
.news > b i{font-style:normal;font-size:7.2pt;letter-spacing:.18em;color:var(--blue)}
.news > div{display:grid;grid-template-columns:repeat(4,1fr);align-items:center;padding:3mm 4mm;gap:3mm}
.news > div span{display:flex;flex-direction:column;gap:.4mm;font-size:8.2pt;color:var(--sub);border-left:.8mm solid var(--navy);padding-left:2.4mm;line-height:1.35}
.news > div span b{font-size:9.4pt;font-weight:900;color:var(--navy)}

/* 04 2027 */
.road{display:flex;flex-direction:column;gap:3.4mm;flex:1}
.rd{display:grid;grid-template-columns:22mm 1fr 44mm;border:.25mm solid var(--rule);flex:1}
.rd > b{background:var(--navy);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.6mm;font-size:17pt;font-weight:900}
.rd > b i{font-style:normal;font-size:6.8pt;letter-spacing:.16em;color:var(--gold);font-weight:800}
.rd.g > b{background:var(--gold);color:var(--navy)}
.rd.g > b i{color:var(--navy)}
.rd > div{padding:3.2mm 4.4mm;display:flex;flex-direction:column;justify-content:center;gap:1mm}
.rd h3{margin:0;font-size:11.4pt;font-weight:900;color:var(--ink);letter-spacing:-.02em}
.rd p{font-size:9pt;line-height:1.5;color:var(--sub)}
.rd .st{border-left:.2mm dashed var(--rule);display:flex;flex-direction:column;justify-content:center;padding:2.6mm 3.6mm;gap:.6mm;background:var(--pale)}
.rd .st i{font-style:normal;font-size:7pt;font-weight:800;color:var(--blue);letter-spacing:.16em}
.rd .st span{font-size:8.8pt;font-weight:800;color:var(--navy);line-height:1.4}
.close{background:var(--navy);color:#fff;display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:6mm;padding:5mm 6mm}
.close img{height:9mm;display:block}
.close p{font-size:10.4pt;font-weight:700;line-height:1.6;border-left:.3mm solid rgba(255,255,255,.4);padding-left:6mm}
.close p span{display:block;font-size:8.2pt;color:var(--sky);font-weight:500}
.close dl{margin:0;display:grid;grid-template-columns:auto auto;column-gap:2.4mm;row-gap:.6mm;font-size:8.4pt}
.close dt{color:var(--gold);font-weight:800}
.close dd{margin:0}
.ar .end{margin-top:-1mm}
</style>

<div class="doc"><div class="stack">

<!-- ===== 1. 표지 ===== -->
<section class="sheet ar cov" data-page="1">
  <div class="nv">
  <div class="brand"><img src="{{LOGO_WHITE}}" alt="INU"><span>인천대학교 산학협력단<br>산학협력팀</span></div>
  <div class="kick">ANNUAL HIGHLIGHTS<b>2026. 1.~10.</b></div>
  <div class="yr" data-bleed aria-hidden="true">2026</div>
  <img class="cx tr" src="{{CHEV_TR}}" alt=""><img class="cx bl" src="{{CHEV_BL}}" alt="">
  <div class="ttl">
    <span class="pill">성과 하이라이트</span>
    <h1>산학협력<br>성과 하이라이트</h1>
    <p class="subt">AI 인재 양성 · 협력 네트워크 · 일하는 방식의 전환</p>
  </div>
  </div>
  <div class="low">
    <div class="trio">
      <div><strong>127<small>명</small></strong><span>상반기 AI 교육 수강</span><em>연간 319명 예상</em></div>
      <div><strong>1,534<small>개사</small></strong><span>가족회사 검색기 수록</span><em>2026. 8. 업데이트 기준</em></div>
      <div><strong>222<small>건</small></strong><span>산학협력활동 수록</span><em>검색기 통합 데이터</em></div>
    </div>
    <div class="foot"><span>발행 2026년 10월 22일</span><b>인천대학교 산학협력단 산학협력팀</b></div>
  </div>
</section>

<!-- ===== 2. 숫자로 보는 2026 ===== -->
<section class="sheet ar" data-page="2">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="body">
    <div class="sx"><div class="no">26</div><div class="tt"><i>BY THE NUMBERS</i><h1>숫자로 보는 2026</h1></div></div>
    <p class="lead">가족회사 재직자와 경영진을 위한 <b>AI 교육을 정례화</b>하고, 외부 기관과의 <b>협력 범위를 넓히며</b>, 팀이 직접 만든 <b>디지털 도구로 일하는 방식</b>까지 바꾼 2026년 1~10월의 기록</p>
    <div class="nums">
      <div class="hero"><i>EDUCATION</i><strong>127<small>명</small></strong><span>상반기 AI 교육 수강</span><em>5개 과정 수강 합계</em></div>
      <div><i>EDUCATION</i><strong>319<small>명</small></strong><span>연간 수강 예상</span><em>하반기 192명 예정 포함</em></div>
      <div><i>EDUCATION</i><strong>3<small>단계</small></strong><span>초급·중급·고급 과정</span><em>상·하반기 연 2회 운영</em></div>
      <div class="g"><i>NETWORK</i><strong>1<small>건</small></strong><span>신규 업무협약</span><em>한국화학융합시험연구원(KTR), 2026. 9. 14.</em></div>
      <div><i>PLATFORM</i><strong>1,534<small>개사</small></strong><span>가족회사 검색기 수록</span><em>2026. 8. 업데이트 기준</em></div>
      <div><i>PLATFORM</i><strong>222<small>건</small></strong><span>산학협력활동 수록</span><em>검색기 통합 데이터</em></div>
      <div><i>PLATFORM</i><strong>13<small>개사</small></strong><span>플래티넘 가족회사</span><em>「PLATINUM 13」 명예의 전당</em></div>
      <div class="g"><i>RISE</i><strong>564.9<small>백만원</small></strong><span>단위과제 2-1 2차년도 예산</span><em>산학협력 공유플랫폼 조성</em></div>
    </div>
    <div style="flex:1;display:flex;flex-direction:column">
      <h2>올해의 세 가지 흐름과 다음 걸음</h2>
      <div class="flows">
        <a class="lk" href="#s1"><b>01</b><span>AI 인재 양성</span><em>재직자 3단계 과정과 CEO 특강 정례화</em><ul class="l"><li>상반기 수강 127명</li><li>하반기 초급·중급·고급 운영</li><li>CEO 특강 8. 19.·10. 26.</li></ul><small>3쪽 ›</small></a>
        <a class="lk" href="#s2"><b>02</b><span>협력 네트워크</span><em>시험기관·공공기관·교육기관으로 협력 확장</em><ul class="l"><li>KTR 업무협약(9. 14.)</li><li>한국산업인력공단 업무협의</li><li>재능고·재능대 협력 논의</li></ul><small>4쪽 ›</small></a>
        <a class="lk" href="#s3"><b>03</b><span>일하는 방식의 전환</span><em>팀이 직접 만든 도구로 반복 업무 축소</em><ul class="l"><li>가족회사 검색기·확인기</li><li>디지털 명함 5개 사이트</li><li>예산 집행관리 시트</li></ul><small>5쪽 ›</small></a>
        <a class="lk" href="#s4"><b>04</b><span>2027 다음 걸음</span><em>연구회·교육 거점·훈련 연계로 확장</em><ul class="l"><li>IN:AI 프런티어 연구회</li><li>상시 AI 교육 거점 조성</li><li>공동훈련 연계</li></ul><small>6쪽 ›</small></a>
      </div>
    </div>
  </div>
  <div class="ft"><b>BY THE NUMBERS</b>- 2 -</div>
</section>

<!-- ===== 3. 01 AI 인재 양성 ===== -->
<section class="sheet ar" data-page="3" id="s1">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="body">
    <div class="sx"><div class="no">01</div><div class="tt"><i>HIGHLIGHT 01</i><h1>AI 인재 양성</h1></div></div>
    <p class="lead">가족회사 재직자를 위한 <b>초급·중급·고급 3단계 실습 과정</b>을 상·하반기로 정례화하고, 인천비전기업협회 경영진 대상 <b>CEO 특강</b>을 더해 교육 대상을 실무자에서 경영진까지 넓힌 한 해</p>
    <div>
      <h2>상반기 수강 127명 구성<small>2026. 1.~6., 단위: 명</small></h2>
      <div class="bar">
        <div style="width:17.3%;background:var(--navy)">초급 <b>22</b></div>
        <div style="width:18.1%;background:var(--blue)">중급 <b>23</b></div>
        <div style="width:14.2%;background:var(--steel)">고급 <b>18</b></div>
        <div style="width:30.7%;background:var(--deep)">AX 아카데미 <b>39</b></div>
        <div style="width:19.7%;background:var(--gold);color:var(--navy)">CEO 특강 <b>25</b></div>
      </div>
      <div class="scale"><span>단계별 과정 63명(49.6%)</span><span>AX전환 재직자 혁신 아카데미·CEO 특강 64명(50.4%)</span></div>
    </div>
    <div>
      <h2>하반기 교육 흐름<small>2026. 8.~11.</small></h2>
      <div class="tl">
        <div class="ax"></div><div class="done" style="width:67.2%"></div>
        <i class="tk" style="left:0"></i><i class="tk" style="left:25.4%"></i><i class="tk" style="left:50%"></i><i class="tk" style="left:75.4%"></i><i class="tk" style="left:calc(100% - .3mm)"></i>
        <div class="today" style="left:67.2%"><i>10. 22. 현재</i></div>
        <div class="ev up gold past" style="left:14.8%"><span class="dot"></span><b>8. 19.</b><span>CEO 특강 1·2회</span><em>「리더를 위한 AI 경영혁신」</em></div>
        <div class="ev up gold l2" style="left:70.5%"><span class="dot"></span><b>10. 26.</b><span>CEO 특강 추가 회차</span><em>8월 반응에 힘입어 개설</em></div>
        <div class="ev dn past" style="left:49.2%"><span class="dot"></span><b>9. 30.</b><span>초급 과정</span><em>운영 완료</em></div>
        <div class="ev dn" style="left:72.1%"><span class="dot"></span><b>10. 28.</b><span>중급 과정</span><em>다음 과정</em></div>
        <div class="ev dn r" style="left:95.1%"><span class="dot"></span><b>11. 25.</b><span>고급 과정</span><em>예정</em></div>
        <div class="months"><span style="width:25.4%">8월</span><span style="width:24.6%">9월</span><span style="width:25.4%">10월</span><span style="width:24.6%">11월</span></div>
      </div>
      <div class="tlg"><span><i style="border-color:var(--gold);background:var(--gold)"></i>CEO 특강(인천비전기업협회)</span><span><i></i>가족회사 단계별 과정</span><span><i style="background:var(--navy)"></i>운영 완료</span></div>
    </div>
    <div class="cards2">
      <div class="cd g"><i class="k">CEO PROGRAM</i><h3>리더를 위한 AI 경영혁신</h3>
        <dl>
          <dt>대상</dt><dd>인천비전기업협회 CEO</dd>
          <dt>내용</dt><dd>생성형 AI 사업계획서 작성·스마트 영업전략</dd>
          <dt>장소</dt><dd>인천테크노파크 미추홀타워 본관 3층</dd>
          <dt>강사</dt><dd>IN교육컨설팅 박성민 대표</dd>
          <dt>정원</dt><dd>회차당 30명, 무료</dd>
          <dt>일정</dt><dd>8. 19.·10. 26. 각 오전·오후</dd>
        </dl>
        <p class="hl">8. 19. 오전·오후 2회 운영 후 반응이 좋아 10. 26. 추가 회차 개설</p></div>
      <div class="cd"><i class="k">INFRA</i><h3>교육 기반 확충</h3>
        <ul class="l">
          <li>이노베이션센터 유휴공간을 <b>상시 AI 교육 거점</b>으로 조성하는 방안 보고 추진</li>
          <li>교육용 <b>노트북 6대</b> 구입 계획(안) 수립으로 실습 장비 고장 대응</li>
          <li>학산도서관 코워킹 스튜디오·인천테크노파크를 실습 교육장으로 활용</li>
          <li>교육마다 안내 웹페이지를 직접 제작해 참여 기업에 안내</li>
        </ul>
        <p class="hl">거점은 교내 여러 부서가 함께 쓰는 공용 교육 공간으로 추진</p></div>
    </div>
  </div>
  <div class="ft"><b>HIGHLIGHT 01</b>- 3 -</div>
</section>

<!-- ===== 4. 02 협력 네트워크 ===== -->
<section class="sheet ar" data-page="4" id="s2">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="body">
    <div class="sx"><div class="no">02</div><div class="tt"><i>HIGHLIGHT 02</i><h1>협력 네트워크</h1></div></div>
    <p class="lead">시험·인증 전문기관과 <b>업무협약</b>을 맺고, 공공기관·교육기관·교내 교수진과 차례로 만나 <b>가족회사 지원의 폭을 넓힌</b> 8~10월의 협력 기록</p>
    <div class="net">
      <div class="vt">
        <div><time>2026. 8.</time><p>인천대–재능대 연구실 장비 공동 활용 계획(안)<span>RISE 단위과제 2-1 소관, 통합 관리 계획 결재 추진</span></p></div>
        <div><time>2026. 9.</time><p>재능고등학교 방문 협의<span>협약형 특성화고(3기, 피지컬 AI) 선정에 따른 협력 논의</span></p></div>
        <div class="key"><time>2026. 9. 14.</time><p>한국화학융합시험연구원(KTR) 업무협약<i class="tg">MOU</i><span>시험·인증 전문기관과 협력 기반 마련</span></p></div>
        <div><time>2026. 9. 29.</time><p>KTR 과천 본원 후속 협의<span>업무협약 후속 조치 논의</span></p></div>
        <div><time>2026. 10. 2.</time><p>한국산업인력공단 인천지사 업무협의<span>가족회사 AI 교육의 공동훈련 연계 방안 논의</span></p></div>
        <div><time>2026. 10. 8.</time><p>산학협력 OPENTALK 교수 방문 협의<span>임베디드시스템공학과 교수와 협력 과제 논의</span></p></div>
        <div class="key"><time>2026. 10. 14.</time><p>유료 가족회사 간담회<i class="tg">특강</i><span>「작은 조직을 위한 AI 도입 이야기」 초청 특강</span></p></div>
        <div><time>2026. 10. 19.</time><p>산학협력중점교수 회의<span>IN:AI 프런티어 연구회(가칭) 안건 논의</span></p></div>
      </div>
      <div class="side">
        <div class="big8"><strong>8<small>건</small></strong><span>주요 대외 협력 일정</span><em>2026. 8.~10. 협의·협약·간담회</em></div>
        <div class="grp"><i>RESEARCH</i><b>시험·인증 기관</b><span>한국화학융합시험연구원(KTR)</span></div>
        <div class="grp"><i>PUBLIC</i><b>공공기관</b><span>한국산업인력공단 인천지사</span></div>
        <div class="grp"><i>EDUCATION</i><b>교육기관</b><span>인천재능대학교·재능고등학교</span></div>
        <div class="grp"><i>INDUSTRY</i><b>기업·단체</b><span>가족회사·인천비전기업협회</span></div>
        <div class="grp"><i>CAMPUS</i><b>교내</b><span>산학협력중점교수·학과 교수진</span></div>
      </div>
    </div>
  </div>
  <div class="ft"><b>HIGHLIGHT 02</b>- 4 -</div>
</section>

<!-- ===== 5. 03 일하는 방식의 전환 ===== -->
<section class="sheet ar" data-page="5" id="s3">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="body">
    <div class="sx"><div class="no">03</div><div class="tt"><i>HIGHLIGHT 03</i><h1>일하는 방식의 전환</h1></div></div>
    <p class="lead"><b>팀이 직접 만든 작은 도구</b>로 가족회사 정보 확인, 예산 관리, 문서 작성 같은 <b>반복 업무를 줄이고</b> 가족회사에 새로운 서비스를 제공한 한 해</p>
    <div class="tools">
      <div class="tool hero">
        <svg viewBox="0 0 24 24" fill="none" stroke="#FCB01B" stroke-width="2" stroke-linecap="round"><circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5 21 21"/></svg>
        <h3>가족회사 검색기</h3><p>가족회사와 산학협력활동을 한곳에서 찾는 웹 서비스</p><ul class="l"><li>정식 결재 서비스(계획 2025. 12. 17., 결과보고 2026. 2. 12.)</li><li>2026. 8. 통합 안내 챗봇·「PLATINUM 13」 추가</li><li>사진으로 가족회사 찾기 기능 추가 예정</li></ul>
        <div class="fact"><strong>1,534</strong>개사 · <strong>222</strong>건 수록</div></div>
      <div class="tool">
        <svg viewBox="0 0 24 24" fill="none" stroke="#1F4E79" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h11M4 10h7"/><path d="M14 14l3 3 4-6"/><rect x="2.5" y="2.5" width="19" height="19" rx="1"/></svg>
        <h3>가족회사 확인기</h3><p>웹페이지에서 기업명을 끌어 선택하면 가족회사 여부를 바로 알려 주는 브라우저 확장</p><ul class="l"><li>검색기 가족회사 명단과 연동</li><li>학교 웹메일 화면에서 바로 확인</li><li>사용 매뉴얼과 함께 배포</li></ul>
        <div class="fact">산학협력단 구성원 배포 추진</div></div>
      <div class="tool">
        <svg viewBox="0 0 24 24" fill="none" stroke="#1F4E79" stroke-width="2" stroke-linejoin="round"><rect x="2.5" y="5" width="19" height="14" rx="1"/><circle cx="8" cy="11" r="2.2"/><path d="M5 16c.8-1.8 5.2-1.8 6 0M14 10h5M14 13.5h4"/></svg>
        <h3>디지털 명함</h3><p>플래티넘 가족회사에 제공하는 개별 명함 웹사이트</p><ul class="l"><li>플래티넘 가족회사 연계 서비스</li><li>사람마다 개별 주소로 배포·관리</li></ul>
        <div class="fact"><strong>5</strong>개 사이트 운영</div></div>
      <div class="tool">
        <svg viewBox="0 0 24 24" fill="none" stroke="#1F4E79" stroke-width="2"><rect x="2.5" y="3.5" width="19" height="17" rx="1"/><path d="M2.5 8.5h19M2.5 13.5h19M9 8.5v12M15 8.5v12"/></svg>
        <h3>예산 집행관리 시트</h3><p>단위과제 2-1 예산을 팀이 함께 관리하는 공유 시트</p><ul class="l"><li>집행 입력이 예산 현황·잔액에 자동 반영</li><li>잔액 부족·집행률 초과 자동 표시</li><li>담당자별 개별 시트 제공</li></ul>
        <div class="fact"><strong>11</strong>개 탭 · 담당자별 시트</div></div>
      <div class="tool">
        <svg viewBox="0 0 24 24" fill="none" stroke="#1F4E79" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2.5h9l4 4v15H6z"/><path d="M15 2.5v4h4"/><path d="M9 14l2 2 4-5"/></svg>
        <h3>공문서 검토기</h3><p>기안문을 붙여 넣으면 서식·표기 오류를 찾아 주는 문서 점검 도구</p><ul class="l"><li>공문서 서식·표기 규칙 자동 점검</li><li>설치 없이 파일 하나로 실행</li></ul>
        <div class="fact">기안문 작성 단계에서 활용</div></div>
      <div class="tool">
        <svg viewBox="0 0 24 24" fill="none" stroke="#1F4E79" stroke-width="2" stroke-linecap="round"><rect x="4" y="2.5" width="16" height="19" rx="1"/><path d="M8 7h8M8 11h8M8 15h5"/></svg>
        <h3>보고서 자동화</h3><p>산학협력단 표준 양식 보고서를 AI로 바로 만드는 작업 체계</p><ul class="l"><li>결과보고서·계획(안)·타 대학 벤치마킹</li><li>표지·머리말·쪽 배치 자동 적용</li></ul>
        <div class="fact">표준 양식 스킬로 정리</div></div>
    </div>
    <div class="news"><b><i>NEWSLETTER</i>월간 가족회사<br>뉴스레터</b><div>
      <span><b>INU Special</b>대학 주요 소식</span><span><b>News</b>산학협력 보도자료</span><span><b>Family</b>가족회사 소식</span><span><b>Trend</b>정부기관 발간 자료</span>
    </div></div>
  </div>
  <div class="ft"><b>HIGHLIGHT 03</b>- 5 -</div>
</section>

<!-- ===== 6. 04 2027 다음 걸음 ===== -->
<section class="sheet ar" data-page="6" id="s4">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="body">
    <div class="sx"><div class="no">04</div><div class="tt"><i>NEXT STEPS</i><h1>2027 다음 걸음</h1></div></div>
    <p class="lead">올해 쌓은 교육·협력·도구를 바탕으로 <b>교육 이후까지 이어지는 지원</b>과 <b>교내외 공동 활용</b>으로 산학협력의 범위를 넓힐 계획</p>
    <div class="road">
      <div class="rd g"><b><i>NEXT</i>01</b><div><h3>IN:AI 프런티어 연구회(가칭)</h3><p>교육 수료 기업의 실무자가 정기적으로 모여 자사 AI 과제를 풀어 가는 연구회 운영</p></div><div class="st"><i>STATUS</i><span>중점교수 회의 논의, 2027년 예산 반영 추진</span></div></div>
      <div class="rd"><b><i>NEXT</i>02</b><div><h3>상시 AI 교육 거점 조성</h3><p>이노베이션센터 유휴공간을 교내 부서와 함께 쓰는 공용 AI 교육 공간으로 조성</p></div><div class="st"><i>STATUS</i><span>공간 조성 방안 보고 추진</span></div></div>
      <div class="rd"><b><i>NEXT</i>03</b><div><h3>공동훈련 연계</h3><p>한국산업인력공단 인천지사와 가족회사 AI 교육을 중소기업 공동훈련으로 잇는 방안 구체화</p></div><div class="st"><i>STATUS</i><span>10. 2. 업무협의 후 후속 검토</span></div></div>
      <div class="rd"><b><i>NEXT</i>04</b><div><h3>검색기 사진 검색 기능</h3><p>행사 서명록 사진을 찍으면 가족회사 여부를 바로 찾는 기능을 검색기에 추가</p></div><div class="st"><i>STATUS</i><span>기능 방향 확정</span></div></div>
      <div class="rd"><b><i>NEXT</i>05</b><div><h3>뉴스레터 제작 내재화</h3><p>외부 용역으로 만들던 월간 뉴스레터를 팀이 직접 만드는 방식으로 전환 검토</p></div><div class="st"><i>STATUS</i><span>내재화 방안 검토</span></div></div>
    </div>
    <div class="close"><img src="{{LOGO_WHITE}}" alt="INU"><p>인천대학교 산학협력단 산학협력팀<span>가족회사와 함께 성장하는 산학협력</span></p>
      <dl><dt>전화</dt><dd>032-835-9758</dd><dt>메일</dt><dd>kirium4u@inu.ac.kr</dd></dl></div>
    <div class="end">— 끝 —</div>
  </div>
  <div class="ft"><b>NEXT STEPS</b>- 6 -</div>
</section>

</div></div>

<!--{{FIT_JS}}-->
````