---
name: "inu-print-consult"
description: "INU 지면 패밀리 · 컨설팅형 — 결론 문장 제목과 근거 도표 하나로 쪽을 짜는 A4 가로 검토·건의 보고서(HTML·PDF). '컨설팅형', '검토(안)', '결론 중심 보고', '건의 보고' 요청에 사용."
---

# INU 컨설팅형 보고서 (INU 지면 패밀리)

결정을 받아야 하는 **검토·건의 보고**를 컨설팅 보고서 방식으로 만든다. A4 가로, 쪽마다 **결론 문장 제목(액션 타이틀) 하나 + 그 결론을 증명하는 근거 도표 하나**. 단장님·부총장 보고, 신규 사업 검토(안), 예산 반영 건의처럼 "그래서 무엇을 해 달라는 것인가"가 분명해야 하는 보고에 쓴다. 지면형 보고서(inu-print-report)와 같은 바탕을 쓴다.

시작점: 2026. 10. 「IN:AI 프런티어 연구회 추진 검토(안)」(템플릿 = 그 실제 문서, 6쪽).

산출물: 완성 HTML, 같은 HTML을 A4 가로로 인쇄한 PDF.

## 쪽 구성 (보통 5~8쪽)

1. **표지**(`.sheet.land.cs.cvr`)
   - 왼쪽 네이비 면(`.lp`): 종이 끝에서 6mm 안쪽(`inset:6mm auto 6mm 6mm`), 폭 172mm. 흰 로고, 보고 종류 pill, 제목 2줄(30pt), 부제, 아래 `REPORT` + 보고일.
   - 골드 꺾쇠 두 개는 스크립트가 제목 길이에 맞춰 자동 배치한다(위 꺾쇠는 제목 오른쪽 위, 아래 꺾쇠는 부제 아래 왼쪽 — 지면형 보고서 E안과 같은 방식). 꺾쇠가 부제를 덮지 않는지 눈으로 확인한다.
   - 오른쪽: 보고 요지 3개(번호 칸), 메타(보고 부서·관련 회의·출발점 등), CONTENTS(쪽 링크), 맨 아래 팀명.
2. **한 장 요약**(EXECUTIVE SUMMARY)
   - 결론 제목 = 보고 전체의 결론 한 문장.
   - 상황·문제·해법 3단 카드(`.scr`, 해법 카드는 골드 선 `.r`). 카드 아래쪽에 핵심 숫자(`.kf`)와 작은 도식(`.mini`)을 두어 카드 아래가 비지 않게 한다.
   - 맨 아래 건의 3칸(`.ask`: 골드 번호 + 굵은 건의 + 보충 한 줄).
3. **근거 쪽 EXHIBIT 1~N**: 현황 진단 → 해법 구조 → 대안 비교 → 추진 계획처럼 결론을 받치는 순서로.
4. **마지막 쪽**: 추진 계획(간트) + 건의를 다시 놓고 `— 끝 —`.

## 근거 쪽 공통 틀 (모든 본문 쪽 같음)

- 머리말(로고 + 팀명 + 파란 선, 공통).
- `.kick`: 왼쪽 `EXHIBIT N` + 한국어 쪽 이름, 오른쪽 **트래커**(`nav.trk`: 모든 본문 쪽 이름, 현재 쪽 `.on` 네이비). 트래커와 표지 목차는 누르면 그 쪽으로 이동하는 링크(`a.lk href="#pN"`, 각 `section`에 `id="pN"`). 링크는 모양을 바꾸지 않는다(밑줄·색 바뀜 없음).
- **결론 제목(`.at > h1.fx`)**: 16.5pt, 2줄 이내, 핵심어는 `<em>`(네이비). 아래 굵은 네이비 선. `data-box`로 넘침 검사.
- 본문(`.body`): 근거 도표 1개 중심. 필요하면 맨 아래 `SO WHAT` 띠(`.sowhat`, 네이비 바탕 한 줄 시사점).
- 아래 줄: 왼쪽 **자료 출처(`.src`, 필수)**, 가운데 쪽 번호, 오른쪽 문서명(`.dn`).

## 결론 제목 쓰는 법 [필수]

- **주제가 아니라 주장**으로 쓴다: '현황'(×) → 'AI 교육은 상반기에만 127명이 들을 만큼 수요가 확인됐지만, 하루 과정 중심이라 현장 정착으로 이어질 장치가 비어 있음'(○).
- **제목만 이어 읽어도 보고 전체 이야기가 되게** 쓴다(요약 → 현황 → 해법 → 운영안 → 추진 계획).
- 한 쪽에 메시지 하나. 그 쪽 도표가 제목을 증명해야 한다. 증명하지 못하는 도표는 빼거나 다른 쪽으로 옮긴다.
- 숫자 하나 이상을 넣으면 설득력이 커진다 [권장].
- 개조식 명사형으로 끝내고 마침표를 찍지 않는다.

## 블록(도표) 라이브러리 (템플릿에 들어 있는 것)

| 도표 | 클래스 | 쓰는 곳 |
|---|---|---|
| 상황·문제·해법 카드 | `.scr` + `.kf` + `.mini` | 한 장 요약 |
| 건의 3칸 | `.ask` | 요약 쪽 아래, 마지막 쪽 |
| 가로 막대 | `.hbar` | 항목별 크기 비교. 막대 폭 = 값 ÷ 최댓값, 강조 행 `.hi`, 합계 `.tot` |
| 큰 숫자 + 누적 막대 | `.yr` + `.stk` | 연간 합계와 그 구성 |
| 3단 흐름 | `.flow` | 지금 구조의 흐름, 빈 곳은 `.gap`(골드 점선) |
| 3단계 구조 | `.steps` + `.st` | 해법 구조, 가운데 핵심 단계 `.mid`, 단계별 역할 줄 `.role` |
| 지금/앞으로 비교표 | `table.cmp` | 바뀌는 점, 앞으로 열 `.next` 강조 |
| 대안 비교(하비 볼) | `.opt` + `.hb` + `.legend` | 대안 A·B·C 비교. 원 채움 `--v:25/50/75/100`, 권고 열 `.rec`·`.rc` |
| 권고안 골격 상자 | `.frame` | 권고안의 참여·방식·지원·확산 + 기대 효과 |
| 간트 일정 | `.gt` | 월 열, 막대 `.b`(left·width를 % 로, 한 칸 = 100%), 완료 회색 `.done`·준비 파랑·운영 골드 `.gold`, 보고일 선 `.now` |
| 시사점 띠 | `.sowhat` | 쪽 결론을 한 줄로 다시 |

- **평가가 들어간 도표(하비 볼 등)에는 "※ 비교 평가는 담당 부서 실무 검토 의견(안)…" 주석을 반드시 단다.** 예시 판단을 사실처럼 쓰지 않는다.
- 일정(안)도 '자료: … 추진 계획(안) — 세부 일정은 … 조정'처럼 출처 줄에 성격을 밝힌다.

## 쪽 맞추기

- 본문 쪽 채움 85% 이상(검사).
- **넘치면:** 도표 행 높이·글자를 줄이거나 문구를 줄인다. 결론 제목은 2줄을 넘기지 않는다.
- **비면:** 먼저 도표를 키운다(행 높이, 숫자 크기, 표 위아래 여백 — 그리드는 `flex:1`·`grid-template-rows:… 1fr`로 늘린다). 그래도 비면 원고에서 나온 SO WHAT 띠, 기대 효과, 보충 표를 더한다. 없는 사실은 만들지 않는다.
- 카드 안 설명·목록은 왼쪽 정렬로 둔다(좁은 칸 양쪽 정렬은 띄어쓰기가 벌어진다).

## 어떤 스킬을 쓸까 (INU 지면 패밀리)

같은 바탕(네이비 색, 서체, 로고, 머리말, 어절 줄바꿈, 출력 여백)을 쓰는 형제 스킬이 넷이다. 사용자는 스킬 이름을 외우지 않아도 된다. "팩트시트로", "컨설팅형으로", "성과보고서형으로"라고 하거나 용도만 말해도 아래 표로 고른다. 두 가지 이상이 맞을 만큼 애매하면 한 줄로 묻는다.

| 사용자가 원하는 것 | 스킬 | 판형 |
|---|---|---|
| 결재용 장문 보고서(Ⅰ~Ⅵ장 구조, 결과·출장·간담회 보고) | inu-print-report (지면형 보고서) | A4 세로, 여러 쪽 |
| 교육·사업·행사를 한 장에 담은 안내·배포물 | inu-print-factsheet (팩트시트) | A4 세로 1장 |
| 결정을 받아야 하는 검토·건의 보고(단장님·부총장 보고 등) | inu-print-consult (컨설팅형) | A4 가로, 5~8쪽 |
| 한 해 또는 한 사업의 성과를 보여 주는 성과집 | inu-print-annual (성과보고서형) | A4 세로, 6쪽 내외 |
| 워드(.docx) 파일이 꼭 필요할 때 | inu-report-master | DOCX |
| 3단 접지 홍보 브로셔(펼친 크기 360×240mm) | 이 패밀리 범위 밖 — 면 배치가 다르므로 디자인 요소만 빌려 쓴다 | — |

## 패밀리 공통 규칙

### 출력 여백 [필수] (사용자 결정, 2026. 10. 22.)
- 사무실 프린터는 종이 가장자리 4~5mm를 찍지 못한다. 색 면을 종이 끝까지 채우면 그 부분이 잘려 흰 테두리가 생긴다. 특히 세로로 선 덩어리 면은 종이 위에 놓인 "세로로 긴 사각형 박스"처럼 출력된다(컨설팅형 표지를 사용자가 실제로 출력해 발견).
- 그래서 배경색·그라데이션이 있는 모든 요소는 **종이 끝에서 6mm 안쪽**에 둔다. 화면에서도 처음부터 흰 여백이 고르게 보이므로 화면과 출력 모양이 같다.
- 글자도 종이 끝 5mm 안쪽에만 둔다. 예외: 색 면 안에서 잘리도록 둔 장식 글자(성과보고서형 표지의 큰 연도)는 `data-bleed`를 단다.
- `check2.py`가 둘 다 검사한다(5mm 기준이라 6mm로 두면 1mm 여유).
- 참고: 지면형 보고서(inu-print-report) 표지의 위쪽 가로 띠도 종이 끝에 닿지만, 가로 띠는 출력해도 머리 띠로 읽혀 자연스러우므로 그 스킬은 그대로 둔다.

### 표기 규칙 (지면형 보고서와 같음 — 반드시 지킴)
- **개조식 명사형 종결, 끝 마침표 없음:** 목록·카드·주석·제목 모두 '~함', '~발표', '~필요', '~추진'으로 끝낸다. 한 항목 안에서 문장이 둘로 나뉠 때만 중간 마침표를 쓴다.
- **따옴표:** 굽은 따옴표 ‘ ’ “ ”를 쓴다. 문서·행사·법령·사업 이름은 「 」로 감싼다.
- **날짜:** 공문서식 '2026. 10. 14.(수)'(점 뒤 띄움). 기간은 '2026. 1.~6.'.
- **단위:** 숫자와 단위를 붙인다('19개사', '46명'). 큰 숫자는 천 단위 쉼표('1,534').
- **'평생교육' 금지:** 재직자 계속교육, 직무역량 강화, 기업 맞춤형 인력양성 등으로 바꾼다(고칠 수 없는 원문 인용만 예외).
- **로고:** 모든 산출물에 넣는다. 밝은 바탕은 네이비 로고, 어두운 바탕은 흰 글자 + 골드 심볼(build2.py가 만들어 넣음).
- 동그라미 숫자(①②③)를 제목·목록 머리에 쓰지 않는다. 번호가 필요하면 네모 칸 숫자나 '01'처럼 쓴다.

### 조판 규칙 (fit.js·build2.py에 구현 — 끄지 말 것)
- **줄바꿈:** 어절 단위(`word-break:keep-all`) + `line-break:strict`(쉼표·닫는 괄호·가운뎃점이 줄 첫머리에 오지 않음).
- **build2.py 줄바꿈 보조:** '간담회(제5차)'처럼 괄호 붙은 말은 한 단어로 묶고, 가운뎃점은 앞에 붙이고 뒤에서만 줄바꿈을 허용하며, '2-1' 같은 숫자 번호는 줄에서 떼지 않는다.
- **마지막 줄 한 단어 금지:** 자간을 최대 -0.03em 줄여 끌어올리고, 안 되면 마지막 두 단어를 붙여 함께 내린다. 대상은 `p, li, td, td>div, dd, .fx`. 일부러 빼려면 `data-nowidow`.
- **띄어쓰기 고르기:** 양쪽 정렬 문단의 띄어쓰기가 0.55em보다 넓게 벌어지면 자간을 -0.045~+0.03em 안에서 다시 고른다. 10.5pt 이상 큰 글씨, 좁은 칸, 카드 안 설명은 양쪽 정렬 대신 왼쪽 정렬로 둔다(벌어짐 방지).
- **한 줄 제목:** `h2`와 `data-oneline` 요소는 자간을 최대 -0.04em까지 줄여 한 줄로 맞춘다. 그래도 넘치면 문구를 줄인다.
- **줄 판정:** 높이 차이가 글자 크기의 60%를 넘을 때만 줄이 바뀐 것으로 본다(큰 숫자 옆 작은 단위 글자 때문에 줄이 바뀐 것으로 잘못 보지 않게).
- **글자:** 기본 자간 -0.02em. 서체는 Noto Sans KR(웹 폰트), 안 되면 설치된 Noto Sans CJK KR·맑은 고딕.
- **표:** 머리 #D9E2F3 + 네이비 위 선, 짝수 행 #F2F2F2, 첫 열 `td.h`, 숫자 열 `td.c`, 합계 `tr.sum`. 한 칸 안 여러 줄은 `<div>`로 한 줄씩 쓰고 글머리 기호(•)는 쓰지 않는다.
- **종이:** 늘 흰색이고 종이 뒤 배경만 다크 모드를 따른다. 화면 폭이 좁으면 종이째 축소한다(인쇄 때는 1배).

### 화면 = 인쇄 [필수]
- 인쇄물이 A4 규격과 디자인 그대로 나와야 하고, 인쇄 전 화면에서도 같아야 한다. `check2.py`가 PDF를 그림으로 그려 화면 지면과 쪽마다 대조한다(다른 면적이 0.5%를 넘으면 실패). `@media print`에서 모양을 바꾸는 규칙을 넣지 않는다.
- **PDF가 정본이다.** HTML을 다른 PC에서 열면 그 PC의 서체로 줄바꿈이 조금 달라질 수 있으므로 결재·배포·인쇄는 PDF로 한다.

### 사실만 쓴다
- 사용자가 준 자료와 대화에서 나온 사실·수치만 쓴다. 수치를 지어내지 않는다.
- 양식의 칸을 채우려고 쓴 예시 문구나 판단(평가, 일정(안), 슬로건, 단계 설명 등)이 있으면 전달할 때 "확인이 필요한 문구"로 따로 알린다.

## 공통 작업 순서

1. **원고 확보:** 사용자가 준 자료(PDF·DOCX·엑셀·메모·대화)에서 내용을 뽑는다.
2. **도구 파일 만들기:** 작업 폴더에 아래 「파일 1~5」를 글자 하나 바꾸지 말고 그대로 저장한다: `common.css`, `fit.js`, `build2.py`, `check2.py`, `template.html`. build2.py는 원고와 같은 폴더의 common.css·fit.js를 읽는다.
3. **로고:** 인천대 로고 이미지(흰 배경 JPG/PNG)가 필요하다.
   - `/mnt/user-data/uploads/INU_로고.jpg`나 첨부 파일에서 찾는다.
   - 팀 가족회사 검색기 저장소(`inusanhak5/inu-family-search`, 공개)의 `inu_logo.png`도 공식 로고다(`https://raw.githubusercontent.com/inusanhak5/inu-family-search/main/inu_logo.png`).
   - **투명 배경 PNG는 흰 배경에 합쳐 JPG로 저장한 뒤 쓴다**(투명 부분이 검게 처리되는 것을 막음).
   - 어디에도 없으면 한 줄로 첨부를 요청한다.
4. **원고 HTML 작성:** `template.html`을 복사해 내용만 바꾼다. 템플릿은 실제로 쓴 예시 문서다. 구조와 블록은 그대로 따르고 글과 숫자를 바꾼다. 블록은 아래 「블록 라이브러리」에서 고르고, 새 블록이 필요하면 같은 토큰(색 변수, 선 두께, 글자 크기 위계)으로 만든다.
5. **빌드:** `python3 build2.py 원고.html INU_logo.jpg out 파일이름`
6. **검사:** `python3 check2.py out/파일이름.html out/검사`
   - "결과: 통과"가 나올 때까지 고치고 5~6을 반복한다.
7. **눈으로 확인:** `out/검사/contact.png`(전체 쪽 한눈에)와 쪽별 `s#.png`를 연다. 검사가 못 잡는 것을 본다: 꺾쇠·장식이 글자를 덮는지, 블록 사이가 휑하게 벌어졌는지, 큰 숫자와 설명이 어긋났는지.
8. **전달:** PDF는 미리보기(render)로, HTML은 첨부(attach)로 보낸다. 답변에는 쪽 수, (해당하면) 쪽별 채움, 확인이 필요한 문구만 짧게 쓴다.

**검사 환경**
- `pip install playwright pypdfium2 pypdf qrcode --break-system-packages`
- 브라우저가 없을 때만 `playwright install chromium`(이미 `/opt/pw-browsers`가 있으면 하지 않는다).
- `pypdfium2`·`pypdf`가 설치되지 않으면 화면·인쇄 대조와 PDF 링크 확인만 건너뛰었다고 전달할 때 말한다.

### 검사 기준 (check2.py가 판정)
- 넘침 0: `.body`와 `data-box`를 단 칸
- 본문 쪽 채움 85% 이상(`.body`가 있는 쪽만, 마지막 쪽 50% 이상, `data-nofill` 쪽은 제외하고 눈으로 확인)
- 색 면이 종이 끝 5mm 안까지 닿지 않음, 글자가 종이 끝 5mm 안에 없음
- 단어 중간 줄바꿈 0, 마지막 줄 한 단어 0, 개조식 끝 마침표 0, 벌어진 띄어쓰기(0.6em 초과) 0, 두 줄 제목 0
- 이동할 곳 없는 링크 0, PDF 링크가 맞는 쪽으로 감
- 인쇄(PDF) 쪽 수 = 지면 수, 화면과 인쇄 모양 차이 0.5% 이하

## 파일 1: common.css

````css
/* ===== INU 보고서 패밀리 공통 바탕 (지면형 보고서와 같은 토큰·서체·머리말·인쇄 규칙) ===== */
:root{
  --navy:#1F4E79; --deep:#163A5C; --blue:#2E75B6; --sky:#9DC3E6; --steel:#5B8DC9; --gray:#8A97A8;
  --mist:#D9E2F3; --pale:#EEF3FA; --gold:#FCB01B; --goldpale:#FFF4DC;
  --ink:#1B2330; --sub:#4A5566; --rule:#BFCBDA; --zebra:#F2F2F2; --paper:#FFFFFF;
  --desk:#E4E8EE; --desk-fg:#4A5566;
  --f:'Noto Sans KR','Noto Sans CJK KR','Malgun Gothic','맑은 고딕',sans-serif;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}}
:root[data-theme="dark"]{--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}
*{box-sizing:border-box}
body{background:var(--desk);color:var(--ink);font-family:var(--f);margin:0;word-break:keep-all;overflow-wrap:break-word;line-break:strict;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.doc{padding-block:24px 40px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
.stack{zoom:var(--z,1);display:flex;flex-direction:column;align-items:center;gap:10mm}
.sheet{position:relative;width:210mm;height:297mm;letter-spacing:-.02em;background:var(--paper);color:var(--ink);overflow:hidden;box-shadow:0 1px 2px rgba(20,30,50,.12),0 8px 24px rgba(20,30,50,.10);flex:none}
.sheet.land{width:297mm;height:210mm}
.sheet p{margin:0}
.sheet em{font-style:normal}

/* 머리말·꼬리말: 왼쪽 네이비 로고 + 오른쪽 팀명 + 파란 선 / "- N -" */
.hd{position:absolute;top:10mm;left:16mm;right:16mm;height:8mm;display:flex;align-items:flex-end;justify-content:space-between;border-bottom:.45mm solid var(--blue);padding-bottom:1.4mm}
.hd img{height:5.2mm;display:block}
.hd span{font-size:8pt;color:var(--sub);letter-spacing:.02em}
.ft{position:absolute;bottom:8mm;left:0;right:0;text-align:center;font-size:8.5pt;color:var(--sub)}
.cx{position:absolute;display:block;pointer-events:none}
a.lk{text-decoration:none;color:inherit;-webkit-tap-highlight-color:transparent}
a.lk:focus:not(:focus-visible){outline:none}

/* 표(지면형 보고서와 동일) */
table{width:100%;border-collapse:collapse;font-size:9pt;line-height:1.45;font-variant-numeric:tabular-nums}
thead th{background:var(--mist);color:var(--navy);font-weight:800;padding:1.3mm 1.6mm;border-top:.5mm solid var(--navy);border-bottom:.25mm solid var(--navy);letter-spacing:.04em}
td{padding:1.15mm 1.8mm;border-bottom:.2mm solid var(--rule);vertical-align:middle}
tbody tr:nth-child(even) td{background:var(--zebra)}
td.h{font-weight:700;text-align:center;color:var(--ink);white-space:nowrap}
td.c{text-align:center}
td div+div{margin-top:.5mm}
tr.sum td{background:var(--pale)!important;font-weight:800;color:var(--navy);border-top:.3mm solid var(--navy)}
.note{font-size:8.5pt;color:var(--sub);line-height:1.5;margin:0;padding-left:3.4mm;text-indent:-3.4mm;text-align:justify}
.end{text-align:center;font-size:10pt;font-weight:700;color:var(--navy);letter-spacing:.3em}

@media print{
  @page{size:A4;margin:0}
  body{background:#fff}
  .doc{padding:0}
  .stack{zoom:1!important;gap:0}
  .sheet{box-shadow:none;break-after:page}
}
````

## 파일 2: fit.js

원고의 `<!--{{FIT_JS}}-->` 자리에 build2.py가 넣는다.

````html
<script>
/* 화면 맞춤: 종이 폭(세로 210mm / 가로 297mm)에 맞춰 축소, 인쇄 때는 1배 */
(function(){
  function fitz(){var s=document.querySelector('.sheet');if(!s)return;var w=document.documentElement.clientWidth-32;document.documentElement.style.setProperty('--z',Math.min(1,w/s.offsetWidth).toFixed(4));}
  fitz();addEventListener('resize',fitz);
  addEventListener('beforeprint',function(){document.documentElement.style.setProperty('--z','1');});
  addEventListener('afterprint',fitz);
})();
</script>
<script>
/* 조판 보정(패밀리 공통, 수정 금지): ① 마지막 줄 한 단어 금지 ② 벌어진 띄어쓰기 고르기 ③ 한 줄 제목 유지. 문서별 추가 보정은 window.FIT_EXTRA. 끝나면 html[data-fit=done] */
(function(){
  function chars(el){var a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n;while(n=w.nextNode())for(var i=0;i<n.data.length;i++)a.push([n,i]);return a;}
  var rg=document.createRange();
  function top(c){rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);var r=rg.getClientRects();return r.length?r[r.length-1].top:null;}
  function info(el){var A=chars(el),txt=A.map(function(c){return c[0].data[c[1]];}).join('');var e=txt.replace(/\s+$/,'').length-1;if(e<1)return{lines:1,widow:false};var th=parseFloat(getComputedStyle(el).fontSize)*.6;
    var lt=top(A[e]),s=e;while(s>0){var ch=txt[s-1];if(/\s/.test(ch)){s--;continue;}var t=top(A[s-1]);if(t===null||Math.abs(t-lt)>th)break;s--;}
    var first=top(A[0]),lines=1,prev=first;for(var i=1;i<=e;i++){if(/\s/.test(txt[i]))continue;var t=top(A[i]);if(t!==null&&t-prev>th){lines++;prev=t;}}
    return{lines:lines,widow:lines>1&&!/\s/.test(txt.slice(s,e+1).trim()),A:A,txt:txt,s:s};}
  function em(el){return parseFloat(getComputedStyle(el).letterSpacing)/parseFloat(getComputedStyle(el).fontSize)||0;}
  function glue(el,I){var k=I.txt.slice(0,I.s).replace(/\s+$/,'').length;var c=I.A[k];if(c&&c[0].data[c[1]]===' '){c[0].data=c[0].data.slice(0,c[1])+String.fromCharCode(160)+c[0].data.slice(c[1]+1);}}
  window.FIT={info:info,em:em};
  var WID='.sheet :is(p,li,td,td>div,dd,.fx):not([data-nowidow])';
  function run(){
    document.querySelectorAll(WID).forEach(function(el){
      if(el.querySelector('br,div,ul,p,li'))return;
      var I=info(el);if(!I.widow)return;var base=em(el),L=I.lines;
      for(var d=.005;d<=.0301;d+=.005){el.style.letterSpacing=(base-d).toFixed(3)+'em';var J=info(el);if(!J.widow&&J.lines<=L)return;}
      el.style.letterSpacing='';glue(el,info(el));});
    function gap(el){var fs=parseFloat(getComputedStyle(el).fontSize),w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n,sp=[];
      while(n=w.nextNode())for(var i=0;i<n.data.length;i++){if(n.data[i]!==' ')continue;rg.setStart(n,i);rg.setEnd(n,i+1);var rc=rg.getClientRects()[0];if(rc&&rc.width>0)sp.push([rc.width/fs,rc.top]);}
      if(!sp.length)return 0;var lt=Math.max.apply(null,sp.map(function(x){return x[1];})),m=0;sp.forEach(function(x){if(Math.abs(x[1]-lt)>2&&x[0]>m)m=x[0];});return m;}
    document.querySelectorAll('.sheet :is(p,li,dd,.fx)').forEach(function(el){
      if(getComputedStyle(el).textAlign!=='justify'||el.querySelector('ul,div,p,li')||gap(el)<=.55)return;
      var cur=el.style.letterSpacing,base=em(el),L=info(el).lines,best=[gap(el),cur];
      for(var d=-.045;d<=.0301;d+=.005){el.style.letterSpacing=(base+d).toFixed(3)+'em';var I=info(el);if(I.widow||I.lines>L)continue;var g=gap(el);if(g<best[0])best=[g,el.style.letterSpacing];}
      el.style.letterSpacing=best[1];});
    document.querySelectorAll('.sheet :is(h2,[data-oneline])').forEach(function(h){var base=em(h);for(var d=0;d<=.0401&&info(h).lines>1;d+=.005)h.style.letterSpacing=(base-d).toFixed(3)+'em';});
    (window.FIT_EXTRA||[]).forEach(function(f){f();});
    document.documentElement.dataset.fit='done';}
  (document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve()).then(function(){requestAnimationFrame(run);});
})();
</script>
````

## 파일 3: build2.py

````python
"""INU 보고서 패밀리 빌드: python3 build2.py 원고.html INU_로고.jpg 출력폴더 파일이름
- 원고의 /*{{COMMON_CSS}}*/ 자리에 common.css, <!--{{FIT_JS}}--> 자리에 fit.js를 넣음(원고와 같은 폴더)
- 로고(흰 배경 JPG)에서 네이비·흰색 로고와 골드 꺾쇠(CHEV_TR/CHEV_BL)를 만들어 data URI로 넣음 — 지면형 보고서 build.py와 같은 방식
- {{QR:주소}} → 네이비 QR 코드(SVG data URI)
- 본문 글자 줄바꿈 보조: 글자+( / )+글자는 붙이고(WJ), 가운뎃점은 앞에 붙이고 뒤에서만 줄바꿈 허용(ZWSP)
- 출력: <이름>.html(완성 문서), <이름>_artifact.html(아티팩트 게시용)"""
import re, sys, os, io, base64
import numpy as np
from PIL import Image
src_path, logo_path, out_dir, name = sys.argv[1:5]
os.makedirs(out_dir, exist_ok=True)
here = os.path.dirname(os.path.abspath(src_path))

def logo_variants(path):
    im = np.asarray(Image.open(path).convert('RGB')).astype(float)
    r, g, b = im[..., 0], im[..., 1], im[..., 2]
    warm = (r > g) & (r > b + 30)
    alpha = np.clip((255 - im.min(axis=2)) / 228, 0, 1)
    GOLD = im[warm & (alpha > .9)].mean(0) if (warm & (alpha > .9)).any() else np.array([252, 176, 27])
    def png(img, w):
        img = img.resize((w, max(1, int(img.height * w / img.width))), Image.LANCZOS)
        buf = io.BytesIO(); img.save(buf, 'PNG', optimize=True)
        return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()
    def make(letter, sym_only=False):
        out = np.zeros(im.shape[:2] + (4,), np.uint8)
        out[..., :3] = np.where(warm[..., None], GOLD, letter)
        out[..., 3] = (alpha * 255).astype(np.uint8)
        if sym_only: out[~warm, 3] = 0
        img = Image.fromarray(out, 'RGBA'); return img.crop(img.getbbox())
    def chevron(sym, part):
        a = np.asarray(sym).copy(); H, W = a.shape[:2]
        yy, xx = np.mgrid[0:H, 0:W]; upper = xx / W > yy / H
        a[(~upper) if part == 'tr' else upper, 3] = 0
        p = Image.fromarray(a, 'RGBA'); return p.crop(p.getbbox())
    sym = make(np.array([0, 0, 0]), sym_only=True)
    return {'LOGO_NAVY': png(make(np.array([0x1F, 0x4E, 0x79])), 270), 'LOGO_WHITE': png(make(np.array([255, 255, 255])), 270),
            'CHEV_TR': png(chevron(sym, 'tr'), 220), 'CHEV_BL': png(chevron(sym, 'bl'), 220)}

def qr(url):
    import qrcode, qrcode.image.svg
    q = qrcode.QRCode(border=0, error_correction=qrcode.constants.ERROR_CORRECT_M); q.add_data(url); q.make(fit=True)
    m = q.get_matrix(); n = len(m)
    d = ''.join(f'M{x} {y}h1v1h-1z' for y, row in enumerate(m) for x, v in enumerate(row) if v)
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n} {n}" shape-rendering="crispEdges"><path fill="#1F4E79" d="{d}"/></svg>'
    return 'data:image/svg+xml;base64,' + base64.b64encode(svg.encode()).decode()

src = open(src_path, encoding='utf-8').read()
src = src.replace('/*{{COMMON_CSS}}*/', open(os.path.join(here, 'common.css'), encoding='utf-8').read())
src = src.replace('<!--{{FIT_JS}}-->', open(os.path.join(here, 'fit.js'), encoding='utf-8').read())
src = re.sub(r'\{\{QR:([^}]+)\}\}', lambda m: qr(m.group(1)), src)
for k, v in logo_variants(logo_path).items():
    src = src.replace('{{' + k + '}}', v)

WJ, ZW = chr(0x2060), chr(0x200B)
def tx(t):
    t = re.sub(r'([가-힣A-Za-z0-9])\(', lambda m: m.group(1) + WJ + '(', t)
    t = re.sub(r'\)([가-힣A-Za-z0-9])', lambda m: ')' + WJ + m.group(1), t)
    t = re.sub(r'([가-힣A-Za-z0-9])·([가-힣A-Za-z0-9])', lambda m: m.group(1) + WJ + '·' + ZW + m.group(2), t)
    t = re.sub(r'(\d)-(\d)', lambda m: m.group(1) + WJ + '-' + WJ + m.group(2), t)   # 2-1 같은 번호는 줄에서 떼지 않음
    return t
a = src.index('</style>'); b = src.index('<script>')
src = src[:a] + re.sub(r'>([^<]+)<', lambda m: '>' + tx(m.group(1)) + '<', src[a:b]) + src[b:]

open(os.path.join(out_dir, name + '_artifact.html'), 'w', encoding='utf-8').write(src)
m = re.search(r'</style>', src)
full = ('<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        + src[:m.end()] + '\n</head>\n<body>' + src[m.end():] + '\n</body>\n</html>\n')
open(os.path.join(out_dir, name + '.html'), 'w', encoding='utf-8').write(full)
print('OK', os.path.join(out_dir, name + '.html'))
````

## 파일 4: check2.py

````python
"""INU 보고서 패밀리 검사 + PDF: python3 check2.py 완성문서.html 출력폴더
통과 기준(지면형 보고서 check.py와 같은 원칙):
  넘침 0(.body·[data-box]) · 본문 쪽 채움 85% 이상(.body가 있는 쪽, data-nofill 제외, 마지막 쪽 50%)
  · 인쇄 안전 여백(종이 끝 5mm) 안쪽에만 글자 · 단어 중간 줄바꿈 0 · 마지막 줄 한 단어 0 · 개조식 끝 마침표 0
  · 벌어진 띄어쓰기(0.6em 초과) 0 · 한 줄 제목(h2·[data-oneline]) · 링크 대상 있음
  · 인쇄(PDF) 쪽 수 = 지면 수 · PDF 링크 도착 쪽 일치 · 화면과 인쇄 모양 일치(차이 0.5% 이하)
출력: 쪽별 PNG(s1.png…), 한눈에 보기(contact.png), PDF, 결과"""
import sys, os, re
from playwright.sync_api import sync_playwright
from PIL import Image
html, out = os.path.abspath(sys.argv[1]), sys.argv[2]
os.makedirs(out, exist_ok=True)
JS = r"""() => {
 const rg=document.createRange(), MM=96/25.4, R={pages:[],boxes:[],bleed:[],safe:[],midword:[],widow:[],period:[],gaps:[],titles:[],links:[],nlinks:0,dest:{}};
 const chars=el=>{const a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode())for(let i=0;i<n.data.length;i++)a.push([n,i]);return a;};
 const top=c=>{rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);const r=rg.getClientRects();return r.length?r[r.length-1].top:null;};
 document.querySelectorAll('.sheet').forEach(s=>{const p=+s.dataset.page,b=s.querySelector('.body');
   if(b){const br=b.getBoundingClientRect();let last=0;b.querySelectorAll(':scope>*').forEach(c=>{if(c.classList.contains('end'))return;last=Math.max(last,c.getBoundingClientRect().bottom);});
     R.pages.push({p,overflow:b.scrollHeight-b.clientHeight,fill:Math.round((last-br.top)/br.height*100),nofill:s.hasAttribute('data-nofill')});}
   else R.pages.push({p,nofill:true,overflow:0});
   s.querySelectorAll('[data-box]').forEach(x=>{const o=Math.max(x.scrollHeight-x.clientHeight,x.scrollWidth-x.clientWidth);if(o>1)R.boxes.push(p+'쪽 '+(x.dataset.box||x.className)+' '+o+'px');});
   const S0=s.getBoundingClientRect();s.querySelectorAll('*').forEach(x=>{const cs=getComputedStyle(x),bg=cs.backgroundColor,img=cs.backgroundImage;
     const colored=(img&&img!=='none')||(bg&&!/rgba\(\s*0,\s*0,\s*0,\s*0\)|transparent/.test(bg)&&!/rgb\(255,\s*255,\s*255\)/.test(bg));if(!colored)return;
     const r=x.getBoundingClientRect();if(!r.width||!r.height)return;const m=5*MM;
     if(r.left<S0.left+m||r.right>S0.right-m||r.top<S0.top+m||r.bottom>S0.bottom-m)R.bleed.push(p+'쪽 '+(x.className||x.tagName));});
   const S=s.getBoundingClientRect(),w=document.createTreeWalker(s,NodeFilter.SHOW_TEXT);let n;
   while(n=w.nextNode()){if(!n.data.trim()||n.parentElement.closest('[data-bleed]'))continue;rg.selectNodeContents(n);
     for(const r of rg.getClientRects()){if(!r.width)continue;if(r.left<S.left+5*MM||r.right>S.right-5*MM||r.top<S.top+5*MM||r.bottom>S.bottom-5*MM){R.safe.push(p+'쪽 '+n.data.trim().slice(0,12));break;}}}});
 const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
 while(n=w.nextNode()){if(n.data.trim().length<2)continue;let pt=null;
   for(let i=0;i<n.length;i++){const t=top([n,i]);if(t===null)continue;if(pt!==null&&t>pt+3){const a=n.data[i-1],c=n.data[i];if(/[가-힣A-Za-z0-9]/.test(a)&&/[가-힣A-Za-z0-9]/.test(c))R.midword.push(n.data.slice(Math.max(0,i-8),i)+'|'+n.data.slice(i,i+6));}pt=t;}}
 document.querySelectorAll('.sheet :is(p,li,td,td>div,dd,.fx):not([data-nowidow])').forEach(el=>{
   if(el.querySelector('br,div,ul,p,li'))return;const A=chars(el),txt=A.map(c=>c[0].data[c[1]]).join(''),e=txt.replace(/\s+$/,'').length-1;if(e<1)return;
   const th=parseFloat(getComputedStyle(el).fontSize)*.6,lt=top(A[e]);let s=e;while(s>0){if(/\s/.test(txt[s-1])){s--;continue;}const t=top(A[s-1]);if(t===null||Math.abs(t-lt)>th)break;s--;}
   if(s>0&&Math.abs(top(A[0])-lt)>th&&!/\s/.test(txt.slice(s,e+1).trim()))R.widow.push(txt.slice(s,e+1));});
 document.querySelectorAll('.sheet :is(li,.note,td>div,td:not(:has(div)),dd,[data-np])').forEach(el=>{let t='';el.childNodes.forEach(c=>{if(c.nodeName!=='UL')t+=c.textContent;});if(/[가-힣)]\.\s*$/.test(t))R.period.push(t.trim().slice(-20));});
 document.querySelectorAll('.sheet :is(p,li,dd,.fx)').forEach(el=>{if(getComputedStyle(el).textAlign!=='justify'||el.querySelector('ul,div,p,li'))return;const fs=parseFloat(getComputedStyle(el).fontSize),sp=[];const w2=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let m;
   while(m=w2.nextNode())for(let i=0;i<m.length;i++){if(m.data[i]!==' ')continue;rg.setStart(m,i);rg.setEnd(m,i+1);const rc=rg.getClientRects()[0];if(rc&&rc.width>0)sp.push([rc.width/fs,rc.top,m.data.slice(Math.max(0,i-10),i+10)]);}
   if(!sp.length)return;const lt=Math.max(...sp.map(x=>x[1]));sp.forEach(x=>{if(Math.abs(x[1]-lt)>2&&x[0]>.6)R.gaps.push(x[0].toFixed(2)+' '+x[2]);});});
 document.querySelectorAll('.sheet :is(h2,[data-oneline])').forEach(h=>{const A=chars(h).filter(c=>!/\s/.test(c[0].data[c[1]]));const T=A.map(top).filter(x=>x!==null);if(T.length&&Math.max(...T)-Math.min(...T)>parseFloat(getComputedStyle(h).fontSize)*.6)R.titles.push(h.textContent.trim().slice(0,40));});
 document.querySelectorAll('a[href^="#"]').forEach(a=>{R.nlinks++;const id=a.getAttribute('href').slice(1),t=document.getElementById(id);if(!t)R.links.push(a.textContent.trim()+' → #'+id);else R.dest[id]=+t.closest('.sheet').dataset.page;});
 return R;}"""
with sync_playwright() as p:
    try: br = p.chromium.launch()
    except Exception:
        br = p.chromium.launch(executable_path=next((x for x in ['/opt/pw-browsers/chromium', '/usr/bin/chromium', '/usr/bin/chromium-browser'] if os.path.exists(x)), None))
    pg = br.new_page(viewport={'width': 1300, 'height': 1200}, device_scale_factor=1.5)
    pg.goto('file://' + html); pg.wait_for_function("document.documentElement.dataset.fit==='done'", timeout=30000); pg.wait_for_timeout(250)
    R = pg.evaluate(JS)
    sheets = pg.query_selector_all('.sheet')
    for i, s in enumerate(sheets, 1): s.screenshot(path=f'{out}/s{i}.png')
    pdf = os.path.join(out, os.path.splitext(os.path.basename(html))[0] + '.pdf')
    pg.pdf(path=pdf, format='A4', print_background=True, prefer_css_page_size=True)
    br.close()
raw = open(pdf, 'rb').read()
pdf_links = len(re.findall(rb'/Subtype\s*/Link', raw))
pdf_pages, diffs = None, []
try:
    import pypdfium2 as pdfium
    from PIL import ImageChops, ImageFilter
    doc = pdfium.PdfDocument(pdf); pdf_pages = len(doc)
    for i in range(min(pdf_pages, len(sheets))):
        a = Image.open(f'{out}/s{i+1}.png').convert('L')
        b = doc[i].render(scale=a.width / doc[i].get_width()).to_pil().convert('L').resize(a.size)
        a2, b2 = [x.resize((x.width // 3, x.height // 3)).filter(ImageFilter.GaussianBlur(1)) for x in (a, b)]
        d = ImageChops.difference(a2, b2).point(lambda v: 255 if v > 48 else 0)
        diffs.append(round(d.histogram()[255] / (d.width * d.height) * 100, 3))
except ImportError:
    pdf_pages = len(re.findall(rb'/Type\s*/Page[^s]', raw))
ims = [Image.open(f'{out}/s{i}.png') for i in range(1, len(sheets) + 1)]
sc = 0.3; ims = [im.resize((int(im.width * sc), int(im.height * sc))) for im in ims]; w, h = ims[0].size
cols = min(3 if w > h else 4, len(ims)); rows = -(-len(ims) // cols)
sheet = Image.new('RGB', (cols * w + (cols - 1) * 10, rows * h + (rows - 1) * 10), '#777')
for i, im in enumerate(ims): sheet.paste(im, ((i % cols) * (w + 10), (i // cols) * (h + 10)))
sheet.save(f'{out}/contact.png')
fails = []
body = [x for x in R['pages'] if not x['nofill']]
for x in R['pages']:
    if x['overflow'] > 0: fails.append(f"{x['p']}쪽 넘침 {x['overflow']}px")
for i, x in enumerate(body):
    lim = 50 if x is R['pages'][-1] else 85
    if x['fill'] < lim: fails.append(f"{x['p']}쪽 채움 {x['fill']}% (<{lim}%)")
try:
    from pypdf import PdfReader
    rd = PdfReader(pdf); nd = {k.lstrip('/'): rd.get_destination_page_number(v) + 1 for k, v in rd.named_destinations.items()}
    for k, v in R['dest'].items():
        if nd.get(k) != v: fails.append(f"PDF 링크 {k}가 {nd.get(k)}쪽으로 감 (맞는 쪽 {v})")
except ImportError: pass
if pdf_pages != len(sheets): fails.append(f"인쇄 쪽 수 {pdf_pages} ≠ 지면 {len(sheets)}쪽")
if R['nlinks'] and pdf_links < R['nlinks']: fails.append(f"PDF 링크 {pdf_links}개 < 문서 링크 {R['nlinks']}개")
for i, v in enumerate(diffs, 1):
    if v > 0.5: fails.append(f"{i}쪽 화면과 인쇄 모양 다름 ({v}%)")
for k, label in [('boxes', '칸 넘침'), ('bleed', '색 면이 종이 끝 5mm 안까지 닿음(사무실 프린터에서 흰 테두리 박스로 출력됨)'), ('safe', '인쇄 안전 여백(5mm) 침범'), ('links', '이동할 곳 없는 링크'), ('midword', '단어 중간 줄바꿈'), ('widow', '마지막 줄 한 단어'), ('period', '끝 마침표'), ('gaps', '벌어진 띄어쓰기'), ('titles', '두 줄 제목')]:
    if R[k]: fails.append(f"{label} {len(R[k])}곳: {R[k][:6]}")
print('쪽별 채움:', ' '.join(f"{x['p']}쪽 {x['fill']}%" for x in body) or '(디자인 쪽만 있음)')
print('PDF:', pdf, '| 지면', len(sheets), '쪽 · 인쇄', pdf_pages, '쪽 · 링크', pdf_links, '개 · 화면/인쇄 차이(%)', diffs)
print('결과: 통과' if not fails else '결과: 고칠 곳\n - ' + '\n - '.join(fails))
````

## 파일 5: template.html

실제로 만든 예시 문서다. 구조·클래스·블록은 그대로 두고 제목·글·숫자만 바꾼다.

````html
<title>IN:AI 연구회 검토</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700;800;900&display=swap">
<style>
/*{{COMMON_CSS}}*/
/* ===== ② 컨설팅형 결론 중심 보고서: A4 가로, 쪽마다 '결론 문장 제목(액션 타이틀) 1개 + 근거 도표 1개' ===== */
@media print{@page{size:A4 landscape;margin:0}}
.cs .kick{position:absolute;left:16mm;right:16mm;top:21.5mm;display:flex;justify-content:space-between;align-items:center}
.cs .kick b{font-size:7.6pt;font-weight:800;color:var(--blue);letter-spacing:.2em}
.cs .kick b i{font-style:normal;color:var(--sub);font-weight:700;letter-spacing:.04em;margin-left:2mm}
.trk{display:flex}
.trk a{font-size:7.4pt;font-weight:700;color:var(--sub);padding:.5mm 2.6mm;border:.25mm solid var(--rule);margin-left:-.25mm;line-height:1.5}
.trk a.on{background:var(--navy);color:#fff;border-color:var(--navy)}
.at{position:absolute;left:16mm;right:16mm;top:27mm;height:20mm;display:flex;align-items:center;border-bottom:.7mm solid var(--navy);overflow:hidden}
.at h1{margin:0;font-size:16.5pt;font-weight:800;line-height:1.36;letter-spacing:-.03em;color:var(--ink)}
.at h1 em{color:var(--navy)}
.cs .body{position:absolute;left:16mm;right:16mm;top:52mm;bottom:20mm;display:flex;flex-direction:column;gap:4.5mm}
.src{position:absolute;left:16mm;bottom:8mm;font-size:7.6pt;color:var(--sub)}
.dn{position:absolute;right:16mm;bottom:8mm;font-size:7.6pt;color:var(--sub)}
.sub{font-size:9.4pt;font-weight:800;color:var(--navy);margin:0 0 2mm;display:flex;align-items:baseline;gap:2mm}
.sub small{font-size:7.8pt;color:var(--sub);font-weight:500}
ul.l{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2mm;font-size:9.6pt;line-height:1.55}
ul.l li{padding-left:4mm;position:relative;text-align:justify}
ul.l li::before{content:"";position:absolute;left:.5mm;top:.62em;width:1.4mm;height:1.4mm;background:var(--navy)}
ul.l b{color:var(--navy);font-weight:800}

/* 표지 */
.cvr .lp{position:absolute;inset:6mm auto 6mm 6mm;width:172mm;background:var(--navy);color:#fff;overflow:hidden}
.cvr .brand{position:absolute;left:10mm;top:9mm;display:flex;align-items:center;gap:3.2mm}
.cvr .brand img{height:9.5mm;display:block}
.cvr .brand span{font-size:8.6pt;font-weight:700;letter-spacing:.05em;border-left:.3mm solid rgba(255,255,255,.5);padding-left:3.2mm;line-height:1.4}
.cvr .ttl{position:absolute;left:16mm;right:30mm;top:66mm}
.cvr .pill{display:inline-block;background:var(--gold);color:var(--navy);font-size:8.6pt;font-weight:800;padding:.9mm 2.8mm;letter-spacing:.08em}
.cvr h1{margin:4.5mm 0 0;font-size:30pt;font-weight:900;line-height:1.2;letter-spacing:-.025em}
.cvr h1 .co{color:var(--gold)}
.cvr .subt{margin:4mm 0 0;font-size:11pt;color:var(--sky);font-weight:500}
.cvr .cx{width:26mm}
.cvr .issue{position:absolute;left:10mm;bottom:9mm;font-size:8pt;letter-spacing:.2em;color:var(--sky);font-weight:700}
.cvr .issue b{color:#fff;letter-spacing:.04em;margin-left:2.4mm}
.cvr .rp{position:absolute;left:190mm;right:16mm;top:16mm;bottom:13mm;display:flex;flex-direction:column;justify-content:space-between}
.cvr .grp{display:flex;flex-direction:column;gap:3.4mm}
.cvr .rh{font-size:7.6pt;font-weight:800;color:var(--blue);letter-spacing:.2em;border-bottom:.5mm solid var(--navy);padding-bottom:1.4mm}
.cvr ol{margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:3.4mm;counter-reset:k}
.cvr ol li{counter-increment:k;display:grid;grid-template-columns:7.4mm 1fr;font-size:10.2pt;font-weight:700;line-height:1.5}
.cvr ol li::before{content:counter(k);width:5.4mm;height:5.4mm;background:var(--navy);color:#fff;font-size:8.4pt;font-weight:800;display:flex;align-items:center;justify-content:center;margin-top:.3mm}
.cvr .meta{margin:0;display:grid;grid-template-columns:19mm 1fr;row-gap:1.8mm;font-size:9.2pt}
.cvr .meta dt{font-weight:800;color:var(--navy)}
.cvr .meta dd{margin:0;font-weight:500}
.cvr .toc a{display:flex;align-items:baseline;gap:2mm;padding:2.1mm 0;border-bottom:.2mm solid var(--rule);font-size:9.6pt}
.cvr .toc i{font-style:normal;font-weight:900;color:var(--navy);width:21mm;font-size:7.6pt;letter-spacing:.06em}
.cvr .toc span{font-weight:700}
.cvr .toc b{margin-left:auto;font-weight:500;color:var(--sub)}
.cvr .rf{font-size:8.6pt;font-weight:800;color:var(--navy);border-top:.25mm solid var(--rule);padding-top:2mm;text-align:right}

/* 요약: 상황-문제-해법 3단 */
.scr{display:grid;grid-template-columns:1fr 1fr 1fr;gap:5mm;flex:1}
.scr > div{border:.25mm solid var(--rule);border-top:1mm solid var(--navy);display:flex;flex-direction:column}
.scr > div.r{border-top-color:var(--gold);background:linear-gradient(var(--goldpale),#fff 30mm)}
.scr .sh{padding:3.6mm 5mm 3mm;border-bottom:.2mm solid var(--rule);display:flex;flex-direction:column;gap:1mm}
.scr .sh i{font-style:normal;font-size:7.4pt;font-weight:800;color:var(--blue);letter-spacing:.2em}
.scr .sh b{font-size:13pt;font-weight:900;color:var(--ink);letter-spacing:-.02em}
.scr ul.l{padding:4.4mm 5mm 4mm;gap:3.6mm;font-size:10.4pt;line-height:1.6}
.scr ul.l li{text-align:left}
.scr .kf{margin-top:auto;border-top:.2mm dashed var(--rule);padding:4.4mm 5mm 3.4mm;display:flex;align-items:baseline;gap:2.4mm}
.scr .kf strong{font-size:32pt;font-weight:900;color:var(--navy);line-height:1;letter-spacing:-.03em}
.scr .kf strong small{font-size:11pt;margin-left:.6mm}
.mini{display:flex;height:7mm;margin:0 5mm 5mm;font-size:7.8pt;font-weight:800;color:#fff}
.mini div{display:flex;align-items:center;justify-content:center;white-space:nowrap}
.mini.ln{gap:1.2mm;color:var(--navy)}
.mini.ln div{flex:1;border:.25mm solid var(--navy);background:#fff}
.mini.ln div.g{border:.35mm dashed var(--gold);background:var(--goldpale)}
.mini.ln div.y{background:var(--navy);color:#fff}
.scr .kf span{font-size:8.8pt;font-weight:700;color:var(--sub);line-height:1.4}
.scr .kf .chain{font-size:15pt;font-weight:900;color:var(--navy);letter-spacing:-.01em}
.scr .kf .chain i{font-style:normal;color:var(--gold);margin:0 1.4mm}
.ask{display:grid;grid-template-columns:24mm 1fr;border:.3mm solid var(--navy)}
.ask > b{background:var(--navy);color:#fff;font-size:10pt;font-weight:800;letter-spacing:.2em;display:flex;align-items:center;justify-content:center}
.ask > div{background:var(--pale);display:grid;grid-template-columns:repeat(3,1fr)}
.ask > div > div{display:grid;grid-template-columns:7mm 1fr;align-items:start;padding:3.4mm 4mm;border-left:.2mm solid var(--rule)}
.ask > div > div:first-child{border-left:0}
.ask i{font-style:normal;width:5.2mm;height:5.2mm;background:var(--gold);color:var(--navy);font-size:8.4pt;font-weight:900;display:flex;align-items:center;justify-content:center;margin-top:.4mm}
.ask p{display:flex;flex-direction:column;gap:.6mm}
.ask p b{font-size:10pt;font-weight:800;color:var(--navy)}
.ask p span{font-size:8.8pt;font-weight:500;color:var(--sub)}

/* 근거 1: 막대 + 연간 예상 + 공백 흐름 */
.ex1{display:grid;grid-template-columns:1.25fr 1fr;gap:9mm;flex:1}
.hbar{display:flex;flex-direction:column;gap:2.6mm;border-top:.5mm solid var(--navy);padding-top:3mm}
.hbar > div{display:grid;grid-template-columns:52mm 1fr;align-items:center;gap:3mm;font-size:9pt;font-weight:700}
.hbar .tr{height:7.5mm;background:var(--zebra);position:relative}
.hbar .tr i{position:absolute;inset:0 auto 0 0;background:var(--blue);display:flex;align-items:center;justify-content:flex-end;padding-right:2mm;color:#fff;font-style:normal;font-weight:900;font-size:9.6pt}
.hbar .hi .tr i{background:var(--navy)}
.hbar .tot{border-top:.25mm solid var(--rule);padding-top:2.4mm;font-weight:800;color:var(--navy)}
.hbar .tot strong{font-size:15pt;font-weight:900}
.yr{border:.25mm solid var(--rule);border-top:.5mm solid var(--navy);padding:3mm 4mm;display:flex;flex-direction:column;gap:2mm}
.yr .big{display:flex;align-items:baseline;gap:2mm}
.yr .big strong{font-size:40pt;font-weight:900;color:var(--navy);line-height:1;letter-spacing:-.03em}
.yr .big span{font-size:12pt;font-weight:800;color:var(--navy)}
.yr .big em{font-size:8.6pt;color:var(--sub);margin-left:auto;font-weight:500}
.stk{display:flex;height:8mm;font-size:8.2pt;font-weight:800;color:#fff}
.stk div{display:flex;align-items:center;justify-content:center}
.flow{display:grid;grid-template-columns:1fr 6mm 1fr 6mm 1fr;align-items:stretch;margin-top:1mm}
.flow > div{border:.25mm solid var(--navy);padding:4mm 2.2mm;text-align:center;font-size:8.6pt;font-weight:700;line-height:1.4;display:flex;flex-direction:column;justify-content:center;gap:.6mm}
.flow > div i{font-style:normal;font-size:7.2pt;color:var(--blue);letter-spacing:.12em;font-weight:800}
.flow > div.gap{border:.4mm dashed var(--gold);background:var(--goldpale);color:var(--ink)}
.flow > span{display:flex;align-items:center;justify-content:center;color:var(--navy);font-weight:900;font-size:11pt}
.sowhat{display:grid;grid-template-columns:28mm 1fr;background:var(--navy);color:#fff;align-items:center}
.sowhat b{font-size:8pt;letter-spacing:.2em;color:var(--gold);font-weight:800;padding:3mm 0 3mm 5mm}
.sowhat p{font-size:10.4pt;font-weight:700;padding:3mm 5mm 3mm 0}

/* 근거 2: 3단계 흐름 + 지금/앞으로 표 */
.steps{display:grid;grid-template-columns:1fr 9mm 1fr 9mm 1fr;align-items:stretch}
.steps > span{display:flex;align-items:center;justify-content:center}
.steps > span::after{content:"";border-left:3.4mm solid var(--navy);border-top:3mm solid transparent;border-bottom:3mm solid transparent}
.st{border:.25mm solid var(--rule);display:flex;flex-direction:column}
.st .sh{background:var(--mist);padding:2.6mm 4mm;display:flex;align-items:baseline;gap:2.4mm}
.st.mid .sh{background:var(--navy);color:#fff}
.st .sh i{font-style:normal;font-size:7.4pt;font-weight:800;letter-spacing:.18em;color:var(--blue)}
.st.mid .sh i{color:var(--gold)}
.st .sh b{font-size:12pt;font-weight:900}
.st .sh small{font-size:8.6pt;font-weight:700;margin-left:auto;opacity:.9}
.st ul.l{padding:3.6mm 4.4mm 3.8mm;gap:2.4mm;font-size:9.8pt}
.st .role{margin-top:auto;border-top:.2mm dashed var(--rule);padding:2mm 4mm;font-size:8.2pt;color:var(--sub);display:grid;grid-template-columns:auto 1fr;column-gap:2mm;row-gap:.6mm}
.st .role b{color:var(--navy);font-weight:800}
.cmp td{padding-block:2.3mm;font-size:9.4pt}.cmp td.now{color:var(--sub)}
.cmp td.next{font-weight:700;color:var(--navy);background:var(--pale)!important}
.cmp th.next{background:var(--navy);color:#fff}

/* 근거 3: 대안 비교(하비 볼) */
.opt{display:grid;grid-template-columns:47mm 1fr 1fr 1fr;grid-template-rows:auto repeat(5,1fr);border-top:.5mm solid var(--navy);flex:1}
.opt > div{padding:2.4mm 3.4mm;border-bottom:.2mm solid var(--rule);font-size:9pt;display:flex;align-items:center;gap:2.4mm}
.opt .oh{background:var(--mist);font-weight:800;color:var(--navy);flex-direction:column;align-items:flex-start;gap:.6mm;justify-content:center}
.opt .oh i{font-style:normal;font-size:7.2pt;letter-spacing:.16em;color:var(--blue)}
.opt .oh b{font-size:11pt}
.opt .oh.rec{background:var(--navy);color:#fff}
.opt .oh.rec i{color:var(--gold)}
.opt .lab{font-weight:800;color:var(--ink);background:var(--zebra);flex-direction:column;align-items:flex-start;justify-content:center;gap:.4mm}
.hb[style*="--v:100"]{background:var(--navy)}
.opt .lab small{display:block;font-size:7.6pt;font-weight:500;color:var(--sub)}
.opt .rc{background:var(--pale)}
.opt .ds{font-size:8.8pt;line-height:1.5;align-items:flex-start;color:var(--sub)}
.opt .ds.rc{color:var(--ink);font-weight:500}
.hb{width:5.4mm;height:5.4mm;border-radius:50%;border:.35mm solid var(--navy);background:conic-gradient(var(--navy) calc(var(--v)*1%),#fff 0);flex:none}
.opt .tx{font-size:8.6pt;color:var(--sub)}
.legend{display:flex;gap:5mm;font-size:7.8pt;color:var(--sub);align-items:center}
.legend span{display:flex;align-items:center;gap:1.4mm}
.legend .hb{width:3.8mm;height:3.8mm}
.ex3{display:grid;grid-template-columns:1fr 78mm;gap:7mm;flex:1}
.frame{border:.3mm solid var(--gold);background:linear-gradient(var(--goldpale),#fff 26mm);padding:3.4mm 4.4mm;display:flex;flex-direction:column;gap:2.4mm}
.frame h3{margin:0;font-size:10.4pt;font-weight:900;color:var(--navy);display:flex;align-items:center;gap:2mm}
.frame h3::before{content:"C";width:5.4mm;height:5.4mm;background:var(--navy);color:#fff;font-size:8.6pt;display:flex;align-items:center;justify-content:center}
.frame dl{margin:0;display:grid;grid-template-columns:13mm 1fr;row-gap:2.2mm;font-size:9pt;line-height:1.5}
.frame dt{font-weight:800;color:var(--navy)}
.frame dd{margin:0;text-align:left}
.frame h4{margin:1.2mm 0 0;padding-top:2.6mm;border-top:.25mm dashed var(--gold);font-size:9.6pt;font-weight:900;color:var(--navy)}
.frame ul.fe{font-size:9pt;gap:1.6mm}
.frame ul.fe li{text-align:left}
.frame ul.fe b{margin-right:1.4mm}

/* 근거 4: 추진 일정(간트) */
.gt{display:grid;grid-template-columns:64mm repeat(9,1fr);border-top:.5mm solid var(--navy);font-size:8.6pt}
.gt > div{border-bottom:.2mm solid var(--rule);border-left:.2mm dotted var(--rule);min-height:10.6mm;display:flex;align-items:center;position:relative}
.gt .mh{background:var(--mist);font-weight:800;color:var(--navy);justify-content:center;min-height:7mm;font-size:8.2pt}
.gt .mh.y{background:var(--navy);color:#fff}
.gt .tk{border-left:0;padding:0 2.4mm;font-weight:700;gap:2mm}
.gt .tk i{font-style:normal;width:4.6mm;height:4.6mm;background:var(--navy);color:#fff;font-size:7.6pt;font-weight:800;display:flex;align-items:center;justify-content:center;flex:none}
.gt .tk.done i{background:var(--gray)}
.gt .b{position:absolute;top:2.8mm;bottom:2.8mm;background:var(--blue);display:flex;align-items:center;padding-left:1.6mm;color:#fff;font-size:7.6pt;font-weight:700;white-space:nowrap;z-index:1}
.gt .b.done{background:var(--gray)}
.gt .b.gold{background:var(--gold);color:var(--navy)}
.gt .now{position:absolute;top:0;bottom:0;width:.5mm;background:var(--gold);z-index:2}
.cs .end{margin-top:auto}
</style>

<div class="doc"><div class="stack">

<!-- ===== 1. 표지 ===== -->
<section class="sheet land cs cvr" data-page="1">
  <div class="lp">
    <img class="cx tr" src="{{CHEV_TR}}" alt=""><img class="cx bl" src="{{CHEV_BL}}" alt="">
    <div class="brand"><img src="{{LOGO_WHITE}}" alt="INU"><span>인천대학교<br>산학협력단</span></div>
    <div class="ttl">
      <span class="pill">검토 보고</span>
      <h1>IN<span class="co">:</span>AI 프런티어 연구회<br>추진 검토(안)</h1>
      <p class="subt">가족회사 AI 교육을 기업 안의 실무 역량으로 잇는 방안</p>
    </div>
    <div class="issue">REPORT<b>2026. 10. 22.</b></div>
  </div>
  <div class="rp">
   <div class="grp">
    <div class="rh">보고 요지</div>
    <ol>
      <li>가족회사 AI 교육 수요는 확인됨 — 상반기 127명, 연간 319명 예상</li>
      <li>하루 과정 중심이라 교육 이후 현장 정착을 받쳐 줄 장치가 비어 있음</li>
      <li>2027년 ‘IN:AI 프런티어 연구회’로 교육과 현장을 잇는 혼합형 운영을 건의</li>
    </ol>
    <dl class="meta">
      <dt>보고 부서</dt><dd>산학협력단 산학협력팀</dd>
      <dt>관련 회의</dt><dd>산학협력중점교수 회의(2026. 10. 19.)</dd>
      <dt>출발점</dt><dd>유료 가족회사 간담회(2026. 10. 14.) 제안</dd>
    </dl>
   </div>
   <div class="grp">
    <div class="rh">CONTENTS</div>
    <div class="toc">
      <a class="lk" href="#p2"><i>SUMMARY</i><span>한 장 요약</span><b>2</b></a>
      <a class="lk" href="#p3"><i>EXHIBIT 1</i><span>현황 진단</span><b>3</b></a>
      <a class="lk" href="#p4"><i>EXHIBIT 2</i><span>해법 구조</span><b>4</b></a>
      <a class="lk" href="#p5"><i>EXHIBIT 3</i><span>운영 방식 비교</span><b>5</b></a>
      <a class="lk" href="#p6"><i>EXHIBIT 4</i><span>추진 계획 및 건의</span><b>6</b></a>
    </div>
   </div>
    <div class="rf">인천대학교 산학협력단 산학협력팀</div>
  </div>
</section>

<!-- ===== 2. 한 장 요약 ===== -->
<section class="sheet land cs" data-page="2" id="p2">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="kick"><b>EXECUTIVE SUMMARY<i>한 장 요약</i></b>
    <nav class="trk"><a class="lk on" href="#p2">요약</a><a class="lk" href="#p3">현황</a><a class="lk" href="#p4">해법</a><a class="lk" href="#p5">운영안</a><a class="lk" href="#p6">추진 계획</a></nav></div>
  <div class="at" data-box="결론 제목"><h1 class="fx">교육으로 쌓은 가족회사 AI 협력을 2027년 <em>‘IN:AI 프런티어 연구회’</em>로 이어, 기업 안에 AI 실무 리더를 키우는 방안을 건의</h1></div>
  <div class="body">
    <div class="scr">
      <div><div class="sh"><i>SITUATION · 상황</i><b>교육 수요는 충분히 확인됨</b></div>
        <ul class="l">
          <li>상반기 단계별 과정·AX 아카데미·CEO 특강 수강 <b>127명</b></li>
          <li>하반기 초급(9. 30.)·중급(10. 28.)·고급(11. 25.) 운영으로 연간 <b>319명</b> 예상</li>
          <li>8월 CEO 특강 반응에 힘입어 10. 26. 추가 회차 개설</li>
        </ul>
        <div class="kf"><strong>319<small>명</small></strong><span>2026년<br>연간 수강 예상</span></div>
        <div class="mini"><div style="width:39.8%;background:var(--navy)">상반기 127</div><div style="width:60.2%;background:var(--steel)">하반기 예정 192</div></div></div>
      <div><div class="sh"><i>COMPLICATION · 문제</i><b>교육 이후를 받칠 장치가 없음</b></div>
        <ul class="l">
          <li>하루 과정 중심이라 회사 복귀 뒤 지속 학습·업무 적용 지원이 끊김</li>
          <li>상반기와 같은 내용이 되풀이되면 다시 듣는 기업의 관심이 떨어질 우려</li>
          <li>교육 성과가 수강자 개인에 머물러 기업 내부 확산으로 이어지기 어려움</li>
        </ul>
        <div class="kf"><strong>1<small>일</small></strong><span>교육은 하루로 끝나고<br>그 뒤를 잇는 과정 없음</span></div>
        <div class="mini ln"><div>교육 당일</div><div>회사 복귀</div><div class="g">공백</div></div></div>
      <div class="r"><div class="sh"><i>RESOLUTION · 해법</i><b>기업별 실무자 연구회로 연결</b></div>
        <ul class="l">
          <li>10. 14. 간담회 초청 강사가 제안한 ‘기업별 AI 프런티어 실무자 연구회’를 사업화</li>
          <li>산학협력단이 판을 깔고 기업 실무자가 과제를 끌고 가는 <b>혼합형</b> 운영</li>
          <li>「IN:AI」 이름으로 교육·연구회·확산을 하나의 체계로 묶어 브랜드화</li>
        </ul>
        <div class="kf"><span class="chain">배움<i>›</i>연결<i>›</i>확산</span></div>
        <div class="mini ln"><div>단계별 교육</div><div class="y">IN:AI 연구회</div><div>기업 내 정착</div></div></div>
    </div>
    <div class="ask"><b>건 의</b><div>
      <div><i>1</i><p><b>2027년 운영 예산 반영 검토</b><span>세부 운영 계획(안) 수립 뒤 예산 편성 협의</span></p></div>
      <div><i>2</i><p><b>외부 지원금 연계 가능성 검토</b><span>「2026 블록체인 상생협의체」 사례 참고</span></p></div>
      <div><i>3</i><p><b>연구회 명칭 사용</b><span>「IN:AI 프런티어 연구회(가칭)」로 브랜드화</span></p></div>
    </div></div>
  </div>
  <div class="src">자료: 산학협력팀 2026년 가족회사 AI 교육 운영 실적·계획, 유료 가족회사 간담회(2026. 10. 14.) 논의</div>
  <div class="ft">- 2 -</div><div class="dn">IN:AI 프런티어 연구회 추진 검토(안)</div>
</section>

<!-- ===== 3. 근거 1: 현황 진단 ===== -->
<section class="sheet land cs" data-page="3" id="p3">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="kick"><b>EXHIBIT 1<i>현황 진단</i></b>
    <nav class="trk"><a class="lk" href="#p2">요약</a><a class="lk on" href="#p3">현황</a><a class="lk" href="#p4">해법</a><a class="lk" href="#p5">운영안</a><a class="lk" href="#p6">추진 계획</a></nav></div>
  <div class="at" data-box="결론 제목"><h1 class="fx">AI 교육은 상반기에만 <em>127명</em>이 들을 만큼 수요가 확인됐지만, 하루 과정 중심이라 현장 정착으로 이어질 장치가 비어 있음</h1></div>
  <div class="body">
    <div class="ex1">
      <div>
        <p class="sub">상반기 과정별 수강 인원<small>단위: 명, 2026. 1.~6.</small></p>
        <div class="hbar">
          <div><span>초급 과정</span><div class="tr"><i style="width:56.4%">22</i></div></div>
          <div><span>중급 과정</span><div class="tr"><i style="width:59%">23</i></div></div>
          <div><span>고급 과정</span><div class="tr"><i style="width:46.2%">18</i></div></div>
          <div class="hi"><span>AX전환 재직자 혁신 아카데미</span><div class="tr"><i style="width:100%">39</i></div></div>
          <div class="hi"><span>인천비전기업협회 CEO 특강</span><div class="tr"><i style="width:64.1%">25</i></div></div>
          <div class="tot"><span>합계</span><span><strong>127</strong>명 · 단계별 과정 63명 + 아카데미·특강 64명</span></div>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;justify-content:space-between;gap:4mm">
        <div class="yr">
          <p class="sub" style="margin:0">연간 수강 예상</p>
          <div class="big"><strong>319</strong><span>명</span><em>2026년 전체</em></div>
          <div class="stk"><div style="width:39.8%;background:var(--navy)">상반기 실적 127</div><div style="width:60.2%;background:var(--steel)">하반기 예정 192</div></div>
        </div>
        <div>
          <p class="sub">교육 이후의 흐름<small>지금 구조</small></p>
          <div class="flow">
            <div><i>DAY 1</i>교육 당일<br>8시간 실습</div><span>›</span>
            <div><i>NEXT</i>회사 복귀<br>업무 재개</div><span>›</span>
            <div class="gap"><i>GAP</i>지속 학습·적용<br>지원 장치 없음</div>
          </div>
        </div>
      </div>
    </div>
    <div class="sowhat"><b>SO WHAT</b><p>수요는 충분함 — 다음 과제는 ‘한 번 듣고 끝나는 교육’을 ‘회사 안에서 계속 이어지는 학습’으로 바꾸는 것</p></div>
  </div>
  <div class="src">자료: 산학협력팀 2026년 상반기 교육 운영 실적, 하반기 운영 계획(연간 예상치는 하반기 예정 인원 포함)</div>
  <div class="ft">- 3 -</div><div class="dn">IN:AI 프런티어 연구회 추진 검토(안)</div>
</section>

<!-- ===== 4. 근거 2: 해법 구조 ===== -->
<section class="sheet land cs" data-page="4" id="p4">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="kick"><b>EXHIBIT 2<i>해법 구조</i></b>
    <nav class="trk"><a class="lk" href="#p2">요약</a><a class="lk" href="#p3">현황</a><a class="lk on" href="#p4">해법</a><a class="lk" href="#p5">운영안</a><a class="lk" href="#p6">추진 계획</a></nav></div>
  <div class="at" data-box="결론 제목"><h1 class="fx">교육과 현장 사이를 <em>‘연구회’</em>로 이어, 배운 사람이 회사 안에서 AI 활용을 이끄는 구조로 전환</h1></div>
  <div class="body">
    <div class="steps">
      <div class="st"><div class="sh"><i>STEP 1</i><b>배움</b><small>단계별 교육</small></div>
        <ul class="l"><li>초급·중급·고급 하루 집중 실습</li><li>CEO 특강으로 경영진 공감대 형성</li><li>수료자 가운데 프런티어 실무자 후보 발굴</li></ul>
        <div class="role"><b>대학</b><span>교육 과정 운영</span><b>기업</b><span>수강자 파견</span></div></div>
      <span></span>
      <div class="st mid"><div class="sh"><i>STEP 2</i><b>연결</b><small>IN:AI 프런티어 연구회</small></div>
        <ul class="l"><li>기업별 프런티어 실무자가 정기 모임에 참여</li><li>자사 업무 과제를 가져와 사례 공유·해결</li><li>중점교수·외부 전문가 자문 연결</li></ul>
        <div class="role"><b>대학</b><span>교류의 장·전문가 연결</span><b>기업</b><span>실무자 지정·과제 제시</span></div></div>
      <span></span>
      <div class="st"><div class="sh"><i>STEP 3</i><b>확산</b><small>기업 내 정착</small></div>
        <ul class="l"><li>프런티어 실무자가 사내에 전파·업무에 적용</li><li>우수 사례를 간담회·뉴스레터로 공유</li><li>다음 해 교육 과정 설계에 현장 요구 반영</li></ul>
        <div class="role"><b>대학</b><span>성과 발굴·홍보</span><b>기업</b><span>사내 확산 주도</span></div></div>
    </div>
    <div>
      <p class="sub">지금과 앞으로<small>교육 중심 → 교육 + 연구회</small></p>
      <table class="cmp"><colgroup><col style="width:44mm"><col><col></colgroup>
        <thead><tr><th>구 분</th><th>지금(교육 중심)</th><th class="next">앞으로(교육 + IN:AI 연구회)</th></tr></thead>
        <tbody>
          <tr><td class="h">학습 방식</td><td class="now">하루 집중 실습 후 종료</td><td class="next">교육 뒤 정기 모임으로 이어지는 학습</td></tr>
          <tr><td class="h">참여 단위</td><td class="now">개인 수강자</td><td class="next">기업별 프런티어 실무자</td></tr>
          <tr><td class="h">성과 범위</td><td class="now">수강자 개인 역량</td><td class="next">기업 업무 개선 과제와 사내 확산</td></tr>
          <tr><td class="h">대학 역할</td><td class="now">교육 운영</td><td class="next">교육 운영 + 연구회 운영·기업 간 연결</td></tr>
        </tbody></table>
    </div>
    <div class="sowhat"><b>SO WHAT</b><p>성과 기준이 ‘몇 명이 들었나’에서 ‘기업 안에서 무엇이 바뀌었나’로 옮겨 감</p></div>
  </div>
  <div class="src">자료: 유료 가족회사 간담회(2026. 10. 14.) 초청 강사 제안 내용을 산학협력팀이 정리</div>
  <div class="ft">- 4 -</div><div class="dn">IN:AI 프런티어 연구회 추진 검토(안)</div>
</section>

<!-- ===== 5. 근거 3: 운영 방식 비교 ===== -->
<section class="sheet land cs" data-page="5" id="p5">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="kick"><b>EXHIBIT 3<i>운영 방식 비교</i></b>
    <nav class="trk"><a class="lk" href="#p2">요약</a><a class="lk" href="#p3">현황</a><a class="lk" href="#p4">해법</a><a class="lk on" href="#p5">운영안</a><a class="lk" href="#p6">추진 계획</a></nav></div>
  <div class="at" data-box="결론 제목"><h1 class="fx">운영 방식은 산학협력단이 판을 깔고 기업 실무자가 과제를 끌고 가는 <em>‘혼합형’</em>이 가장 현실적</h1></div>
  <div class="body">
    <div class="ex3">
      <div style="display:flex;flex-direction:column;gap:2.6mm">
        <div class="opt">
          <div class="oh" style="background:#fff"></div>
          <div class="oh"><i>OPTION A</i><b>대학 주도 세미나형</b></div>
          <div class="oh"><i>OPTION B</i><b>기업 자율 연구회형</b></div>
          <div class="oh rec"><i>OPTION C · 권고</i><b>혼합형</b></div>
          <div class="lab">운영 방식</div>
          <div class="ds">산학협력단이 주제·강사를 정해 정기 세미나 개최</div>
          <div class="ds">기업별 실무자가 모임을 스스로 꾸리고 운영</div>
          <div class="ds rc">산학협력단이 교류의 장을 열고, 실무자가 자사 과제를 들고 참여</div>
          <div class="lab">기업 참여 지속성</div><div><i class="hb" style="--v:50"></i><span class="tx">강의 듣고 이탈 쉬움</span></div><div><i class="hb" style="--v:25"></i><span class="tx">구심점 없으면 흐지부지</span></div><div class="rc"><i class="hb" style="--v:100"></i><span class="tx">대학 일정 + 자사 과제</span></div>
          <div class="lab">현장 과제 연결</div><div><i class="hb" style="--v:25"></i><span class="tx">공통 주제 위주</span></div><div><i class="hb" style="--v:100"></i><span class="tx">자사 과제 중심</span></div><div class="rc"><i class="hb" style="--v:75"></i><span class="tx">자사 과제를 함께 다룸</span></div>
          <div class="lab">운영 부담<small>원이 찰수록 부담이 적음</small></div><div><i class="hb" style="--v:25"></i><span class="tx">기획·섭외 모두 대학</span></div><div><i class="hb" style="--v:100"></i><span class="tx">대학 부담 거의 없음</span></div><div class="rc"><i class="hb" style="--v:50"></i><span class="tx">장 운영만 대학</span></div>
          <div class="lab">성과 확인</div><div><i class="hb" style="--v:75"></i><span class="tx">출석·만족도로 확인</span></div><div><i class="hb" style="--v:25"></i><span class="tx">대학이 파악하기 어려움</span></div><div class="rc"><i class="hb" style="--v:75"></i><span class="tx">과제 결과로 확인</span></div>
        </div>
        <div class="legend"><span><i class="hb" style="--v:100"></i>매우 유리</span><span><i class="hb" style="--v:75"></i>유리</span><span><i class="hb" style="--v:50"></i>보통</span><span><i class="hb" style="--v:25"></i>불리</span></div>
      </div>
      <div class="frame">
        <h3>혼합형 운영 골격(안)</h3>
        <dl>
          <dt>참여</dt><dd>가족회사별 프런티어 실무자 지정, 단계별 교육 수료자 우선</dd>
          <dt>방식</dt><dd>정기 교류 모임 + 기업별 업무 과제 수행</dd>
          <dt>지원</dt><dd>산학협력단이 일정·장소·전문가를 연결하고 중점교수가 자문</dd>
          <dt>확산</dt><dd>우수 과제를 가족회사 간담회·월간 뉴스레터로 공유</dd>
          <dt>브랜드</dt><dd>「IN:AI」 이름 아래 교육·연구회를 한 체계로 운영</dd>
        </dl>
        <h4 class="fx2">기대 효과</h4>
        <ul class="l fe">
          <li><b>기업</b> 사내에서 AI 활용을 이끌 실무 리더 확보</li>
          <li><b>대학</b> 가족회사와의 관계를 교육 이후까지 지속</li>
          <li><b>교육</b> 현장 과제가 다음 과정 설계로 되돌아옴</li>
        </ul>
        <p class="note" style="margin-top:auto">※ 비교 평가는 담당 부서 실무 검토 의견(안)으로, 중점교수 회의 논의 결과에 따라 조정</p>
      </div>
    </div>
  </div>
  <div class="src">자료: 산학협력팀 실무 검토</div>
  <div class="ft">- 5 -</div><div class="dn">IN:AI 프런티어 연구회 추진 검토(안)</div>
</section>

<!-- ===== 6. 근거 4: 추진 계획 및 건의 ===== -->
<section class="sheet land cs" data-page="6" id="p6">
  <div class="hd"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교 산학협력단 산학협력팀</span></div>
  <div class="kick"><b>EXHIBIT 4<i>추진 계획 및 건의</i></b>
    <nav class="trk"><a class="lk" href="#p2">요약</a><a class="lk" href="#p3">현황</a><a class="lk" href="#p4">해법</a><a class="lk" href="#p5">운영안</a><a class="lk on" href="#p6">추진 계획</a></nav></div>
  <div class="at" data-box="결론 제목"><h1 class="fx">중점교수 회의 논의를 출발점으로 <em>2027년 예산 반영</em>과 외부 재원 검토를 함께 진행해, 상반기 시범 운영을 목표로 함</h1></div>
  <div class="body">
    <div>
      <p class="sub">추진 일정(안)<small>2026. 10.~2027. 6.</small></p>
      <div class="gt">
        <div class="mh" style="border-left:0">추진 과제</div>
        <div class="mh y">'26. 10.</div><div class="mh y">11.</div><div class="mh y">12.</div>
        <div class="mh">'27. 1.</div><div class="mh">2.</div><div class="mh">3.</div><div class="mh">4.</div><div class="mh">5.</div><div class="mh">6.</div>

        <div class="tk done"><i>1</i>산학협력중점교수 회의 안건 논의</div>
        <div><span class="b done" style="left:0;width:100%">10. 19.</span><span class="now" style="left:70%"></span></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>

        <div class="tk"><i>2</i>세부 운영 계획(안) 수립</div>
        <div><span class="now" style="left:70%"></span></div><div><span class="b" style="left:0;width:100%">계획(안)</span></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>

        <div class="tk"><i>3</i>2027년 운영 예산 반영</div>
        <div><span class="now" style="left:70%"></span></div><div><span class="b" style="left:0;width:200%">예산 편성 협의</span></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>

        <div class="tk"><i>4</i>외부 지원금 연계 검토</div>
        <div><span class="now" style="left:70%"></span></div><div><span class="b" style="left:0;width:300%">유사 사업 사례 조사·협의</span></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div>

        <div class="tk"><i>5</i>참여 기업·프런티어 실무자 모집</div>
        <div><span class="now" style="left:70%"></span></div><div></div><div></div><div></div><div><span class="b" style="left:0;width:200%">모집·지정</span></div><div></div><div></div><div></div><div></div>

        <div class="tk"><i>6</i>IN:AI 연구회 시범 운영</div>
        <div><span class="now" style="left:70%"></span></div><div></div><div></div><div></div><div></div><div></div><div><span class="b gold" style="left:0;width:300%">시범 운영·성과 점검</span></div><div></div><div></div>
      </div>
      <div class="legend" style="margin-top:1.8mm"><span><i style="width:5mm;height:2.4mm;background:var(--gray);display:inline-block"></i>완료</span><span><i style="width:5mm;height:2.4mm;background:var(--blue);display:inline-block"></i>준비</span><span><i style="width:5mm;height:2.4mm;background:var(--gold);display:inline-block"></i>운영</span><span><i style="width:.6mm;height:3.4mm;background:var(--gold);display:inline-block"></i>보고일(2026. 10. 22.)</span></div>
    </div>
    <div class="ask"><b>건 의</b><div>
      <div><i>1</i><p><b>2027년 운영 예산 반영 검토</b><span>세부 운영 계획(안) 수립 뒤 예산 편성 협의</span></p></div>
      <div><i>2</i><p><b>외부 지원금 연계 가능성 검토</b><span>「2026 블록체인 상생협의체」 사례 참고</span></p></div>
      <div><i>3</i><p><b>연구회 명칭 사용</b><span>「IN:AI 프런티어 연구회(가칭)」로 브랜드화</span></p></div>
    </div></div>
    <div class="end">— 끝 —</div>
  </div>
  <div class="src">자료: 산학협력팀 추진 계획(안) — 세부 일정은 회의 논의와 예산 편성 결과에 따라 조정</div>
  <div class="ft">- 6 -</div><div class="dn">IN:AI 프런티어 연구회 추진 검토(안)</div>
</section>

</div></div>

<script>
/* 표지 꺾쇠: 위 꺾쇠는 제목 오른쪽 위, 아래 꺾쇠는 부제 아래 왼쪽(지면형 보고서 E안과 같은 방식) */
(function(){function place(){var lp=document.querySelector('.cvr .lp');if(!lp)return;var h=lp.querySelector('h1'),sub=lp.querySelector('.subt'),tr=lp.querySelector('.cx.tr'),bl=lp.querySelector('.cx.bl');
 var T=lp.getBoundingClientRect(),z=(T.width/lp.offsetWidth)||1,mm=96/25.4,r=document.createRange();r.selectNodeContents(h);
 var R=[].slice.call(r.getClientRects()),right=Math.max.apply(null,R.map(function(x){return x.right;})),tp=Math.min.apply(null,R.map(function(x){return x.top;})),S=sub.getBoundingClientRect();
 tr.style.left=((right-T.left)/z+15*mm-26*mm)+'px';tr.style.top=((tp-T.top)/z-8*mm)+'px';bl.style.left=(3*mm)+'px';bl.style.top=((S.bottom-T.top)/z+10*mm-26*mm)+'px';}
 place();if(document.fonts&&document.fonts.ready)document.fonts.ready.then(place);})();
</script>
<!--{{FIT_JS}}-->
````