---
name: "inu-print-factsheet"
description: "INU 지면 패밀리 · 팩트시트 — 교육·사업·행사를 A4 한 장(큰 숫자 4칸·일정·비용·QR)에 담은 인쇄용 HTML·PDF. '팩트시트', '한 장 요약', '안내 한 장', '배포용 한 장' 요청에 사용."
---

# INU 팩트시트 (INU 지면 패밀리)

교육·사업·행사 하나를 **A4 세로 한 장**에 담는 인쇄용 HTML·PDF를 만든다. 기관 방문 때 건네는 자료, 교육 안내, 사업 소개 한 장, 홍보물 대용으로 쓴다. 지면형 보고서(inu-print-report)와 같은 바탕 위에서, 읽는 문서가 아니라 **훑어보는 문서**로 짠다: 큰 숫자 4개, 일정, 비용, 구성, 신청 방법.

시작점: 2026. 10. 「2026 하반기 AI·AX 역량강화 교육」 팩트시트(템플릿 = 그 실제 문서). 사용자 반응: "이런 거 홍보 브로셔로도 써도 되겠다."

산출물: 완성 HTML, 같은 HTML을 A4로 인쇄한 PDF(1쪽).

## 지면 구조 (위→아래, 템플릿 그대로)

- **네이비 면(`.top`)**: 종이 끝에서 6mm 안쪽(`inset:6mm 6mm auto`), 높이 72mm.
  - 왼쪽 위: 흰 로고 + "인천대학교 산학협력단 / 산학협력팀".
  - 오른쪽 위: `FACT SHEET` + 발행 월(예: 2026. 10.).
  - 분류 pill(골드 바탕, 예: '가족회사 재직자 교육') → 제목 2줄(24pt, 900) → 부제 1줄(하늘색).
  - 오른쪽에 골드 꺾쇠 두 개(로고 심볼을 나눈 것). 제목과 겹치지 않게 제목 묶음 `right:54mm`를 유지한다.
- **숫자 4칸(`.kpis`)**: 네이비 면 아래 경계에 걸쳐 놓인 흰 카드(top 70mm), 위 골드 선. 칸마다 큰 숫자 + 단위, 이름, 보충 한 줄. 원문 수치만 쓴다. `data-box`로 넘침을 검사한다.
- **본문(`.body`)**: top 101mm ~ bottom 15mm, 블록 4개 내외를 `justify-content:space-between`으로 위아래 고르게 배치.
  - 블록 제목은 `h2` = ■ + 영문 라벨(`<i>SCHEDULE</i>`) + 한국어 제목 + 오른쪽 `<small>` 보충.
- **꼬리 줄(`.ft2`)**: 왼쪽 '발행 2026. 10. 22.', 오른쪽 '인천대학교 산학협력단 산학협력팀'.
- 쪽이 하나뿐이고 디자인 쪽이므로 `section`에 `data-nofill`을 단다(채움률 대신 눈으로 확인).

## 블록 라이브러리 (템플릿에 들어 있는 것)

| 블록 | 클래스 | 쓰는 곳 |
|---|---|---|
| 일정 카드 3칸 | `.crs` | 회차·단계별 날짜. 상태 배지: 지난 것 `div.done`(회색 선·회색 배지 '운영 완료'), 다음 것 `.st.next`(골드 '다음 과정'), 그 뒤 '예정'(테두리) |
| 비용 표 | `table.fee` | 등급별 비용. 무료 칸은 `td.c.free`(네이비 반전, 자간 넓게) |
| 개요 목록 | `dl.info` | 강사·장소·정원·주최 등 4줄 내외 |
| 2단 배치 | `.two` | 비용 표 + 개요 목록을 나란히 |
| 구성 막대 | `.bar` + `.scale` | 전체 중 구성 비율. 칸 폭 %는 실제 비율로 계산하고, 아래 `.scale`에 묶음 합계와 % |
| 신청·문의 | `.apply` | QR(31mm) + 신청 주소 + 전화·메일. 왼쪽 골드 선, 옅은 파랑 바탕 |

- 내용 성격에 맞게 블록을 바꿔도 된다(행사면 일정 카드 대신 프로그램 시간표 표, 사업 안내면 비용 표 대신 지원 내용 표). 새 블록도 같은 토큰으로 만든다.
- **QR:** `<img src="{{QR:https://주소}}">`라고 쓰면 build2.py가 네이비 QR을 만들어 넣는다. 실제 주소가 있을 때만 쓰고, 주소 글자도 함께 적는다.

## 한 장 맞추기

- **반드시 한 장.** 넘치면 블록 하나를 빼거나 문구를 줄인다. 2쪽으로 늘리지 않는다.
- **휑하면 키운다:** `space-between` 때문에 내용이 적으면 블록 사이가 벌어진다. 블록 사이가 12mm보다 넓으면 블록 자체를 키운다 — 일정 카드 안쪽 여백·날짜 크기(28pt), 표 행 높이(위아래 2.1mm·9.4pt), 막대 높이(12mm), QR 크기(31mm). 처음 시안에서 블록 사이가 휑해 이 크기로 키운 것이 템플릿 값이다.
- 숫자 4칸의 보충 줄은 한 줄로 끝나게 짧게 쓴다(두 줄이면 칸 높이가 들쭉날쭉해진다).

## 어떤 스킬을 쓸까 (INU 지면 패밀리)

같은 바탕(네이비 색, 서체, 로고, 머리말, 어절 줄바꿈, 출력 여백)을 쓰는 형제 스킬이 넷이다. 사용자는 스킬 이름을 외우지 않아도 된다. "팩트시트로", "컨설팅형으로", "성과보고서형으로"라고 하거나 용도만 말해도 아래 표로 고른다. 두 가지 이상이 맞을 만큼 애매하면 한 줄로 묻는다.

| 사용자가 원하는 것 | 스킬 | 판형 |
|---|---|---|
| 결재용 장문 보고서(Ⅰ~Ⅵ장 구조, 결과·출장·간담회 보고) | inu-print-report (지면형 보고서) | A4 세로, 여러 쪽 |
| 교육·사업·행사를 한 장에 담은 안내·배포물 | inu-print-factsheet (팩트시트) | A4 세로 1장 |
| 결정을 받아야 하는 검토·건의 보고(단장님·부총장 보고 등) | inu-print-consult (컨설팅형) | A4 가로, 5~8쪽 |
| 한 해 또는 한 사업의 성과를 보여 주는 성과집 | inu-print-annual (성과보고서형) | A4 세로, 6쪽 내외 |
| 워드(.docx) 파일이 꼭 필요할 때 | inu-report-master | DOCX |
| 3단 접지 홍보 브로셔(펼친 크기 360×240mm) | 이 패밀리 범위 밖 — 면 배치가 다르므로 디자인 요소만 빌려 쓴다 | — |

## 패밀리 공통 규칙

### 출력 여백 [필수] (사용자 결정, 2026. 10. 22.)
- 사무실 프린터는 종이 가장자리 4~5mm를 찍지 못한다. 색 면을 종이 끝까지 채우면 그 부분이 잘려 흰 테두리가 생긴다. 특히 세로로 선 덩어리 면은 종이 위에 놓인 "세로로 긴 사각형 박스"처럼 출력된다(컨설팅형 표지를 사용자가 실제로 출력해 발견).
- 그래서 배경색·그라데이션이 있는 모든 요소는 **종이 끝에서 6mm 안쪽**에 둔다. 화면에서도 처음부터 흰 여백이 고르게 보이므로 화면과 출력 모양이 같다.
- 글자도 종이 끝 5mm 안쪽에만 둔다. 예외: 색 면 안에서 잘리도록 둔 장식 글자(성과보고서형 표지의 큰 연도)는 `data-bleed`를 단다.
- `check2.py`가 둘 다 검사한다(5mm 기준이라 6mm로 두면 1mm 여유).
- 참고: 지면형 보고서(inu-print-report) 표지의 위쪽 가로 띠도 종이 끝에 닿지만, 가로 띠는 출력해도 머리 띠로 읽혀 자연스러우므로 그 스킬은 그대로 둔다.

### 표기 규칙 (지면형 보고서와 같음 — 반드시 지킴)
- **개조식 명사형 종결, 끝 마침표 없음:** 목록·카드·주석·제목 모두 '~함', '~발표', '~필요', '~추진'으로 끝낸다. 한 항목 안에서 문장이 둘로 나뉠 때만 중간 마침표를 쓴다.
- **따옴표:** 굽은 따옴표 ‘ ’ “ ”를 쓴다. 문서·행사·법령·사업 이름은 「 」로 감싼다.
- **날짜:** 공문서식 '2026. 10. 14.(수)'(점 뒤 띄움). 기간은 '2026. 1.~6.'.
- **단위:** 숫자와 단위를 붙인다('19개사', '46명'). 큰 숫자는 천 단위 쉼표('1,534').
- **'평생교육' 금지:** 재직자 계속교육, 직무역량 강화, 기업 맞춤형 인력양성 등으로 바꾼다(고칠 수 없는 원문 인용만 예외).
- **로고:** 모든 산출물에 넣는다. 밝은 바탕은 네이비 로고, 어두운 바탕은 흰 글자 + 골드 심볼(build2.py가 만들어 넣음).
- 동그라미 숫자(①②③)를 제목·목록 머리에 쓰지 않는다. 번호가 필요하면 네모 칸 숫자나 '01'처럼 쓴다.

### 조판 규칙 (fit.js·build2.py에 구현 — 끄지 말 것)
- **줄바꿈:** 어절 단위(`word-break:keep-all`) + `line-break:strict`(쉼표·닫는 괄호·가운뎃점이 줄 첫머리에 오지 않음).
- **build2.py 줄바꿈 보조:** '간담회(제5차)'처럼 괄호 붙은 말은 한 단어로 묶고, 가운뎃점은 앞에 붙이고 뒤에서만 줄바꿈을 허용하며, '2-1' 같은 숫자 번호는 줄에서 떼지 않는다.
- **마지막 줄 한 단어 금지:** 자간을 최대 -0.03em 줄여 끌어올리고, 안 되면 마지막 두 단어를 붙여 함께 내린다. 대상은 `p, li, td, td>div, dd, .fx`. 일부러 빼려면 `data-nowidow`.
- **띄어쓰기 고르기:** 양쪽 정렬 문단의 띄어쓰기가 0.55em보다 넓게 벌어지면 자간을 -0.045~+0.03em 안에서 다시 고른다. 10.5pt 이상 큰 글씨, 좁은 칸, 카드 안 설명은 양쪽 정렬 대신 왼쪽 정렬로 둔다(벌어짐 방지).
- **한 줄 제목:** `h2`와 `data-oneline` 요소는 자간을 최대 -0.04em까지 줄여 한 줄로 맞춘다. 그래도 넘치면 문구를 줄인다.
- **줄 판정:** 높이 차이가 글자 크기의 60%를 넘을 때만 줄이 바뀐 것으로 본다(큰 숫자 옆 작은 단위 글자 때문에 줄이 바뀐 것으로 잘못 보지 않게).
- **글자:** 기본 자간 -0.02em. 서체는 Noto Sans KR(웹 폰트), 안 되면 설치된 Noto Sans CJK KR·맑은 고딕.
- **표:** 머리 #D9E2F3 + 네이비 위 선, 짝수 행 #F2F2F2, 첫 열 `td.h`, 숫자 열 `td.c`, 합계 `tr.sum`. 한 칸 안 여러 줄은 `<div>`로 한 줄씩 쓰고 글머리 기호(•)는 쓰지 않는다.
- **종이:** 늘 흰색이고 종이 뒤 배경만 다크 모드를 따른다. 화면 폭이 좁으면 종이째 축소한다(인쇄 때는 1배).

### 화면 = 인쇄 [필수]
- 인쇄물이 A4 규격과 디자인 그대로 나와야 하고, 인쇄 전 화면에서도 같아야 한다. `check2.py`가 PDF를 그림으로 그려 화면 지면과 쪽마다 대조한다(다른 면적이 0.5%를 넘으면 실패). `@media print`에서 모양을 바꾸는 규칙을 넣지 않는다.
- **PDF가 정본이다.** HTML을 다른 PC에서 열면 그 PC의 서체로 줄바꿈이 조금 달라질 수 있으므로 결재·배포·인쇄는 PDF로 한다.

### 사실만 쓴다
- 사용자가 준 자료와 대화에서 나온 사실·수치만 쓴다. 수치를 지어내지 않는다.
- 양식의 칸을 채우려고 쓴 예시 문구나 판단(평가, 일정(안), 슬로건, 단계 설명 등)이 있으면 전달할 때 "확인이 필요한 문구"로 따로 알린다.

## 공통 작업 순서

1. **원고 확보:** 사용자가 준 자료(PDF·DOCX·엑셀·메모·대화)에서 내용을 뽑는다.
2. **도구 파일 만들기:** 작업 폴더에 아래 「파일 1~5」를 글자 하나 바꾸지 말고 그대로 저장한다: `common.css`, `fit.js`, `build2.py`, `check2.py`, `template.html`. build2.py는 원고와 같은 폴더의 common.css·fit.js를 읽는다.
3. **로고:** 인천대 로고 이미지(흰 배경 JPG/PNG)가 필요하다.
   - `/mnt/user-data/uploads/INU_로고.jpg`나 첨부 파일에서 찾는다.
   - 팀 가족회사 검색기 저장소(`inusanhak5/inu-family-search`, 공개)의 `inu_logo.png`도 공식 로고다(`https://raw.githubusercontent.com/inusanhak5/inu-family-search/main/inu_logo.png`).
   - **투명 배경 PNG는 흰 배경에 합쳐 JPG로 저장한 뒤 쓴다**(투명 부분이 검게 처리되는 것을 막음).
   - 어디에도 없으면 한 줄로 첨부를 요청한다.
4. **원고 HTML 작성:** `template.html`을 복사해 내용만 바꾼다. 템플릿은 실제로 쓴 예시 문서다. 구조와 블록은 그대로 따르고 글과 숫자를 바꾼다. 블록은 아래 「블록 라이브러리」에서 고르고, 새 블록이 필요하면 같은 토큰(색 변수, 선 두께, 글자 크기 위계)으로 만든다.
5. **빌드:** `python3 build2.py 원고.html INU_logo.jpg out 파일이름`
6. **검사:** `python3 check2.py out/파일이름.html out/검사`
   - "결과: 통과"가 나올 때까지 고치고 5~6을 반복한다.
7. **눈으로 확인:** `out/검사/contact.png`(전체 쪽 한눈에)와 쪽별 `s#.png`를 연다. 검사가 못 잡는 것을 본다: 꺾쇠·장식이 글자를 덮는지, 블록 사이가 휑하게 벌어졌는지, 큰 숫자와 설명이 어긋났는지.
8. **전달:** PDF는 미리보기(render)로, HTML은 첨부(attach)로 보낸다. 답변에는 쪽 수, (해당하면) 쪽별 채움, 확인이 필요한 문구만 짧게 쓴다.

**검사 환경**
- `pip install playwright pypdfium2 pypdf qrcode --break-system-packages`
- 브라우저가 없을 때만 `playwright install chromium`(이미 `/opt/pw-browsers`가 있으면 하지 않는다).
- `pypdfium2`·`pypdf`가 설치되지 않으면 화면·인쇄 대조와 PDF 링크 확인만 건너뛰었다고 전달할 때 말한다.

### 검사 기준 (check2.py가 판정)
- 넘침 0: `.body`와 `data-box`를 단 칸
- 본문 쪽 채움 85% 이상(`.body`가 있는 쪽만, 마지막 쪽 50% 이상, `data-nofill` 쪽은 제외하고 눈으로 확인)
- 색 면이 종이 끝 5mm 안까지 닿지 않음, 글자가 종이 끝 5mm 안에 없음
- 단어 중간 줄바꿈 0, 마지막 줄 한 단어 0, 개조식 끝 마침표 0, 벌어진 띄어쓰기(0.6em 초과) 0, 두 줄 제목 0
- 이동할 곳 없는 링크 0, PDF 링크가 맞는 쪽으로 감
- 인쇄(PDF) 쪽 수 = 지면 수, 화면과 인쇄 모양 차이 0.5% 이하

## 파일 1: common.css

````css
/* ===== INU 보고서 패밀리 공통 바탕 (지면형 보고서와 같은 토큰·서체·머리말·인쇄 규칙) ===== */
:root{
  --navy:#1F4E79; --deep:#163A5C; --blue:#2E75B6; --sky:#9DC3E6; --steel:#5B8DC9; --gray:#8A97A8;
  --mist:#D9E2F3; --pale:#EEF3FA; --gold:#FCB01B; --goldpale:#FFF4DC;
  --ink:#1B2330; --sub:#4A5566; --rule:#BFCBDA; --zebra:#F2F2F2; --paper:#FFFFFF;
  --desk:#E4E8EE; --desk-fg:#4A5566;
  --f:'Noto Sans KR','Noto Sans CJK KR','Malgun Gothic','맑은 고딕',sans-serif;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}}
:root[data-theme="dark"]{--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}
*{box-sizing:border-box}
body{background:var(--desk);color:var(--ink);font-family:var(--f);margin:0;word-break:keep-all;overflow-wrap:break-word;line-break:strict;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.doc{padding-block:24px 40px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
.stack{zoom:var(--z,1);display:flex;flex-direction:column;align-items:center;gap:10mm}
.sheet{position:relative;width:210mm;height:297mm;letter-spacing:-.02em;background:var(--paper);color:var(--ink);overflow:hidden;box-shadow:0 1px 2px rgba(20,30,50,.12),0 8px 24px rgba(20,30,50,.10);flex:none}
.sheet.land{width:297mm;height:210mm}
.sheet p{margin:0}
.sheet em{font-style:normal}

/* 머리말·꼬리말: 왼쪽 네이비 로고 + 오른쪽 팀명 + 파란 선 / "- N -" */
.hd{position:absolute;top:10mm;left:16mm;right:16mm;height:8mm;display:flex;align-items:flex-end;justify-content:space-between;border-bottom:.45mm solid var(--blue);padding-bottom:1.4mm}
.hd img{height:5.2mm;display:block}
.hd span{font-size:8pt;color:var(--sub);letter-spacing:.02em}
.ft{position:absolute;bottom:8mm;left:0;right:0;text-align:center;font-size:8.5pt;color:var(--sub)}
.cx{position:absolute;display:block;pointer-events:none}
a.lk{text-decoration:none;color:inherit;-webkit-tap-highlight-color:transparent}
a.lk:focus:not(:focus-visible){outline:none}

/* 표(지면형 보고서와 동일) */
table{width:100%;border-collapse:collapse;font-size:9pt;line-height:1.45;font-variant-numeric:tabular-nums}
thead th{background:var(--mist);color:var(--navy);font-weight:800;padding:1.3mm 1.6mm;border-top:.5mm solid var(--navy);border-bottom:.25mm solid var(--navy);letter-spacing:.04em}
td{padding:1.15mm 1.8mm;border-bottom:.2mm solid var(--rule);vertical-align:middle}
tbody tr:nth-child(even) td{background:var(--zebra)}
td.h{font-weight:700;text-align:center;color:var(--ink);white-space:nowrap}
td.c{text-align:center}
td div+div{margin-top:.5mm}
tr.sum td{background:var(--pale)!important;font-weight:800;color:var(--navy);border-top:.3mm solid var(--navy)}
.note{font-size:8.5pt;color:var(--sub);line-height:1.5;margin:0;padding-left:3.4mm;text-indent:-3.4mm;text-align:justify}
.end{text-align:center;font-size:10pt;font-weight:700;color:var(--navy);letter-spacing:.3em}

@media print{
  @page{size:A4;margin:0}
  body{background:#fff}
  .doc{padding:0}
  .stack{zoom:1!important;gap:0}
  .sheet{box-shadow:none;break-after:page}
}
````

## 파일 2: fit.js

원고의 `<!--{{FIT_JS}}-->` 자리에 build2.py가 넣는다.

````html
<script>
/* 화면 맞춤: 종이 폭(세로 210mm / 가로 297mm)에 맞춰 축소, 인쇄 때는 1배 */
(function(){
  function fitz(){var s=document.querySelector('.sheet');if(!s)return;var w=document.documentElement.clientWidth-32;document.documentElement.style.setProperty('--z',Math.min(1,w/s.offsetWidth).toFixed(4));}
  fitz();addEventListener('resize',fitz);
  addEventListener('beforeprint',function(){document.documentElement.style.setProperty('--z','1');});
  addEventListener('afterprint',fitz);
})();
</script>
<script>
/* 조판 보정(패밀리 공통, 수정 금지): ① 마지막 줄 한 단어 금지 ② 벌어진 띄어쓰기 고르기 ③ 한 줄 제목 유지. 문서별 추가 보정은 window.FIT_EXTRA. 끝나면 html[data-fit=done] */
(function(){
  function chars(el){var a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n;while(n=w.nextNode())for(var i=0;i<n.data.length;i++)a.push([n,i]);return a;}
  var rg=document.createRange();
  function top(c){rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);var r=rg.getClientRects();return r.length?r[r.length-1].top:null;}
  function info(el){var A=chars(el),txt=A.map(function(c){return c[0].data[c[1]];}).join('');var e=txt.replace(/\s+$/,'').length-1;if(e<1)return{lines:1,widow:false};var th=parseFloat(getComputedStyle(el).fontSize)*.6;
    var lt=top(A[e]),s=e;while(s>0){var ch=txt[s-1];if(/\s/.test(ch)){s--;continue;}var t=top(A[s-1]);if(t===null||Math.abs(t-lt)>th)break;s--;}
    var first=top(A[0]),lines=1,prev=first;for(var i=1;i<=e;i++){if(/\s/.test(txt[i]))continue;var t=top(A[i]);if(t!==null&&t-prev>th){lines++;prev=t;}}
    return{lines:lines,widow:lines>1&&!/\s/.test(txt.slice(s,e+1).trim()),A:A,txt:txt,s:s};}
  function em(el){return parseFloat(getComputedStyle(el).letterSpacing)/parseFloat(getComputedStyle(el).fontSize)||0;}
  function glue(el,I){var k=I.txt.slice(0,I.s).replace(/\s+$/,'').length;var c=I.A[k];if(c&&c[0].data[c[1]]===' '){c[0].data=c[0].data.slice(0,c[1])+String.fromCharCode(160)+c[0].data.slice(c[1]+1);}}
  window.FIT={info:info,em:em};
  var WID='.sheet :is(p,li,td,td>div,dd,.fx):not([data-nowidow])';
  function run(){
    document.querySelectorAll(WID).forEach(function(el){
      if(el.querySelector('br,div,ul,p,li'))return;
      var I=info(el);if(!I.widow)return;var base=em(el),L=I.lines;
      for(var d=.005;d<=.0301;d+=.005){el.style.letterSpacing=(base-d).toFixed(3)+'em';var J=info(el);if(!J.widow&&J.lines<=L)return;}
      el.style.letterSpacing='';glue(el,info(el));});
    function gap(el){var fs=parseFloat(getComputedStyle(el).fontSize),w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n,sp=[];
      while(n=w.nextNode())for(var i=0;i<n.data.length;i++){if(n.data[i]!==' ')continue;rg.setStart(n,i);rg.setEnd(n,i+1);var rc=rg.getClientRects()[0];if(rc&&rc.width>0)sp.push([rc.width/fs,rc.top]);}
      if(!sp.length)return 0;var lt=Math.max.apply(null,sp.map(function(x){return x[1];})),m=0;sp.forEach(function(x){if(Math.abs(x[1]-lt)>2&&x[0]>m)m=x[0];});return m;}
    document.querySelectorAll('.sheet :is(p,li,dd,.fx)').forEach(function(el){
      if(getComputedStyle(el).textAlign!=='justify'||el.querySelector('ul,div,p,li')||gap(el)<=.55)return;
      var cur=el.style.letterSpacing,base=em(el),L=info(el).lines,best=[gap(el),cur];
      for(var d=-.045;d<=.0301;d+=.005){el.style.letterSpacing=(base+d).toFixed(3)+'em';var I=info(el);if(I.widow||I.lines>L)continue;var g=gap(el);if(g<best[0])best=[g,el.style.letterSpacing];}
      el.style.letterSpacing=best[1];});
    document.querySelectorAll('.sheet :is(h2,[data-oneline])').forEach(function(h){var base=em(h);for(var d=0;d<=.0401&&info(h).lines>1;d+=.005)h.style.letterSpacing=(base-d).toFixed(3)+'em';});
    (window.FIT_EXTRA||[]).forEach(function(f){f();});
    document.documentElement.dataset.fit='done';}
  (document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve()).then(function(){requestAnimationFrame(run);});
})();
</script>
````

## 파일 3: build2.py

````python
"""INU 보고서 패밀리 빌드: python3 build2.py 원고.html INU_로고.jpg 출력폴더 파일이름
- 원고의 /*{{COMMON_CSS}}*/ 자리에 common.css, <!--{{FIT_JS}}--> 자리에 fit.js를 넣음(원고와 같은 폴더)
- 로고(흰 배경 JPG)에서 네이비·흰색 로고와 골드 꺾쇠(CHEV_TR/CHEV_BL)를 만들어 data URI로 넣음 — 지면형 보고서 build.py와 같은 방식
- {{QR:주소}} → 네이비 QR 코드(SVG data URI)
- 본문 글자 줄바꿈 보조: 글자+( / )+글자는 붙이고(WJ), 가운뎃점은 앞에 붙이고 뒤에서만 줄바꿈 허용(ZWSP)
- 출력: <이름>.html(완성 문서), <이름>_artifact.html(아티팩트 게시용)"""
import re, sys, os, io, base64
import numpy as np
from PIL import Image
src_path, logo_path, out_dir, name = sys.argv[1:5]
os.makedirs(out_dir, exist_ok=True)
here = os.path.dirname(os.path.abspath(src_path))

def logo_variants(path):
    im = np.asarray(Image.open(path).convert('RGB')).astype(float)
    r, g, b = im[..., 0], im[..., 1], im[..., 2]
    warm = (r > g) & (r > b + 30)
    alpha = np.clip((255 - im.min(axis=2)) / 228, 0, 1)
    GOLD = im[warm & (alpha > .9)].mean(0) if (warm & (alpha > .9)).any() else np.array([252, 176, 27])
    def png(img, w):
        img = img.resize((w, max(1, int(img.height * w / img.width))), Image.LANCZOS)
        buf = io.BytesIO(); img.save(buf, 'PNG', optimize=True)
        return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()
    def make(letter, sym_only=False):
        out = np.zeros(im.shape[:2] + (4,), np.uint8)
        out[..., :3] = np.where(warm[..., None], GOLD, letter)
        out[..., 3] = (alpha * 255).astype(np.uint8)
        if sym_only: out[~warm, 3] = 0
        img = Image.fromarray(out, 'RGBA'); return img.crop(img.getbbox())
    def chevron(sym, part):
        a = np.asarray(sym).copy(); H, W = a.shape[:2]
        yy, xx = np.mgrid[0:H, 0:W]; upper = xx / W > yy / H
        a[(~upper) if part == 'tr' else upper, 3] = 0
        p = Image.fromarray(a, 'RGBA'); return p.crop(p.getbbox())
    sym = make(np.array([0, 0, 0]), sym_only=True)
    return {'LOGO_NAVY': png(make(np.array([0x1F, 0x4E, 0x79])), 270), 'LOGO_WHITE': png(make(np.array([255, 255, 255])), 270),
            'CHEV_TR': png(chevron(sym, 'tr'), 220), 'CHEV_BL': png(chevron(sym, 'bl'), 220)}

def qr(url):
    import qrcode, qrcode.image.svg
    q = qrcode.QRCode(border=0, error_correction=qrcode.constants.ERROR_CORRECT_M); q.add_data(url); q.make(fit=True)
    m = q.get_matrix(); n = len(m)
    d = ''.join(f'M{x} {y}h1v1h-1z' for y, row in enumerate(m) for x, v in enumerate(row) if v)
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n} {n}" shape-rendering="crispEdges"><path fill="#1F4E79" d="{d}"/></svg>'
    return 'data:image/svg+xml;base64,' + base64.b64encode(svg.encode()).decode()

src = open(src_path, encoding='utf-8').read()
src = src.replace('/*{{COMMON_CSS}}*/', open(os.path.join(here, 'common.css'), encoding='utf-8').read())
src = src.replace('<!--{{FIT_JS}}-->', open(os.path.join(here, 'fit.js'), encoding='utf-8').read())
src = re.sub(r'\{\{QR:([^}]+)\}\}', lambda m: qr(m.group(1)), src)
for k, v in logo_variants(logo_path).items():
    src = src.replace('{{' + k + '}}', v)

WJ, ZW = chr(0x2060), chr(0x200B)
def tx(t):
    t = re.sub(r'([가-힣A-Za-z0-9])\(', lambda m: m.group(1) + WJ + '(', t)
    t = re.sub(r'\)([가-힣A-Za-z0-9])', lambda m: ')' + WJ + m.group(1), t)
    t = re.sub(r'([가-힣A-Za-z0-9])·([가-힣A-Za-z0-9])', lambda m: m.group(1) + WJ + '·' + ZW + m.group(2), t)
    t = re.sub(r'(\d)-(\d)', lambda m: m.group(1) + WJ + '-' + WJ + m.group(2), t)   # 2-1 같은 번호는 줄에서 떼지 않음
    return t
a = src.index('</style>'); b = src.index('<script>')
src = src[:a] + re.sub(r'>([^<]+)<', lambda m: '>' + tx(m.group(1)) + '<', src[a:b]) + src[b:]

open(os.path.join(out_dir, name + '_artifact.html'), 'w', encoding='utf-8').write(src)
m = re.search(r'</style>', src)
full = ('<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        + src[:m.end()] + '\n</head>\n<body>' + src[m.end():] + '\n</body>\n</html>\n')
open(os.path.join(out_dir, name + '.html'), 'w', encoding='utf-8').write(full)
print('OK', os.path.join(out_dir, name + '.html'))
````

## 파일 4: check2.py

````python
"""INU 보고서 패밀리 검사 + PDF: python3 check2.py 완성문서.html 출력폴더
통과 기준(지면형 보고서 check.py와 같은 원칙):
  넘침 0(.body·[data-box]) · 본문 쪽 채움 85% 이상(.body가 있는 쪽, data-nofill 제외, 마지막 쪽 50%)
  · 인쇄 안전 여백(종이 끝 5mm) 안쪽에만 글자 · 단어 중간 줄바꿈 0 · 마지막 줄 한 단어 0 · 개조식 끝 마침표 0
  · 벌어진 띄어쓰기(0.6em 초과) 0 · 한 줄 제목(h2·[data-oneline]) · 링크 대상 있음
  · 인쇄(PDF) 쪽 수 = 지면 수 · PDF 링크 도착 쪽 일치 · 화면과 인쇄 모양 일치(차이 0.5% 이하)
출력: 쪽별 PNG(s1.png…), 한눈에 보기(contact.png), PDF, 결과"""
import sys, os, re
from playwright.sync_api import sync_playwright
from PIL import Image
html, out = os.path.abspath(sys.argv[1]), sys.argv[2]
os.makedirs(out, exist_ok=True)
JS = r"""() => {
 const rg=document.createRange(), MM=96/25.4, R={pages:[],boxes:[],bleed:[],safe:[],midword:[],widow:[],period:[],gaps:[],titles:[],links:[],nlinks:0,dest:{}};
 const chars=el=>{const a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode())for(let i=0;i<n.data.length;i++)a.push([n,i]);return a;};
 const top=c=>{rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);const r=rg.getClientRects();return r.length?r[r.length-1].top:null;};
 document.querySelectorAll('.sheet').forEach(s=>{const p=+s.dataset.page,b=s.querySelector('.body');
   if(b){const br=b.getBoundingClientRect();let last=0;b.querySelectorAll(':scope>*').forEach(c=>{if(c.classList.contains('end'))return;last=Math.max(last,c.getBoundingClientRect().bottom);});
     R.pages.push({p,overflow:b.scrollHeight-b.clientHeight,fill:Math.round((last-br.top)/br.height*100),nofill:s.hasAttribute('data-nofill')});}
   else R.pages.push({p,nofill:true,overflow:0});
   s.querySelectorAll('[data-box]').forEach(x=>{const o=Math.max(x.scrollHeight-x.clientHeight,x.scrollWidth-x.clientWidth);if(o>1)R.boxes.push(p+'쪽 '+(x.dataset.box||x.className)+' '+o+'px');});
   const S0=s.getBoundingClientRect();s.querySelectorAll('*').forEach(x=>{const cs=getComputedStyle(x),bg=cs.backgroundColor,img=cs.backgroundImage;
     const colored=(img&&img!=='none')||(bg&&!/rgba\(\s*0,\s*0,\s*0,\s*0\)|transparent/.test(bg)&&!/rgb\(255,\s*255,\s*255\)/.test(bg));if(!colored)return;
     const r=x.getBoundingClientRect();if(!r.width||!r.height)return;const m=5*MM;
     if(r.left<S0.left+m||r.right>S0.right-m||r.top<S0.top+m||r.bottom>S0.bottom-m)R.bleed.push(p+'쪽 '+(x.className||x.tagName));});
   const S=s.getBoundingClientRect(),w=document.createTreeWalker(s,NodeFilter.SHOW_TEXT);let n;
   while(n=w.nextNode()){if(!n.data.trim()||n.parentElement.closest('[data-bleed]'))continue;rg.selectNodeContents(n);
     for(const r of rg.getClientRects()){if(!r.width)continue;if(r.left<S.left+5*MM||r.right>S.right-5*MM||r.top<S.top+5*MM||r.bottom>S.bottom-5*MM){R.safe.push(p+'쪽 '+n.data.trim().slice(0,12));break;}}}});
 const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
 while(n=w.nextNode()){if(n.data.trim().length<2)continue;let pt=null;
   for(let i=0;i<n.length;i++){const t=top([n,i]);if(t===null)continue;if(pt!==null&&t>pt+3){const a=n.data[i-1],c=n.data[i];if(/[가-힣A-Za-z0-9]/.test(a)&&/[가-힣A-Za-z0-9]/.test(c))R.midword.push(n.data.slice(Math.max(0,i-8),i)+'|'+n.data.slice(i,i+6));}pt=t;}}
 document.querySelectorAll('.sheet :is(p,li,td,td>div,dd,.fx):not([data-nowidow])').forEach(el=>{
   if(el.querySelector('br,div,ul,p,li'))return;const A=chars(el),txt=A.map(c=>c[0].data[c[1]]).join(''),e=txt.replace(/\s+$/,'').length-1;if(e<1)return;
   const th=parseFloat(getComputedStyle(el).fontSize)*.6,lt=top(A[e]);let s=e;while(s>0){if(/\s/.test(txt[s-1])){s--;continue;}const t=top(A[s-1]);if(t===null||Math.abs(t-lt)>th)break;s--;}
   if(s>0&&Math.abs(top(A[0])-lt)>th&&!/\s/.test(txt.slice(s,e+1).trim()))R.widow.push(txt.slice(s,e+1));});
 document.querySelectorAll('.sheet :is(li,.note,td>div,td:not(:has(div)),dd,[data-np])').forEach(el=>{let t='';el.childNodes.forEach(c=>{if(c.nodeName!=='UL')t+=c.textContent;});if(/[가-힣)]\.\s*$/.test(t))R.period.push(t.trim().slice(-20));});
 document.querySelectorAll('.sheet :is(p,li,dd,.fx)').forEach(el=>{if(getComputedStyle(el).textAlign!=='justify'||el.querySelector('ul,div,p,li'))return;const fs=parseFloat(getComputedStyle(el).fontSize),sp=[];const w2=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let m;
   while(m=w2.nextNode())for(let i=0;i<m.length;i++){if(m.data[i]!==' ')continue;rg.setStart(m,i);rg.setEnd(m,i+1);const rc=rg.getClientRects()[0];if(rc&&rc.width>0)sp.push([rc.width/fs,rc.top,m.data.slice(Math.max(0,i-10),i+10)]);}
   if(!sp.length)return;const lt=Math.max(...sp.map(x=>x[1]));sp.forEach(x=>{if(Math.abs(x[1]-lt)>2&&x[0]>.6)R.gaps.push(x[0].toFixed(2)+' '+x[2]);});});
 document.querySelectorAll('.sheet :is(h2,[data-oneline])').forEach(h=>{const A=chars(h).filter(c=>!/\s/.test(c[0].data[c[1]]));const T=A.map(top).filter(x=>x!==null);if(T.length&&Math.max(...T)-Math.min(...T)>parseFloat(getComputedStyle(h).fontSize)*.6)R.titles.push(h.textContent.trim().slice(0,40));});
 document.querySelectorAll('a[href^="#"]').forEach(a=>{R.nlinks++;const id=a.getAttribute('href').slice(1),t=document.getElementById(id);if(!t)R.links.push(a.textContent.trim()+' → #'+id);else R.dest[id]=+t.closest('.sheet').dataset.page;});
 return R;}"""
with sync_playwright() as p:
    try: br = p.chromium.launch()
    except Exception:
        br = p.chromium.launch(executable_path=next((x for x in ['/opt/pw-browsers/chromium', '/usr/bin/chromium', '/usr/bin/chromium-browser'] if os.path.exists(x)), None))
    pg = br.new_page(viewport={'width': 1300, 'height': 1200}, device_scale_factor=1.5)
    pg.goto('file://' + html); pg.wait_for_function("document.documentElement.dataset.fit==='done'", timeout=30000); pg.wait_for_timeout(250)
    R = pg.evaluate(JS)
    sheets = pg.query_selector_all('.sheet')
    for i, s in enumerate(sheets, 1): s.screenshot(path=f'{out}/s{i}.png')
    pdf = os.path.join(out, os.path.splitext(os.path.basename(html))[0] + '.pdf')
    pg.pdf(path=pdf, format='A4', print_background=True, prefer_css_page_size=True)
    br.close()
raw = open(pdf, 'rb').read()
pdf_links = len(re.findall(rb'/Subtype\s*/Link', raw))
pdf_pages, diffs = None, []
try:
    import pypdfium2 as pdfium
    from PIL import ImageChops, ImageFilter
    doc = pdfium.PdfDocument(pdf); pdf_pages = len(doc)
    for i in range(min(pdf_pages, len(sheets))):
        a = Image.open(f'{out}/s{i+1}.png').convert('L')
        b = doc[i].render(scale=a.width / doc[i].get_width()).to_pil().convert('L').resize(a.size)
        a2, b2 = [x.resize((x.width // 3, x.height // 3)).filter(ImageFilter.GaussianBlur(1)) for x in (a, b)]
        d = ImageChops.difference(a2, b2).point(lambda v: 255 if v > 48 else 0)
        diffs.append(round(d.histogram()[255] / (d.width * d.height) * 100, 3))
except ImportError:
    pdf_pages = len(re.findall(rb'/Type\s*/Page[^s]', raw))
ims = [Image.open(f'{out}/s{i}.png') for i in range(1, len(sheets) + 1)]
sc = 0.3; ims = [im.resize((int(im.width * sc), int(im.height * sc))) for im in ims]; w, h = ims[0].size
cols = min(3 if w > h else 4, len(ims)); rows = -(-len(ims) // cols)
sheet = Image.new('RGB', (cols * w + (cols - 1) * 10, rows * h + (rows - 1) * 10), '#777')
for i, im in enumerate(ims): sheet.paste(im, ((i % cols) * (w + 10), (i // cols) * (h + 10)))
sheet.save(f'{out}/contact.png')
fails = []
body = [x for x in R['pages'] if not x['nofill']]
for x in R['pages']:
    if x['overflow'] > 0: fails.append(f"{x['p']}쪽 넘침 {x['overflow']}px")
for i, x in enumerate(body):
    lim = 50 if x is R['pages'][-1] else 85
    if x['fill'] < lim: fails.append(f"{x['p']}쪽 채움 {x['fill']}% (<{lim}%)")
try:
    from pypdf import PdfReader
    rd = PdfReader(pdf); nd = {k.lstrip('/'): rd.get_destination_page_number(v) + 1 for k, v in rd.named_destinations.items()}
    for k, v in R['dest'].items():
        if nd.get(k) != v: fails.append(f"PDF 링크 {k}가 {nd.get(k)}쪽으로 감 (맞는 쪽 {v})")
except ImportError: pass
if pdf_pages != len(sheets): fails.append(f"인쇄 쪽 수 {pdf_pages} ≠ 지면 {len(sheets)}쪽")
if R['nlinks'] and pdf_links < R['nlinks']: fails.append(f"PDF 링크 {pdf_links}개 < 문서 링크 {R['nlinks']}개")
for i, v in enumerate(diffs, 1):
    if v > 0.5: fails.append(f"{i}쪽 화면과 인쇄 모양 다름 ({v}%)")
for k, label in [('boxes', '칸 넘침'), ('bleed', '색 면이 종이 끝 5mm 안까지 닿음(사무실 프린터에서 흰 테두리 박스로 출력됨)'), ('safe', '인쇄 안전 여백(5mm) 침범'), ('links', '이동할 곳 없는 링크'), ('midword', '단어 중간 줄바꿈'), ('widow', '마지막 줄 한 단어'), ('period', '끝 마침표'), ('gaps', '벌어진 띄어쓰기'), ('titles', '두 줄 제목')]:
    if R[k]: fails.append(f"{label} {len(R[k])}곳: {R[k][:6]}")
print('쪽별 채움:', ' '.join(f"{x['p']}쪽 {x['fill']}%" for x in body) or '(디자인 쪽만 있음)')
print('PDF:', pdf, '| 지면', len(sheets), '쪽 · 인쇄', pdf_pages, '쪽 · 링크', pdf_links, '개 · 화면/인쇄 차이(%)', diffs)
print('결과: 통과' if not fails else '결과: 고칠 곳\n - ' + '\n - '.join(fails))
````

## 파일 5: template.html

실제로 만든 예시 문서다. 구조·클래스·블록은 그대로 두고 제목·글·숫자만 바꾼다.

````html
<title>AX 교육 팩트시트</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700;800;900&display=swap">
<style>
/*{{COMMON_CSS}}*/
/* ===== ① 1페이지 팩트시트: A4 세로 한 장, 위 네이비 면 + 지표 4칸이 경계에 걸침 + 일정·비용·구성·신청 ===== */
.fs .top{position:absolute;inset:6mm 6mm auto 6mm;height:72mm;background:var(--navy);color:#fff;overflow:hidden}
.fs .brand{position:absolute;left:10mm;top:7mm;display:flex;align-items:center;gap:3.2mm}
.fs .brand img{height:9mm;display:block}
.fs .brand span{font-size:8.6pt;font-weight:700;letter-spacing:.05em;border-left:.3mm solid rgba(255,255,255,.5);padding-left:3.2mm;line-height:1.4}
.fs .tag{position:absolute;right:10mm;top:7.5mm;text-align:right;font-size:7.8pt;font-weight:800;letter-spacing:.24em;color:var(--sky)}
.fs .tag b{display:block;color:#fff;font-size:12pt;letter-spacing:.02em;margin-top:.8mm}
.fs .ttl{position:absolute;left:10mm;top:25mm;right:54mm}
.fs .pill{display:inline-block;background:var(--gold);color:var(--navy);font-size:8.4pt;font-weight:800;padding:.8mm 2.6mm;letter-spacing:.08em}
.fs h1{margin:3.2mm 0 0;font-size:24pt;font-weight:900;line-height:1.2;letter-spacing:-.025em}
.fs .subt{margin:2.6mm 0 0;font-size:10.2pt;color:var(--sky);font-weight:500}
.fs .cx.tr{width:34mm;right:14mm;top:18mm}
.fs .cx.bl{width:22mm;right:38mm;top:40mm;opacity:.95}

/* 지표 4칸: 네이비 면 아래 경계에 걸쳐 놓임 */
.fs .kpis{position:absolute;left:16mm;right:16mm;top:70mm;display:grid;grid-template-columns:repeat(4,1fr);background:#fff;border:.25mm solid var(--rule);border-top:.9mm solid var(--gold);box-shadow:0 1.2mm 3mm rgba(31,78,121,.10)}
.fs .kpis div{padding:3mm 3.4mm 2.8mm;display:flex;flex-direction:column;gap:.7mm;border-right:.2mm solid var(--rule)}
.fs .kpis div:last-child{border-right:0}
.fs .kpis strong{font-size:22pt;font-weight:900;color:var(--navy);line-height:1;letter-spacing:-.02em;font-variant-numeric:tabular-nums}
.fs .kpis strong small{font-size:10pt;font-weight:800;margin-left:.6mm}
.fs .kpis span{font-size:8.8pt;font-weight:800;color:var(--ink)}
.fs .kpis em{font-size:7.6pt;color:var(--sub);line-height:1.4}

.fs .body{position:absolute;left:16mm;right:16mm;top:101mm;bottom:15mm;display:flex;flex-direction:column;justify-content:space-between}
.fs h2{margin:0 0 3.4mm;font-size:11.5pt;font-weight:800;color:var(--ink);display:flex;align-items:center;gap:2mm;padding-bottom:1.2mm;border-bottom:.25mm solid var(--rule)}
.fs h2::before{content:"";width:2.6mm;height:2.6mm;background:var(--navy);flex:none}
.fs h2 i{font-style:normal;font-size:7.4pt;font-weight:800;color:var(--blue);letter-spacing:.2em}
.fs h2 small{font-size:8.4pt;font-weight:500;color:var(--sub);margin-left:auto}

/* 과정 일정 3칸 */
.crs{display:grid;grid-template-columns:repeat(3,1fr);gap:4mm}
.crs > div{border:.25mm solid var(--rule);border-top:.9mm solid var(--navy);padding:4mm 4mm 4mm;display:grid;grid-template-columns:auto 1fr;grid-template-rows:auto auto auto;column-gap:3mm;row-gap:1.2mm;align-items:end;position:relative}
.crs > div.done{border-top-color:var(--gray)}
.crs .lv{grid-row:1;grid-column:1/3;display:flex;align-items:baseline;justify-content:space-between}
.crs .lv b{font-size:12pt;font-weight:900;color:var(--navy)}
.crs .done .lv b{color:var(--sub)}
.crs .st{font-size:7.4pt;font-weight:800;letter-spacing:.06em;padding:.3mm 1.6mm;border:.25mm solid var(--navy);color:var(--navy)}
.crs .done .st{border-color:var(--gray);color:var(--sub);background:var(--zebra)}
.crs .st.next{background:var(--gold);border-color:var(--gold)}
.crs strong{grid-row:2;grid-column:1;font-size:28pt;font-weight:900;color:var(--ink);line-height:1;letter-spacing:-.03em;font-variant-numeric:tabular-nums}
.crs .done strong{color:var(--sub)}
.crs .wd{grid-row:2;grid-column:2;font-size:9pt;font-weight:700;color:var(--sub);padding-bottom:.6mm}
.crs p{grid-row:3;grid-column:1/3;font-size:8.8pt;color:var(--sub);font-weight:500;border-top:.2mm dashed var(--rule);padding-top:2.2mm;margin-top:1.4mm}

/* 비용 + 운영 개요 2단 */
.two{display:grid;grid-template-columns:1fr 1fr;gap:7mm}
.fee td{padding-block:2.1mm;font-size:9.4pt}.fee td.c{font-weight:800;color:var(--navy)}
.fee td.c.free{color:#fff;background:var(--navy)!important;letter-spacing:.2em}
.info{margin:0;display:grid;grid-template-columns:20mm 1fr;border-top:.5mm solid var(--navy)}
.info dt{font-size:8.4pt;font-weight:800;color:var(--navy);background:var(--mist);padding:2.35mm 2mm;border-bottom:.2mm solid #fff;letter-spacing:.04em;display:flex;align-items:center}
.info dd{margin:0;font-size:9.4pt;font-weight:500;padding:2.35mm 2.4mm;border-bottom:.2mm solid var(--rule);line-height:1.45}

/* 구성 막대 */
.bar{display:flex;height:12mm;font-size:8.4pt;font-weight:800;color:#fff}
.bar div{display:flex;align-items:center;justify-content:center;white-space:nowrap;border-right:.4mm solid #fff;gap:1.2mm}
.bar div b{font-size:10pt;font-weight:900}
.bar div:last-child{border-right:0}
.scale{display:flex;justify-content:space-between;font-size:7.8pt;color:var(--sub);margin-top:1.4mm}

/* 신청·문의 */
.apply{display:grid;grid-template-columns:31mm 1fr 1fr;gap:6mm;align-items:center;background:var(--pale);border-left:1.2mm solid var(--gold);padding:4.4mm 5mm 4.4mm 4.4mm}
.apply img{width:31mm;height:31mm;display:block;background:#fff;padding:1.6mm}
.apply dl{margin:0;display:flex;flex-direction:column;gap:1mm}
.apply dt{font-size:7.6pt;font-weight:800;color:var(--blue);letter-spacing:.18em}
.apply dd{margin:0;font-size:10pt;font-weight:700;color:var(--ink);line-height:1.45}
.apply dd.url{font-size:9pt;color:var(--navy);word-break:break-all}
.apply .gap{margin-top:2mm}
.fs .ft2{position:absolute;left:16mm;right:16mm;bottom:8mm;display:flex;justify-content:space-between;font-size:7.8pt;color:var(--sub);border-top:.25mm solid var(--rule);padding-top:1.6mm}
.fs .ft2 b{color:var(--navy);font-weight:800}
</style>

<div class="doc"><div class="stack">
<section class="sheet fs" data-page="1" data-nofill>
  <div class="top">
    <img class="cx tr" src="{{CHEV_TR}}" alt=""><img class="cx bl" src="{{CHEV_BL}}" alt="">
    <div class="brand"><img src="{{LOGO_WHITE}}" alt="INU"><span>인천대학교 산학협력단<br>산학협력팀</span></div>
    <div class="tag">FACT SHEET<b>2026. 10.</b></div>
    <div class="ttl">
      <span class="pill">가족회사 재직자 교육</span>
      <h1>2026 하반기<br>AI·AX 역량강화 교육</h1>
      <p class="subt">초급부터 고급까지 하루 실습으로 이어지는 단계별 과정</p>
    </div>
  </div>

  <div class="kpis" data-box="지표">
    <div><strong>127<small>명</small></strong><span>상반기 수강 인원</span><em>5개 과정 수강 합계</em></div>
    <div><strong>319<small>명</small></strong><span>연간 수강 예상</span><em>하반기 192명 예정 포함</em></div>
    <div><strong>3<small>단계</small></strong><span>초급·중급·고급</span><em>회차별 하루 집중 실습</em></div>
    <div><strong>30<small>명</small></strong><span>회차당 정원</span><em>코워킹 스튜디오 실습석 기준</em></div>
  </div>

  <div class="body">
    <div>
      <h2><i>SCHEDULE</i>과정 일정<small>시간 09:00~18:10 · 장소 학산도서관(이룸관) 1층</small></h2>
      <div class="crs">
        <div class="done"><div class="lv"><b>초급</b><span class="st">운영 완료</span></div><strong>9. 30.</strong><span class="wd">수요일</span><p>입문 단계 · 8시간 실습</p></div>
        <div><div class="lv"><b>중급</b><span class="st next">다음 과정</span></div><strong>10. 28.</strong><span class="wd">수요일</span><p>활용 단계 · 8시간 실습</p></div>
        <div><div class="lv"><b>고급</b><span class="st">예정</span></div><strong>11. 25.</strong><span class="wd">수요일</span><p>심화 단계 · 8시간 실습</p></div>
      </div>
    </div>

    <div class="two">
      <div>
        <h2><i>FEE</i>교육비<small>1인 기준</small></h2>
        <table class="fee"><colgroup><col><col style="width:30mm"></colgroup>
          <thead><tr><th>멤버십 등급</th><th>교육비</th></tr></thead>
          <tbody>
            <tr><td class="h">플래티넘 가족회사</td><td class="c free">무료</td></tr>
            <tr><td class="h">골드 가족회사</td><td class="c">60,000원</td></tr>
            <tr><td class="h">실버 가족회사</td><td class="c">75,000원</td></tr>
            <tr><td class="h">일반(정가)</td><td class="c">100,000원</td></tr>
          </tbody>
        </table>
      </div>
      <div>
        <h2><i>OUTLINE</i>운영 개요</h2>
        <dl class="info">
          <dt>강사</dt><dd>IN교육컨설팅 박성민 대표</dd>
          <dt>장소</dt><dd>학산도서관(이룸관) 1층 코워킹 스튜디오</dd>
          <dt>정원</dt><dd>회차당 30명 이내</dd>
          <dt>주최·주관</dt><dd>산학협력단·앵커(RISE)사업단</dd>
        </dl>
      </div>
    </div>

    <div>
      <h2><i>FIRST HALF</i>상반기 수강 127명 구성<small>2026. 1.~6.</small></h2>
      <div class="bar">
        <div style="width:17.3%;background:var(--navy)">초급 <b>22</b></div>
        <div style="width:18.1%;background:var(--blue)">중급 <b>23</b></div>
        <div style="width:14.2%;background:var(--steel)">고급 <b>18</b></div>
        <div style="width:30.7%;background:var(--deep)">AX 아카데미 <b>39</b></div>
        <div style="width:19.7%;background:var(--gold);color:var(--navy)">CEO 특강 <b>25</b></div>
      </div>
      <div class="scale"><span>단계별 과정 63명(49.6%)</span><span>AX전환 재직자 혁신 아카데미·인천비전기업협회 CEO 특강 64명(50.4%)</span></div>
    </div>

    <div class="apply">
      <img src="{{QR:https://indigo.inu.ac.kr/lnc/online/list.do}}" alt="온라인 신청 QR">
      <dl>
        <dt>온라인 신청</dt>
        <dd class="url">indigo.inu.ac.kr/lnc/online/list.do</dd>
        <dd style="font-size:8.4pt;font-weight:500;color:var(--sub)">QR을 찍으면 신청 페이지로 바로 연결</dd>
      </dl>
      <dl>
        <dt>문의</dt>
        <dd>032-835-9758</dd>
        <dd>kirium4u@inu.ac.kr</dd>
      </dl>
    </div>
  </div>

  <div class="ft2"><span>발행 2026. 10. 22.</span><b>인천대학교 산학협력단 산학협력팀</b></div>
</section>
</div></div>

<!--{{FIT_JS}}-->
````