---
name: "inu-print-guide"
description: "INU 지면 패밀리 No.5 실습 가이드형 — 체크박스·복사 칸·증상→해결·원문 카드로 따라 하는 A4 실습 자료(HTML·PDF). 실습 자료·세팅 가이드·설치 매뉴얼·따라하기 요청에 사용."
---

# INU 실습 가이드형 (지면 패밀리 No.5)

읽고 판단하는 보고서가 아니라 **옆에 펴 두고 따라 하는 A4 문서**를 만든다. 모든 줄이 ‘체크할 행동’, ‘복사할 글자’, ‘확인할 결과’ 셋 중 하나로 끝나게 짠다. 처음 해 보는 사람도 어디까지 했는지 잃어버리지 않게 하는 것이 목적이다.

**출처:** AI 모션그래픽 강의(AICONLAB) 「0주차 기본 세팅 체크리스트」(15쪽, HTML을 크롬으로 출력한 PDF)를 2026. 10. 25. 쪽마다 재고 해부한 뒤, 인천대 산학협력단 양식으로 옮긴 것이다. 사용자가 이 자료를 좋아해서 분석을 맡겼고, 분석 결과를 보고 스킬로 만들기로 했다. 분석 보고서(「실습 가이드형 지면 해부 보고서」, 9쪽)가 이 양식의 첫 견본이며, 이 스킬의 도구로 다시 뽑아 검사를 통과했다.

**이 양식의 진짜 힘은 모양보다 문장 습관에 있다(사용자와 합의한 진단).** 카드 모양만 흉내 내면 효과가 반도 안 난다. 「글쓰기 규칙」의 여덟 가지 습관을 부품과 함께 반드시 적용한다.

**규칙의 강도**
- **[필수]** 또는 표시 없는 규칙: 무조건 지킨다. `check.py`가 검사해서 어기면 "고칠 곳"으로 막는다.
- **[권장]**: 기본으로 따르되, 내용상 분명한 이유가 있으면 예외를 둔다. 예외를 두면 전달할 때 한 줄로 이유를 말한다.

산출물은 세 가지다.
1. 완성 HTML 파일(글꼴·로고·이미지가 모두 들어간 한 파일)
2. 같은 HTML을 A4로 인쇄한 PDF
3. 아티팩트 웹 페이지

## 언제 이 양식을 쓰나 (지면 패밀리 5종)

| No | 양식 | 스킬 | 쓸 때 | 판형 | 문체 |
|---|---|---|---|---|---|
| 1 | 지면형 보고서 | inu-print-report | 결과·출장·사업 보고, 결재용 | A4 세로 | 개조식 |
| 2 | 팩트시트 | inu-print-factsheet | 교육·행사 한 장 안내, 배포용 | A4 1쪽 | 개조식 |
| 3 | 컨설팅형 | inu-print-consult | 결론 문장 + 근거 도표, 검토·건의 | A4 가로 | 결론문 |
| 4 | 성과보고서형 | inu-print-annual | 한 해·사업 성과집, 큰 숫자 | A4 매거진 | 개조식 |
| 5 | **실습 가이드형** | **inu-print-guide** | **수강생·실무자가 따라 하는 실습 자료, 설치·사용 매뉴얼** | A4 세로 | **해요체** |

- 바로 쓸 곳(사용자 업무 기준): 가족회사 AI·AX 교육 사전 세팅 가이드, 팀 내 Claude·업무 도구 세팅 매뉴얼, 공동활용 연구장비 사용 가이드(신청 → 예약 → 사용 → 반납, 오류 표시 → 조치), 행사 운영 스태프 체크리스트(D-7·D-1·당일, 돌발 상황 → 대응).
- **결재용에는 쓰지 않는다.** 같은 내용을 결재로 올릴 때는 inu-print-report로 개조식으로 다시 쓴다. 한 문서 안에서 해요체와 개조식을 섞지 않는다.
- 사용자가 ‘따라 하는 자료’를 원하는데 양식을 말하지 않았으면 이 양식을 쓴다. 분량·쪽 수는 되묻지 않고 내용에 맞춰 정한다.

## 작업 순서

1. **원고 확보**
   - 사용자가 준 자료(PDF·DOCX·메모·강의 자료)에서 내용을 뽑는다. 원문 사실만 쓰고 수치·명령어를 지어내지 않는다.
   - 명령어·주소·프롬프트 원문은 **한 글자도 바꾸지 않는다.** 확인되지 않은 명령어는 넣지 않는다.
   - 실측값(걸린 시간 등)은 자료에 있을 때만 쓴다. 없으면 메타 알약에 ‘시범 전’, ‘실행 전’처럼 검증 상태를 쓴다.
2. **도구 파일 만들기**
   - 작업 폴더에 아래 「파일 1~3」을 글자 하나 바꾸지 말고 그대로 저장한다: `template.html`, `build.py`, `check.py`.
3. **로고**
   - 인천대 공식 컬러 로고(파랑+골드, 흰 배경 JPG/PNG)가 필요하다. `/mnt/user-data/uploads/INU_로고.jpg`나 첨부 파일에서 찾는다.
   - 없으면 팀 가족회사 검색기 저장소(`inusanhak5/inu-family-search`, 공개)의 `inu_logo.png`를 받는다: `curl -sS -o inu_logo.png https://raw.githubusercontent.com/inusanhak5/inu-family-search/main/inu_logo.png`
   - 둘 다 안 되면 한 줄로 첨부를 요청한다.
   - build.py가 파란 부분을 네이비 #1F4E79(밝은 바탕용)와 흰색(어두운 바탕용, 골드 심볼 유지) 두 벌로 바꾸고 흰 배경을 투명하게 만든다. 손으로 로고 색을 바꾸지 않는다.
4. **원고 HTML 작성**
   - `template.html`을 `원고.html`로 복사해 `<title>`, `CONFIG`, 표지, 본문 `<section class="sheet">`들을 채운다. 쪽 나누기는 「쪽 구성」을 따른다.
   - 사진·화면 캡처는 작업 폴더 안 상대 경로로 `src="img/파일.png"`처럼 쓴다. build.py가 넣어 준다.
5. **빌드**
   - `python3 build.py 원고.html 로고.jpg out 파일이름`
   - 처음 실행할 때 글꼴(Pretendard 1.3.9, D2Coding 1.3.2)을 `npm pack`으로 받아 `fonts/`에 둔다. 원고에 쓰인 글자만 잘라 넣으므로 파일이 1MB 안팎이다.
6. **검사**
   - `python3 check.py out/파일이름.html out`
   - "결과: 통과"가 나올 때까지 「고칠 곳 처리」대로 고치고 5~6을 반복한다.
7. **눈으로 확인**
   - `out/contact.png`(전체 쪽 한눈에 보기)를 연다. 필요하면 쪽별 `s#.png`도 본다. 겹침·잘림·어색한 빈칸을 본다.
8. **전달**
   - `out/파일이름.html`을 아티팩트로 게시한다(같은 경로로 다시 게시하면 같은 링크가 갱신된다).
   - HTML과 PDF를 파일로 보낸다.
   - 답변에는 쪽 수와 쪽별 채움률만 짧게 쓴다.

**검사 환경**
- `pip install fonttools brotli pillow numpy pypdfium2 playwright --break-system-packages`
- 브라우저가 없을 때만 `playwright install chromium`.
- 설치가 안 되는 항목이 있으면 건너뛴 검사를 전달할 때 말한다.

## 문서 구조

- **1쪽 표지 (`.cover`)** — 원본처럼 밝은 표지. 지면형 보고서의 네이비 전면 표지를 쓰지 않는다.
  - 위: 네이비 로고 + ‘인천대학교 산학협력단’, 오른쪽에 시리즈명과 발행 연월(`.brandrow .series`).
  - 눈썹 줄(`.eyebrow`, 블루) → 큰 제목(`.ct`, 34pt, 2줄 이내) → 리드 2~3문장(무엇을 보며, 무엇을 체크하면, 끝나고 무엇이 생기는지).
  - **준비물 카드 3장(`.facts3`)** — 그중 가장 중요한 한 장만 `.tile.hot`(골드 띠). 골드 카드는 표지에 한 장만.
  - **구성 목차(`.toc data-auto`)** — 본문 부 머리(`.sh`)에서 자동으로 만든다. 보조 설명은 각 `.sh`의 `data-sub`. 쪽 표시는 시작 쪽부터 다음 부 직전 쪽까지(예: 4–5쪽).
    - 목차에서 뺄 부 머리는 `data-toc="no"`. `.sh`가 아닌 곳을 목차에 넣으려면 `data-toc-target data-toc-no="7" data-toc-title="제목" data-sub="설명"`.
  - **쓰는 법(`.callout` + `.ck`)** — 체크박스 줄 2~3개. 문서 전체의 약속(네모 칸은 끝낸 것부터 체크, 회색 칸은 그대로 복사, A1 같은 번호의 뜻)을 쓴다.
  - 맨 아래 발행 줄(`.cfoot`): 발행일 · 인천대학교 산학협력단 산학협력팀.
- **단위 체계 [필수]** — 부(1, 2, 3…) → 편(0-1, 0-2…) → 칸(A1, B2…).
  - 부는 아라비아 숫자 배지. 지면형 보고서의 로마 숫자(Ⅰ, Ⅱ)를 쓰지 않는다. ‘몇 번째 할 일’이라는 순서감을 주기 위해서다.
  - 복사 칸 번호는 편과 짝을 맞춘다(0-2편 = A, 0-3편 = B…). 같은 편 안에서 1부터 센다. 꼭 필요하면 A0처럼 0을 쓴다.
  - 동그라미 숫자(①②③)는 어디에도 쓰지 않는다(사용자 규칙).
- **머리말·꼬리말** — 스크립트가 자동으로 넣는다. 머리말: 왼쪽 네이비 로고 + 오른쪽 `CONFIG.headLabel` + 얇은 회청색 선. 꼬리말: 왼쪽 `CONFIG.docTitle · CONFIG.team`, 오른쪽 ‘N / 전체’. 원본에는 로고·발행처가 없었다. INU판은 반드시 넣는다.
- **끝맺음** — 마지막 쪽은 다크 상시 블록(‘이것만 기억하세요’)이나 결과 확인 체크로 끝내도 된다. ‘— 끝 —’은 쓰지 않는다(따라 하는 문서이므로).

## 부품 8종 (template.html에 모두 들어 있음)

| No | 부품 | 클래스 | 쓸 때 | 규칙 |
|---|---|---|---|---|
| 1 | 숫자 배지 부 머리 | `.sh` > `.n` + `h1` + `.en` | 부마다 쪽 맨 위 | 배지 네이비 7mm, 제목 16pt 한 줄, 오른쪽 영문 라벨(CHECKLIST 등) |
| 2 | 2열 비교 체크표 | `table.cmp` | 길이 둘로 갈릴 때(맥/윈도우, 학내/학외, 신규/기존) | 같은 단계는 `tr.all` + `colspan="2"` + `.same` 칩(‘맥·윈도우 같음’). 해당 없음은 `.skip`(‘— 건너뛰기’). 보충 설명은 `.sub2` |
| 3 | 번호 복사 칸 | `.copy` > `.cl`(`.k` 번호) + `pre.cb` | 명령어·주소·AI에게 할 말 | 표 안에는 ‘복사 칸 A1’만 쓰고 글자는 복사 칸에 모은다. 우리말 문장은 `pre.cb`에 `style="font-family:var(--f);font-size:8.8pt"` |
| 4 | 증상 → 해결 줄 | `.fix` > `.fx`(`.os` + `.sy` + `.to`) | 안 될 때 | 증상은 화면에 뜬 문구를 `<code>`로 그대로. 해결은 한두 문장 |
| 5 | 다크 상시 블록 | `.night` | 문서 전체에 늘 따라붙는 규칙 하나 | 딥 네이비 #14273D, 제목 오른쪽에 흰 로고(골드 심볼). 한 문서에 **종류는 하나**, 같은 블록을 2~3번 되풀이하는 것은 허용 |
| 6 | 원문 카드 | `.pc` | 프롬프트·예문·양식 원문 | 번호 배지 + 제목 + 메타 알약(실측값 또는 검증 상태). ‘한글 뜻’·‘포인트’ 줄, ‘원문 (그대로 복사)’ + `pre.cb`. 남의 자료면 아래에 출처 줄(`.note`) |
| 7 | 묶음 라벨 | `.grp` | 카드가 6장 넘을 때 용도로 묶기 | 칩 ‘묶음 N’ + 13pt 제목 + ‘~할 때’ 한 줄 |
| 8 | 왼쪽 띠 안내 박스 | `.callout` | 본문 전에 꼭 알아야 할 약속 | 빈칸 표시법처럼 문서 전체에 걸리는 규칙에만. 남발하지 않음 |

보조 부품: `.card`(연한 카드 면, 편 하나를 담음), `.ck`(체크박스 줄), `.tile`/`.grid4`(숫자 타일, 주의할 칸만 `.hot`), `table.t`(일반 표, 머리 #E7EEF6 + 네이비 윗선), `.lbl`(작은 소제목), `.note`(메모·출처), `.cont`(다음 쪽으로 이어지는 카드 표시), `.spec`(시범·견본 표시 띠).

## 글쓰기 규칙 (원본에서 찾은 여덟 가지 습관 — 반드시 적용)

1. **해요체 지시문:** ‘~하세요’, ‘~돼요’, ‘~예요’로 끝내 옆에서 말해 주듯 쓴다. 마침표를 찍는다. 짧은 문장.
2. **번호로 서로 가리키기:** 표에는 ‘복사 칸 C1’만, 긴 글자는 복사 칸에 모은다. 표가 짧아지고 복사할 글자가 섞이지 않는다.
3. **두 갈래 길:** ‘말로 먼저, 막히면 직접’. AI에게 말로 시키는 길과 명령어로 하는 길이 있으면 나란히 둔다.
4. **정상 신호 미리 알리기:** ‘비밀번호 칠 때 글자 안 보임 = 정상’, ‘한참 변화 없어도 정상, 창을 닫지 마세요’처럼 불안해서 멈출 순간을 먼저 짚는다. 자료에 그런 순간이 있으면 빠뜨리지 않는다.
5. **실측 숫자로 기대치 맞추기:** ‘강사 실측 10분 22초’처럼 기다릴 시간·걸릴 시간을 자료에 있으면 쓴다.
6. **오류 문구는 화면 그대로:** 증상 제목에 메시지 원문을 쓴다. 읽는 사람은 자기 화면과 글자만 맞춰 보면 된다.
7. **원문 보존 + 뜻 + 요령:** 영어 원문은 한 글자도 안 고치고, 한글 뜻과 ‘포인트’를 따로 단다. 바꿔 쓸 자리는 한글 뜻에서 [기관]처럼 대괄호로 표시하고 「빈칸 [ ] 안내」 박스로 알린다.
8. **검증 상태 드러내기:** 해 본 것(실측값)과 안 해 본 것(‘실행 전’, 반응 수, 출처 링크)을 숨기지 않는다.

**표기 (패밀리 공통, 사용자가 정한 것)**
- 따옴표는 굽은 따옴표 ‘ ’ “ ”. 문서·행사 이름은 「 」.
- 날짜는 공문서식 ‘2026. 10. 25.(일)’.
- 숫자와 단위는 붙인다(‘15쪽’, ‘13칸’).
- **‘평생교육’ 금지:** 재직자 계속교육, 직무역량 강화, 기업 맞춤형 인력양성, 상시 학습체계 등으로 바꾼다(고칠 수 없는 원문 인용만 예외). check.py가 잡는다.
- 남의 브랜드·자료로 만든 예시는 ‘연습용’이라고 밝힌다.

## 시각 규격 (template.html에 구현됨 — 바꾸지 말 것)

**색 (원본 → INU판).** 원본은 회색 다섯 단계에 포인트색 하나(청록, 면적 0.1%)만 쓰고, 강조색(주황)은 표지에서 한 번만 썼다. 이 절제를 그대로 지킨다.

| 역할 | 원본 | INU판 토큰 |
|---|---|---|
| 종이 바탕 | #EFEEEB 전면 회색(면적 45.5%) | 흰 종이 `--paper` #FFFFFF |
| 카드 면 | #FFFFFF | `--card` #F3F6FA |
| 복사 칸·원문 상자 | #F7F6F2 | 흰 상자 + 테두리 `--rule` #D5DDE8 |
| 공통 행 | #FAFAF8 | `--card2` #E7EEF6 |
| 본문 잉크 | #1C1E24 | `--ink` #1B2330 |
| 다크 블록 | #1C1E24 | `--night` #14273D (안쪽 상자 #1D3753, 선 #2D4E72, 보조 글씨 #B9C8DB) |
| 보조 글씨 | #5D606B | `--sub` #4A5566 (연한 글씨 `--faint` #8A97A8) |
| 포인트색(라벨·칩·체크박스) | #2FA39A 청록 | `--blue` #2E75B6 |
| 강조(한 곳) | #E2552D 주황 | `--gold` #FCB01B — **면과 띠에만**, 골드 위 글자는 네이비. 연한 골드 면 `--goldpale` #FFF3D6 |
| 배지·번호 칩 | #1C1E24 | `--navy` #1F4E79 |

- 포인트색은 블루 하나만 쓴다. 블루를 넓은 면에 칠하지 않는다(라벨·칩·체크박스·묶음 칩·안내 띠만).
- 골드는 표지 강조 카드 1장, 주의 타일 1~2칸, 다크 블록 안 강조 글자에만.

**서체 [필수]:** Pretendard(본문·제목) + D2Coding(명령어·번호 칩). build.py가 잘라 넣는다. 원본과 같은 짝이다. Pretendard는 한글과 영문 폭이 고르고 숫자가 반듯해 명령어 옆에서 어울리고, D2Coding은 한글이 섞인 명령어도 칸이 맞는 고정폭이다. (결재용 지면형 보고서는 지금처럼 Noto Sans KR.)

**글자 위계 (원본 PDF 글꼴 정보로 잰 값을 그대로 씀)**

| 요소 | 크기 | 굵기 |
|---|---|---|
| 표지 제목 | 34pt (원본 30pt) | 800 |
| 부 제목 `.sh h1` | 16pt | 800 |
| 묶음 제목 `.grp b` | 13pt | 800 |
| 표지 리드 | 11.5pt | 400 |
| 카드 제목 `.pc .pt` · 편 제목 `.card h3` | 11pt · 10.5pt | 800 |
| 본문·리드 `.lead` | 9.6pt | 400 |
| 표 `.cmp` · 행 머리 | 9pt | 400 · 700 |
| 명령어 `pre.cb` | 8.2pt D2Coding | 400 |
| 메모 `.note` | 8.2pt | 400 |
| 라벨 칩 `.same` · 메타 알약 | 7.6pt · 7.4pt | 700 · 400 |
| 꼬리말 | 7pt | 400 |

**지면 치수:** A4 210×297mm, 좌우 14mm(원본 13mm), 본문 폭 182mm, 본문 위 19mm·아래 14mm, 카드 모서리 2.2mm, 카드 안 여백 약 4~5mm, 덩어리 사이 3.6mm, 꼬리말은 바닥에서 7mm.

## 조판 규칙 (템플릿에 구현됨 — 끄지 말 것)

- **어절 단위 줄바꿈 [필수]:** `word-break:keep-all` + `line-break:strict`. 단어가 줄 끝에서 잘리지 않는다(사용자 규칙). 원본은 이 설정이 없어 단어 중간 줄바꿈이 10곳(예: 7쪽 ‘그 부/분만’) 있었다.
- **왼쪽 정렬:** 명령어·영문과 섞이므로 양쪽 정렬을 쓰지 않는다(지면형 보고서와 다른 점).
- **마지막 줄 한 단어 금지 [필수]:** 보정 스크립트가 자간을 최대 -0.03em 줄여 끌어올리고, 안 되면 마지막 두 단어를 붙여 함께 내린다.
- **긴 주소·명령어는 반드시 복사 칸으로 [필수]:** 표 칸·본문에 긴 주소를 넣지 않는다. 원본 2쪽 ‘git-/scm.com’이 표 칸에서 끊긴 결함 때문이다. 복사 칸 안에서는 아주 긴 덩어리만 줄을 넘길 수 있고(`overflow-wrap:anywhere`), check.py는 이것을 ‘참고’로만 알린다.
- **제목 한 줄 [필수]:** 부 제목, 편 제목, 카드 제목, 묶음 제목, 목차 줄은 한 줄. 넘치면 문구를 줄인다.
- **흰 종이 [필수]:** 종이 전면에 색을 칠하지 않는다. 원본의 전면 회색 바탕은 사무실 프린터에서 가장자리 4~5mm가 흰 테두리로 남고 토너를 많이 쓴다. 회색 느낌은 카드 면으로만 낸다.
- **화면 = 인쇄 [필수]:** 같은 크롬 엔진으로 PDF를 뽑으므로 모양이 같아야 한다. `@media print` 규칙과 인쇄 때만 바뀌는 스타일을 건드리지 않는다.
- **로고:** 밝은 바탕은 네이비 로고, 다크 블록 안은 흰 로고(골드 심볼 유지). 모든 쪽에 로고가 있어야 한다(표지는 brandrow, 본문은 머리말).

## 쪽 구성과 고칠 곳 처리

- **쪽 단위로 쓴다:** `<section class="sheet" data-page="N">` 하나가 종이 한 장. data-page는 1부터 차례대로.
- **부 시작:** 부는 앞쪽 공간이 넉넉하면 쪽 중간에서 시작해도 된다. 부를 새 쪽으로 넘기느라 빈칸을 만들지 않는다.
- **카드 나누기:** 원본은 카드를 쪽 사이에서 자르지 않기만 해서 쪽 아래가 크게 비었다(2·5·11쪽 60% 안팎). INU판은 긴 카드(편, 표)를 쪽 끝에서 나누고 새 쪽 맨 위에 `<p class="cont">0-3 작업 폴더 (계속)</p>`를 단다. 표는 행 중간에서 나누지 않는다. 짧은 카드(원문 카드 1장, 증상 줄 1개)는 나누지 않는다.
- **검사 기준 (check.py가 판정):**
  - 넘침 0, 가로 넘침 0
  - 쪽 채움 85% 이상(표지는 발행 줄 위 공간 기준 85%, 마지막 쪽은 50%)
  - 단어 중간 줄바꿈 0, 마지막 줄 한 단어 0, 두 줄 제목 0
  - 모든 쪽 로고, 이동할 곳 없는 목차 링크 0
  - ‘평생교육’ 0, 동그라미 숫자 0
  - 글꼴 내장 확인(Pretendard·D2Coding이 실제로 쓰였는지 — 조용한 대체 글꼴 방지)
  - PDF 쪽 수 = 지면 수
  - 화면과 인쇄 대조: 쪽마다 1.5% 이하(정상 0.7% 미만, 본문이 3mm만 밀려도 13% 이상으로 잡힘)
- **넘칠 때 (이 순서로):**
  1. 맨 아래 덩어리를 다음 쪽 맨 위로 옮기고, 긴 카드면 `(계속)`으로 나눈다.
  2. 해당 쪽 `.body`에 `style="gap:3mm"`을 줘 덩어리 사이를 좁힌다.
  3. 문장을 줄인다. 글자 크기 규칙은 바꾸지 않는다.
- **85% 미만일 때 (이 순서로):**
  1. 다음 쪽 첫 덩어리를 끌어올린다.
  2. 해당 쪽 `.body`에 `style="gap:4.2~5mm"`을 줘 덩어리 사이를 넓힌다(최대 5mm).
  3. 자료에 있는 내용으로 보탠다: 증상 → 해결 줄 하나, 복사 칸 하나, 확인 체크 줄, ‘이것만 기억하세요’ 블록. 없는 사실은 만들지 않는다.
- **템플릿 그대로 빌드하면** 1·2쪽이 85%에 못 미쳐 실패한다. 정상이다. 내용을 채우면 통과한다.

## 왜 이 규칙인가 (원본 측정 결과, 2026. 10. 25.)

규칙을 고치고 싶어질 때 먼저 읽는다.
- **만든 방식:** PDF 기록상 HeadlessChrome 156 · Skia/PDF, 태그 붙은 PDF, 2.2MB. 우리 지면 패밀리와 같은 ‘HTML로 짜고 크롬으로 PDF 뽑기’ 방식이라 그대로 옮겨 올 수 있었다.
- **구성:** 15쪽, 다섯 부분(편별 체크리스트 2–3쪽 · 복사 모음 4–5쪽 · 안 될 때 6쪽 · 원샷 17종 7–11쪽 · 더 해 보기 13종 12–15쪽), 원문 카드 30장(11묶음), 복사 칸 13칸(A1~A4 · B1~B3 · C1~C5 · D1).
- **색 면적(15쪽 픽셀 집계):** 바탕 회색 45.5%, 카드 흰색 30.2%, 코드 상자 11.5%, 공통 행 2.6%, 잉크·다크 2.2%, 포인트 청록 0.1%, 주황 0.01%.
- **원본의 약점 (패밀리 검사 기준으로 채점):** 화면=인쇄 통과, 빈 쪽 없음 통과. 쪽 채움은 본문 14쪽 중 6쪽만 85% 통과(평균 80.6%, 최저 5쪽 57.7%). 단어 중간 줄바꿈 10곳 + 주소 끊김 1곳. 마지막 줄 조각(2쪽 ‘칸 A3)’). 로고·발행처 없음. 뒤쪽 7쪽부터 같은 카드가 30장 이어져 단조로움(참고 자료라 허용하되, 묶음 라벨로 끊어 준다).
- **원본에서 그대로 가져온 것:** 숫자 배지·편·칸 번호 체계, 2열 비교 체크표와 ‘같음’ 칩, 번호 복사 칸, 증상 → 해결 줄, 원문 카드, 다크 상시 블록, 해요체와 여덟 가지 습관, Pretendard + D2Coding.
- **INU판에서 바꾼 것:** 청록 → INU 블루, 주황 → 골드(면만), 회색 바탕 → 흰 종이 + 연한 카드 면, 로고 머리말과 발행처 꼬리말, 어절 단위 줄바꿈과 자간 보정, 85% 채움 검사, 긴 카드 ‘(계속)’ 분할, 긴 주소·명령어는 복사 칸으로.
- **이 스킬의 검증:** 견본 보고서(9쪽)를 이 템플릿·build.py·check.py로 다시 뽑아 통과(채움 85.3~98.9%). 일부러 어절 줄바꿈을 끄고 금지어·동그라미 숫자·넘치는 카드를 넣은 원고로 검사기가 각각 잡아내는 것을 확인했다.


## 파일 1: template.html

````html
<title>{{문서 이름: 두~네 단어}}</title>
<meta name="claude:viewport-fit-sides" content="cover">
<style>
{{FONTFACE}}
/* 실습 가이드형(INU 지면 패밀리 No.5): A4 흰 종이 = .sheet. 좌우 14mm, 본문 폭 182mm. 연한 카드 면 위에 체크박스·복사 칸·원문 카드를 쌓는 '따라 하는 문서'. 종이는 늘 흰색, 종이 뒤 책상 배경만 테마를 따름 */
:root{
  --navy:#1F4E79; --blue:#2E75B6; --sky:#9DC3E6; --gold:#FCB01B; --goldpale:#FFF3D6;
  --ink:#1B2330; --sub:#4A5566; --faint:#8A97A8; --rule:#D5DDE8; --card:#F3F6FA; --card2:#E7EEF6; --paper:#FFFFFF;
  --night:#14273D; --night2:#1D3753; --nightline:#2D4E72; --nightsub:#B9C8DB;
  --desk:#E4E8EE; --desk-fg:#4A5566;
  --f:'Pretendard','Noto Sans KR','Malgun Gothic','맑은 고딕',sans-serif;
  --m:'D2Coding','Consolas','Menlo',monospace;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}}
:root[data-theme="dark"]{--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}
*{box-sizing:border-box}
body{background:var(--desk);color:var(--ink);font-family:var(--f);margin:0;word-break:keep-all;overflow-wrap:break-word;line-break:strict;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.doc{padding-block:24px 40px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
.stack{zoom:var(--z,1);display:flex;flex-direction:column;align-items:center;gap:10mm}
.sheet{position:relative;width:210mm;height:297mm;background:var(--paper);overflow:hidden;letter-spacing:-.01em;box-shadow:0 1px 2px rgba(20,30,50,.12),0 8px 24px rgba(20,30,50,.10);flex:none}
p{margin:0}

/* 머리·꼬리 */
.hd{position:absolute;top:8.5mm;left:14mm;right:14mm;display:flex;align-items:center;justify-content:space-between;padding-bottom:1.6mm;border-bottom:.25mm solid var(--rule)}
.hd img{height:4.6mm;display:block}
.hd span{font-size:7.2pt;color:var(--faint);letter-spacing:.02em}
.ft{position:absolute;bottom:7mm;left:14mm;right:14mm;display:flex;justify-content:space-between;font-size:7pt;color:var(--faint);font-variant-numeric:tabular-nums}
.body{position:absolute;top:19mm;bottom:14mm;left:14mm;right:14mm;overflow:hidden;display:flex;flex-direction:column;gap:3.6mm}

/* 부 머리: 숫자 배지 + 제목 + 영문 라벨 */
.sh{display:flex;align-items:center;gap:2.8mm}
.sh .n{width:7mm;height:7mm;border-radius:1.3mm;background:var(--navy);color:#fff;font-size:11pt;font-weight:800;display:flex;align-items:center;justify-content:center;flex:none}
.sh h1{margin:0;font-size:16pt;font-weight:800;letter-spacing:-.02em;line-height:1.2}
.sh .en{margin-left:auto;font-size:7pt;font-weight:700;color:var(--blue);letter-spacing:.22em}
.lead{font-size:9.6pt;color:var(--sub);line-height:1.65;margin-top:-1mm}
.lead b{color:var(--ink)}

/* 카드·라벨 */
.card{background:var(--card);border-radius:2.2mm;padding:3.8mm 4.6mm;display:flex;flex-direction:column;gap:2.2mm}
.card h3,.h3{margin:0;font-size:10.5pt;font-weight:800;display:flex;align-items:baseline;gap:2mm;line-height:1.3}
.card h3 small,.h3 small{font-size:8.6pt;font-weight:600;color:var(--sub)}
.lbl{margin:0;font-size:10.5pt;font-weight:800}
.note{font-size:8.2pt;color:var(--sub);line-height:1.55}
code{font-family:var(--m);font-size:.9em;background:var(--paper);border:.25mm solid var(--rule);border-radius:.8mm;padding:0 .8mm}
.same{font-size:7.6pt;font-weight:700;color:var(--blue);margin-left:1.6mm;white-space:nowrap}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:3mm}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:3mm}
.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:3mm}

/* 체크박스 줄 */
.ck{position:relative;padding-left:5mm;line-height:1.55}
.ck::before{content:"";position:absolute;left:0;top:.26em;width:3mm;height:3mm;border:.35mm solid var(--blue);border-radius:.7mm;background:var(--paper)}
.skip{color:var(--faint)}
.sub2{display:block;font-size:8pt;color:var(--sub);margin-top:.4mm}

/* 2열 비교 체크표 */
table.cmp{width:100%;border-collapse:collapse;font-size:9pt}
table.cmp thead th{font-size:8.2pt;font-weight:700;color:var(--sub);text-align:left;padding:0 1.6mm 1mm}
table.cmp tbody th{text-align:left;font-weight:700;vertical-align:top;padding:1.8mm 1.6mm 1.8mm 0;white-space:nowrap}
table.cmp td{vertical-align:top;padding:1.8mm 1.6mm;border-bottom:.25mm solid var(--rule)}
table.cmp tbody th{border-bottom:.25mm solid var(--rule)}
table.cmp tr.all td{background:var(--card2)}
table.cmp tr:last-child td,table.cmp tr:last-child th{border-bottom:0}

/* 번호 복사 칸 */
.copy{display:flex;flex-direction:column;gap:1.3mm}
.copy .cl{font-size:8.6pt;font-weight:700;display:flex;align-items:center;gap:1.8mm}
.k{font-family:var(--m);font-weight:700;font-size:8pt;background:var(--navy);color:#fff;border-radius:.8mm;padding:.2mm 1.3mm;letter-spacing:0}
pre.cb{margin:0;background:var(--paper);border:.25mm solid var(--rule);border-radius:1.4mm;padding:2mm 2.8mm;font-family:var(--m);font-size:8.2pt;line-height:1.6;white-space:pre-wrap;word-break:normal;overflow-wrap:anywhere;color:var(--ink)}

/* 증상 → 해결 */
.fix{display:flex;flex-direction:column;gap:1.4mm}
.fx{display:grid;grid-template-columns:auto 1fr;gap:1.6mm 2.4mm;align-items:start;background:var(--card);border-radius:1.6mm;padding:2mm 3mm;font-size:8.8pt;line-height:1.55}
.os{font-size:7.4pt;font-weight:700;border:.25mm solid var(--navy);color:var(--navy);border-radius:.8mm;padding:0 1.2mm;margin-top:.3mm;white-space:nowrap}
.fx .sy{font-weight:700}
.fx .sy code{background:var(--card2);border-color:var(--card2)}
.fx .to{color:var(--sub)}
.fx .to::before{content:"→";color:var(--blue);font-weight:700;margin-right:1.4mm}

/* 다크 상시 블록 */
.night{background:var(--night);color:#fff;border-radius:2.2mm;padding:3.6mm 4.6mm;display:flex;flex-direction:column;gap:2mm}
.night h3{margin:0;font-size:10pt;font-weight:800;display:flex;align-items:center;gap:2mm}
.night h3 img{height:4mm;margin-left:auto}
.night pre{margin:0;background:var(--night2);border:.25mm solid var(--nightline);border-radius:1.4mm;padding:2mm 2.8mm;font-family:var(--m);font-size:8.2pt;line-height:1.6;white-space:pre-wrap;color:#fff}
.night p{font-size:8.5pt;color:var(--nightsub);line-height:1.6}
.night b{color:var(--gold)}

/* 묶음 라벨 */
.grp{display:flex;align-items:baseline;gap:2.4mm}
.grp .gk{font-size:7.6pt;font-weight:700;background:var(--blue);color:#fff;border-radius:.8mm;padding:.4mm 1.6mm;align-self:center}
.grp b{font-size:13pt;font-weight:800;letter-spacing:-.02em}
.grp span{font-size:9pt;color:var(--sub)}

/* 원문 카드 */
.pc{background:var(--card);border-radius:2.2mm;padding:3.4mm 4.2mm;display:flex;flex-direction:column;gap:1.6mm}
.pc .ph{display:flex;align-items:center;gap:2.2mm}
.pc .pn{font-family:var(--m);font-weight:700;font-size:9.5pt;background:var(--navy);color:#fff;border-radius:1mm;padding:.3mm 1.5mm}
.pc .pt{font-size:11pt;font-weight:800}
.pc .meta{margin-left:auto;font-size:7.4pt;color:var(--sub);border:.25mm solid var(--rule);background:var(--paper);border-radius:9mm;padding:.4mm 2.4mm;white-space:nowrap}
.pc .row{display:grid;grid-template-columns:12mm 1fr;gap:2mm;font-size:9pt;line-height:1.55}
.pc .row i{font-style:normal;font-size:7.6pt;font-weight:700;color:var(--blue);padding-top:.35mm}
.pc .src{font-size:7.6pt;font-weight:700;color:var(--blue)}

/* 안내 박스 */
.callout{background:var(--card);border-left:1.2mm solid var(--blue);border-radius:0 2mm 2mm 0;padding:3mm 4mm;font-size:9pt;line-height:1.6}
.callout b{font-weight:800}

/* 분석용 표 */
table.t{width:100%;border-collapse:collapse;font-size:8.6pt;line-height:1.45;font-variant-numeric:tabular-nums}
table.t thead th{background:var(--card2);color:var(--navy);font-weight:800;text-align:left;padding:1.4mm 1.8mm;border-top:.5mm solid var(--navy);border-bottom:.25mm solid var(--navy)}
table.t td{padding:1.3mm 1.8mm;border-bottom:.2mm solid var(--rule);vertical-align:middle}
table.t td.h{font-weight:700;white-space:nowrap}
table.t td.c{text-align:center}
table.t td div+div{margin-top:.4mm}
table.t .mono{font-family:var(--m);font-size:8pt}
.sw{display:inline-block;width:5mm;height:5mm;border-radius:1mm;vertical-align:middle;border:.2mm solid rgba(0,0,0,.12)}
.arrow{color:var(--blue);font-weight:700}

/* 숫자 타일 */
.tile{background:var(--card);border-radius:2.2mm;padding:3mm 3.6mm;display:flex;flex-direction:column;gap:.6mm}
.tile i{font-style:normal;font-size:7.6pt;font-weight:700;color:var(--sub)}
.tile strong{font-size:19pt;font-weight:800;line-height:1.05;color:var(--navy);font-variant-numeric:tabular-nums;letter-spacing:-.02em}
.tile strong small{font-size:9pt;font-weight:700;margin-left:.6mm}
.tile span{font-size:8pt;color:var(--sub);line-height:1.45}
.tile.hot{background:var(--goldpale)}
.tile.hot strong{color:var(--navy)}

/* 부품 카탈로그 */
.comp{display:grid;grid-template-columns:44mm 1fr;gap:5mm;padding-top:3mm;border-top:.25mm solid var(--rule)}
.comp:first-of-type{border-top:0;padding-top:0}
.cd{display:flex;flex-direction:column;gap:1.4mm}
.cd .cn{display:flex;align-items:center;gap:1.6mm;font-size:7.4pt;font-weight:700;color:var(--blue);letter-spacing:.06em}
.cd .cn b{width:4.4mm;height:4.4mm;border-radius:.9mm;background:var(--blue);color:#fff;font-size:7.6pt;display:flex;align-items:center;justify-content:center;letter-spacing:0}
.cd h4{margin:0;font-size:11pt;font-weight:800;line-height:1.3}
.cd p{font-size:8.2pt;color:var(--sub);line-height:1.55}
.cd p em{font-style:normal;font-weight:700;color:var(--navy)}
.demo{min-width:0;display:flex;flex-direction:column;gap:2mm}

/* 원본 썸네일 */
.thumbs{display:grid;grid-template-columns:repeat(5,1fr);gap:3mm}
.thumbs figure{margin:0;display:flex;flex-direction:column;gap:1.2mm}
.thumbs img{width:100%;display:block;border-radius:1mm;border:.25mm solid var(--rule)}
.thumbs figcaption{font-size:7.4pt;color:var(--sub);line-height:1.4}
.thumbs figcaption b{color:var(--ink)}

/* 채움률 막대 */
.fill{display:grid;grid-template-columns:8mm 1fr;gap:0 2mm}
.fill .ax{position:relative;height:42mm;font-size:6.8pt;color:var(--faint)}
.fill .ax span{position:absolute;right:0;transform:translateY(50%)}
.fill .plot{position:relative;height:42mm;display:grid;grid-template-columns:repeat(15,1fr);gap:1.6mm;align-items:end;border-bottom:.3mm solid var(--sub)}
.fill .gl{position:absolute;left:0;right:0;border-top:.2mm solid var(--rule)}
.fill .th{position:absolute;left:0;right:0;border-top:.35mm dashed var(--navy);z-index:2}
.fill .th em{position:absolute;right:0;top:-4mm;font-style:normal;font-size:7pt;font-weight:700;color:var(--navy);background:var(--card);padding:0 1mm}
.fill .b{position:relative;background:var(--navy);border-radius:1mm 1mm 0 0;z-index:1}
.fill .b.low{background:var(--gold)}
.fill .b.last{background:var(--sky)}
.fill .b span{position:absolute;bottom:100%;left:50%;transform:translateX(-50%);font-size:6.6pt;font-weight:700;color:var(--ink);padding-bottom:.6mm;white-space:nowrap;font-variant-numeric:tabular-nums}
.fill .xl{grid-column:2;display:grid;grid-template-columns:repeat(15,1fr);gap:1.6mm;font-size:6.8pt;color:var(--sub);text-align:center;margin-top:1mm}
.legend{display:flex;gap:4mm;font-size:7.4pt;color:var(--sub);align-items:center}
.legend i{display:inline-block;width:3mm;height:3mm;border-radius:.6mm;margin-right:1.2mm;vertical-align:-.4mm}

/* 표지 */
.cover .body{top:14mm;bottom:12mm;gap:5mm}
.brandrow{display:flex;align-items:center;gap:3.2mm}
.brandrow img{height:9mm;display:block}
.brandrow span{font-size:8.6pt;font-weight:700;color:var(--navy);line-height:1.35;border-left:.3mm solid var(--rule);padding-left:3.2mm}
.brandrow .series{margin-left:auto;border:0;text-align:right;font-size:7.4pt;font-weight:700;color:var(--blue);letter-spacing:.14em}
.brandrow .series b{display:block;font-size:10pt;color:var(--ink);letter-spacing:0}
.eyebrow{font-size:9pt;font-weight:800;color:var(--blue);letter-spacing:.06em;margin-top:14mm}
.ct{margin:-1.5mm 0 1mm;font-size:34pt;font-weight:800;line-height:1.2;letter-spacing:-.03em;text-wrap:balance}
.cover .lead{font-size:11.5pt;line-height:1.65;margin:0}
.facts3 .tile{padding:3.6mm 4mm;gap:1mm}.facts3 .tile strong{font-size:13pt;line-height:1.35;letter-spacing:-.01em}
.facts3 .tile.hot{box-shadow:inset 0 1.2mm 0 var(--gold)}
.toc{display:flex;flex-direction:column}
.toc a{display:grid;grid-template-columns:8mm 1fr auto;gap:2mm;align-items:baseline;padding:2.6mm 0;border-bottom:.25mm solid var(--rule);font-size:9.4pt;color:inherit;text-decoration:none}
.toc a i{font-style:normal;font-weight:800;color:var(--navy)}
.toc a b{font-weight:700}
.toc a small{font-size:8.2pt;color:var(--sub);font-weight:400;margin-left:2mm}
.toc a span{font-size:8.6pt;color:var(--sub);font-variant-numeric:tabular-nums}
.cfoot{margin-top:auto;display:flex;justify-content:space-between;align-items:flex-end;font-size:8.4pt;color:var(--sub);border-top:.25mm solid var(--rule);padding-top:2.4mm}
.cfoot b{color:var(--navy);font-size:9.6pt}

/* 다음 쪽으로 이어지는 카드·묶음 */
.cont{margin:0;font-size:8.6pt;font-weight:700;color:var(--blue);letter-spacing:.02em}

/* 시범 지면 표시 */
.spec{display:flex;align-items:center;gap:2mm;font-size:8pt;color:var(--sub);background:var(--goldpale);border-radius:1.6mm;padding:1.6mm 3mm}
.spec b{background:var(--gold);color:var(--navy);font-size:7.6pt;font-weight:800;border-radius:.8mm;padding:.3mm 1.6mm}

@media print{
  @page{size:A4;margin:0}
  body{background:#fff}
  .doc{padding:0}
  .stack{zoom:1!important;gap:0}
  .sheet{box-shadow:none;break-after:page}
}
</style>

<div class="doc"><div class="stack">

<!-- ===== 표지 (1쪽) — 목차는 본문 부 머리(.sh)에서 자동으로 만듦 ===== -->
<section class="sheet cover" data-page="1">
 <div class="body">
  <div class="brandrow"><img src="{{LOGO_NAVY}}" alt="INU"><span>인천대학교<br>산학협력단</span><span class="series">INU 실습 가이드<b>2026. 10.</b></span></div>
  <p class="eyebrow">실습 가이드 · 과정 이름</p>
  <h1 class="ct">0차시 기본 세팅<br>체크리스트</h1>
  <p class="lead">무엇을 보면서, 무엇을 하나씩 체크하면, 끝나고 무엇이 생기는지 두세 문장으로 써요. 해요체로 써요.</p>
  <p class="lbl">시작 전에 준비할 것</p>
  <div class="grid3 facts3">
   <div class="tile"><i>컴퓨터</i><strong>macOS 14 이상<br>Windows 11</strong><span>보충 설명 한두 줄</span></div>
   <div class="tile hot"><i>꼭 필요한 것</i><strong>강조할 준비물<br>한 가지</strong><span>골드 띠 카드는 표지에 한 장만</span></div>
   <div class="tile"><i>인터넷</i><strong>항상 연결</strong><span>보충 설명 한두 줄</span></div>
  </div>
  <p class="lbl">이 자료 구성</p>
  <nav class="toc" data-auto></nav>
  <p class="lbl">쓰는 법</p>
  <div class="callout" style="display:flex;flex-direction:column;gap:1.2mm">
   <p class="ck">네모 칸은 끝낸 것부터 체크하세요.</p>
   <p class="ck">회색 칸 안의 글자는 그대로 복사해서 붙여 넣으세요. 표의 A1, B1은 복사 칸 번호예요.</p>
  </div>
  <div class="cfoot"><span>발행 2026. 10. 25.(일)</span><b>인천대학교 산학협력단 산학협력팀</b></div>
 </div>
</section>

<!-- ===== 본문 쪽: data-page=쪽 번호. 부 머리 .sh의 data-sub가 표지 목차의 보조 설명이 됨 ===== -->
<section class="sheet" data-page="2">
 <div class="body">
  <div class="sh" data-sub="0-1 ~ 0-2 · 맥과 윈도우 두 칸"><div class="n">1</div><h1>편별 체크리스트</h1><span class="en">CHECKLIST</span></div>
  <p class="lead">이 부에서 할 일을 한두 문장으로 써요. <b>꼭 기억할 말</b>만 굵게 해요.</p>
  <div class="card">
   <h3>0-1 시작 전에 준비할 것<small>컴퓨터 · 요금제</small></h3>
   <table class="cmp"><colgroup><col style="width:24mm"><col><col></colgroup>
    <thead><tr><th></th><th>맥</th><th>윈도우</th></tr></thead>
    <tbody>
     <tr><th>터미널 열기</th><td><p class="ck">Command+스페이스 → ‘터미널’</p></td><td><p class="ck">Win+X → Windows PowerShell<span class="sub2">줄 앞 PS 확인 · 관리자 권한 필요 없음</span></p></td></tr>
     <tr><th>먼저</th><td><span class="skip">— 건너뛰기</span></td><td><p class="ck">(권장) Git for Windows 설치<span class="sub2">주소는 복사 칸 A0</span></p></td></tr>
     <tr><th>설치 한 줄</th><td><p class="ck">복사 칸 <b>A1</b> 붙여 넣고 Enter</p></td><td><p class="ck">복사 칸 <b>A2</b> 붙여 넣고 Enter</p></td></tr>
     <tr class="all"><th>설치 확인</th><td colspan="2"><p class="ck">창을 새로 열고 <code>claude --version</code><span class="same">맥·윈도우 같음</span></p></td></tr>
    </tbody></table>
   <p class="note">돈이 드는 것과 무료인 것처럼, 표 아래에 붙일 메모 한 줄</p>
  </div>
  <div class="grid2">
   <div class="copy"><div class="cl"><span class="k">A1</span>맥 — 설치 한 줄 (터미널)</div><pre class="cb">curl -fsSL https://claude.ai/install.sh | bash</pre></div>
   <div class="copy"><div class="cl"><span class="k">A2</span>윈도우 — 설치 한 줄 (PowerShell)</div><pre class="cb">irm https://claude.ai/install.ps1 | iex</pre></div>
  </div>
  <div class="copy"><div class="cl"><span class="k">B1</span>맥 · 윈도우 — Claude에게 말로</div><pre class="cb" style="font-family:var(--f);font-size:8.8pt">내 문서 폴더 안에 실습 폴더 만들어 줘</pre></div>
  <p class="lbl">안 될 때</p>
  <div class="fix">
   <div class="fx"><span class="os">맥</span><div><span class="sy"><code>command not found: claude</code></span><div class="to">해결 방법을 한 줄로</div></div></div>
   <div class="fx"><span class="os">윈도우</span><div><span class="sy">화면에 뜬 증상을 그대로</span><div class="to">정상이에요. 기다리면 돼요처럼 안심시키는 말도 여기에</div></div></div>
  </div>
  <div class="night">
   <h3>이것만 기억하세요<img src="{{LOGO_WHITE}}" alt="INU"></h3>
   <p>문서 전체에 늘 따라붙는 규칙 하나만 둬요. 강조는 <b>골드 글자</b>로.</p>
  </div>
 </div>
</section>

<section class="sheet" data-page="3">
 <div class="body">
  <div class="sh" data-sub="용도별 묶음 · 원문 그대로 복사"><div class="n">2</div><h1>원샷 프롬프트</h1><span class="en">PROMPTS</span></div>
  <p class="lead">카드 묶음의 쓰는 법을 한두 문장으로 써요.</p>
  <div class="callout"><b>빈칸 [ ] 안내</b> — 한글 뜻에서 [ ]로 표시한 자리는 바꿔 쓰는 빈칸이에요.</div>
  <div class="night">
   <h3>모든 프롬프트 끝에 붙일 한 줄<img src="{{LOGO_WHITE}}" alt="INU"></h3>
   <pre>When done, render it to result.mp4 (capture frames with Playwright, encode with ffmpeg; include audio if you made any).</pre>
   <p>뜻: 다 만들면 result.mp4로 뽑아 줘. 원문 다음 줄에 <b>이 한 줄</b>을 이어 붙이세요.</p>
  </div>
  <div class="grp"><span class="gk">묶음 1</span><b>출시 · 홍보</b><span>제품 · 서비스를 알릴 때</span></div>
  <div class="pc">
   <div class="ph"><span class="pn">01</span><span class="pt">카드 제목</span><span class="meta">영상 30초 · 걸린 시간 8분 3초</span></div>
   <div class="row"><i>한글 뜻</i><span>원문의 뜻을 한두 문장으로. 바꿔 쓸 자리는 [기관]처럼 표시.</span></div>
   <div class="row"><i>포인트</i><span><b>이 프롬프트가 잘 되는 이유</b> → 결과가 어떻게 달라지는지</span></div>
   <span class="src">원문 (그대로 복사)</span>
   <pre class="cb">Original prompt text goes here, character for character.</pre>
  </div>
  <div class="grid4">
   <div class="tile"><i>지표 이름</i><strong>15<small>쪽</small></strong><span>보충 설명</span></div>
   <div class="tile"><i>지표 이름</i><strong>30<small>장</small></strong><span>보충 설명</span></div>
   <div class="tile hot"><i>주의할 지표</i><strong>8<small>곳</small></strong><span>골드 면은 주의 · 강조 한두 칸만</span></div>
   <div class="tile"><i>지표 이름</i><strong>2<small>벌</small></strong><span>보충 설명</span></div>
  </div>
  <div class="card">
   <h3>표 제목<small>보조 설명</small></h3>
   <table class="t">
    <colgroup><col style="width:30mm"><col><col style="width:40mm"></colgroup>
    <thead><tr><th>구분</th><th>내용</th><th>비고</th></tr></thead>
    <tbody>
     <tr><td class="h">항목</td><td><div>한 칸 안 여러 줄은</div><div>div로 한 줄씩</div></td><td>메모</td></tr>
     <tr><td class="h">항목</td><td>내용</td><td class="c">0</td></tr>
    </tbody>
   </table>
  </div>
  <!-- 카드가 다음 쪽으로 이어지면 새 쪽 맨 위에 <p class="cont">0-3 작업 폴더 (계속)</p> -->
 </div>
</section>

</div></div>

<script>
/* 문서 설정: 스킬이 문서마다 채움 */
var CONFIG={
  docTitle:'AI 실습 0차시 기본 세팅 체크리스트',          /* 꼬리말 왼쪽 */
  team:'인천대학교 산학협력단 산학협력팀',              /* 꼬리말 왼쪽 뒤 */
  headLabel:'인천대학교 산학협력단 · INU 실습 가이드'   /* 머리말 오른쪽 */
};
/* 머리말·꼬리말 삽입(표지는 머리말 없음), 표지 목차 자동 생성, 화면 폭 맞춤 */
(function(){
  var C=CONFIG, sheets=[].slice.call(document.querySelectorAll('.sheet')), N=sheets.length;
  sheets.forEach(function(s){
    var p=+s.dataset.page;
    if(!s.classList.contains('cover')){
      var hd=document.createElement('div'); hd.className='hd';
      hd.innerHTML='<img src="{{LOGO_NAVY}}" alt="INU"><span>'+C.headLabel+'</span>';
      s.prepend(hd);
    }
    var ft=document.createElement('div'); ft.className='ft';
    ft.innerHTML='<span>'+C.docTitle+' · '+C.team+'</span><span>'+p+' / '+N+'</span>';
    s.appendChild(ft);
  });
  /* 목차: 표지가 아닌 쪽의 부 머리(.sh)마다 한 줄. data-toc="no"면 뺌. data-toc-no·data-toc-title로 번호·제목을 바꿀 수 있음.
     쪽 표시는 그 부가 시작하는 쪽부터 다음 부 직전 쪽까지(예: 4–5쪽) */
  var toc=document.querySelector('.toc[data-auto]');
  if(toc){
    var items=[].slice.call(document.querySelectorAll('.sheet:not(.cover) .sh')).filter(function(h){return h.dataset.toc!=='no';});
    var tgt=[].slice.call(document.querySelectorAll('.sheet:not(.cover) [data-toc-target]'));
    items=items.concat(tgt).sort(function(a,b){return a.compareDocumentPosition(b)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1;});
    var rows=items.map(function(h,k){
      if(!h.id)h.id='part-'+(k+1);
      var n=h.dataset.tocNo||((h.querySelector('.n')||{}).textContent||''), t=h.dataset.tocTitle||((h.querySelector('h1')||{}).textContent||'');
      return {id:h.id,n:n,t:t,sub:h.dataset.sub||'',p:+h.closest('.sheet').dataset.page};
    });
    toc.innerHTML=rows.map(function(r,k){
      var end=k+1<rows.length?rows[k+1].p-1:N; if(end<r.p)end=r.p;
      var pg=end>r.p?r.p+'–'+end+'쪽':r.p+'쪽';
      return '<a href="#'+r.id+'"><i>'+r.n+'</i><b>'+r.t+(r.sub?'<small>'+r.sub+'</small>':'')+'</b><span>'+pg+'</span></a>';
    }).join('');
  }
  function fitz(){ var w=document.documentElement.clientWidth-32; document.documentElement.style.setProperty('--z',Math.min(1,w/794).toFixed(4)); }
  fitz(); addEventListener('resize',fitz);
  addEventListener('beforeprint',function(){document.documentElement.style.setProperty('--z','1');});
  addEventListener('afterprint',fitz);
})();
</script>
<script>
/* 조판 보정(수정 금지): 마지막 줄 한 단어 금지 — 자간을 최대 -0.03em까지 줄여 끌어올리고, 안 되면 마지막 두 단어를 붙여 함께 내림. 끝나면 html[data-fit=done] */
(function(){
  var rg=document.createRange();
  function chars(el){var a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n;while(n=w.nextNode())for(var i=0;i<n.data.length;i++)a.push([n,i]);return a;}
  function top(c){rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);var r=rg.getClientRects();return r.length?r[r.length-1].top:null;}
  function info(el){var A=chars(el),txt=A.map(function(c){return c[0].data[c[1]];}).join('');var e=txt.replace(/\s+$/,'').length-1;if(e<1)return{lines:1,widow:false};
    var lt=top(A[e]),s=e;while(s>0){var ch=txt[s-1];if(/\s/.test(ch)){s--;continue;}var t=top(A[s-1]);if(t===null||Math.abs(t-lt)>2)break;s--;}
    var first=top(A[0]),lines=1,prev=first;for(var i=1;i<=e;i++){if(/\s/.test(txt[i]))continue;var t=top(A[i]);if(t!==null&&t-prev>2){lines++;prev=t;}}
    return{lines:lines,widow:lines>1&&!/\s/.test(txt.slice(s,e+1).trim()),A:A,txt:txt,s:s};}
  function em(el){return parseFloat(getComputedStyle(el).letterSpacing)/parseFloat(getComputedStyle(el).fontSize)||0;}
  function glue(el,I){var k=I.txt.slice(0,I.s).replace(/\s+$/,'').length;var c=I.A[k];if(c&&c[0].data[c[1]]===' '){c[0].data=c[0].data.slice(0,c[1])+String.fromCharCode(160)+c[0].data.slice(c[1]+1);}}
  window.__guideInfo=info;
  window.__guideSel='.sheet .lead, .sheet .ck, .sheet .note, .sheet .callout, .sheet .card > p, .sheet .grid2 .card p, .sheet .cd p, .sheet td, .sheet .to, .sheet .night p, .sheet .pc .row span, .sheet .tile span, .sheet figcaption';
  function run(){
    document.querySelectorAll(window.__guideSel).forEach(function(el){
      if(el.querySelector('div,ul,table,pre'))return;
      var I=info(el);if(!I.widow)return;var base=em(el),L=I.lines;
      for(var d=.005;d<=.0301;d+=.005){el.style.letterSpacing=(base-d).toFixed(3)+'em';var J=info(el);if(!J.widow&&J.lines<=L)return;}
      el.style.letterSpacing='';glue(el,info(el));});
    document.documentElement.dataset.fit='done';
  }
  if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){setTimeout(run,30);});else setTimeout(run,300);
})();
</script>
````

## 파일 2: build.py

````python
"""INU 실습 가이드형 빌드: 원고 HTML → 글꼴 부분집합·로고·이미지 내장 → 단일 HTML 한 장
사용: python3 build.py 원고.html 로고(jpg/png) out 파일이름
- 글꼴: Pretendard(400·500·600·700·800) + D2Coding(400·700)을 원고에 쓰인 글자만 잘라 woff2로 내장
  (작업 폴더 fonts/에 없으면 npm pack으로 받음 — npm 레지스트리는 작업 환경에서 열려 있음)
- 로고: 공식 로고의 파란 부분을 네이비(#1F4E79)·흰색으로 바꾼 두 벌을 만듦(골드 심볼은 그대로, 흰 배경은 투명 처리)
- 이미지: 원고의 src="상대경로" 중 실제 파일이 있는 것은 data URI로 바꿔 넣음
결과 HTML 하나로 아티팩트·PDF·오프라인 열람이 모두 같은 모양으로 나옴
"""
import base64, io, os, re, subprocess, sys, pathlib, tarfile, mimetypes

def die(m):
    print('실패:', m); sys.exit(1)

if len(sys.argv) < 5:
    die('사용법: python3 build.py 원고.html 로고.jpg out 파일이름')
SRC, LOGO, OUT, NAME = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3]), sys.argv[4]
OUT.mkdir(parents=True, exist_ok=True)
HERE = pathlib.Path.cwd()

try:
    from fontTools import subset
    from fontTools.ttLib import TTFont
    import brotli  # noqa: F401  (woff2 압축)
    from PIL import Image
    import numpy as np
except ImportError:
    die('pip install fonttools brotli pillow numpy --break-system-packages 를 먼저 실행')

# ---------- 1. 글꼴 확보 ----------
FD = HERE / 'fonts'; FD.mkdir(exist_ok=True)
PKGS = {'pretendard': 'pretendard@1.3.9', 'd2coding': 'd2coding@1.3.2'}
def fetch(key):
    d = FD / key
    if d.exists():
        return d
    r = subprocess.run(['npm', 'pack', PKGS[key], '--silent'], cwd=FD, capture_output=True, text=True)
    tgz = [l for l in r.stdout.split() if l.endswith('.tgz')]
    if r.returncode or not tgz:
        die(f'{PKGS[key]} 내려받기 실패: {r.stderr.strip()[:200]}')
    d.mkdir()
    with tarfile.open(FD / tgz[-1]) as t:
        try:
            t.extractall(d, filter='data')
        except TypeError:
            t.extractall(d)
    return d
PR = fetch('pretendard') / 'package/dist/public/static/alternative'
D2 = fetch('d2coding') / 'package/src'

src = SRC.read_text(encoding='utf-8')
text = re.sub(r'<[^>]+>', ' ', src)
extra = (' 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
         '.,:;!?()[]{}<>/\\|-_=+*&^%$#@~`"\'‘’“”·—–→←↑↓…▲●■◦※「」『』')
uni = sorted({ord(c) for c in set(text) | set(extra) if ord(c) > 31})

def face(path, family, weight):
    f = TTFont(str(path))
    o = subset.Options(); o.flavor = 'woff2'; o.layout_features = ['*']; o.name_IDs = []
    s = subset.Subsetter(o); s.populate(unicodes=uni); s.subset(f)
    b = io.BytesIO(); f.flavor = 'woff2'; f.save(b)
    return ("@font-face{font-family:'%s';font-weight:%d;font-style:normal;font-display:block;"
            "src:url(data:font/woff2;base64,%s) format('woff2')}" % (family, weight, base64.b64encode(b.getvalue()).decode()))

import logging; logging.getLogger('fontTools').setLevel(logging.ERROR)
faces = [face(PR / f'Pretendard-{n}.ttf', 'Pretendard', w) for n, w in
         [('Regular', 400), ('Medium', 500), ('SemiBold', 600), ('Bold', 700), ('ExtraBold', 800)]]
faces += [face(D2 / 'd2coding.ttf', 'D2Coding', 400), face(D2 / 'd2coding-bold.ttf', 'D2Coding', 700)]

# ---------- 2. 로고 두 벌 ----------
if not LOGO.exists():
    die(f'로고 파일 없음: {LOGO}')
im = Image.open(LOGO).convert('RGBA'); a = np.asarray(im).astype(int)
r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
white = (r > 235) & (g > 235) & (b > 235)
a[..., 3] = np.where(white, 0, al)                       # 흰 배경 → 투명
blue = (b > r + 40) & (b > g) & (a[..., 3] > 0)          # 파란 글자 부분
if blue.sum() < 50:
    die('로고에서 파란 부분을 찾지 못함 — 공식 컬러 로고(파랑+골드)를 쓰세요')
def variant(rgb):
    o = a.copy(); o[blue, 0], o[blue, 1], o[blue, 2] = rgb
    ys, xs = np.where(o[..., 3] > 0)
    o = o[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    buf = io.BytesIO(); Image.fromarray(o.astype('uint8'), 'RGBA').save(buf, 'PNG', optimize=True)
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()
LOGO_NAVY, LOGO_WHITE = variant((0x1F, 0x4E, 0x79)), variant((255, 255, 255))

# ---------- 3. 내장 ----------
html = src.replace('{{FONTFACE}}', '\n'.join(faces)).replace('{{LOGO_NAVY}}', LOGO_NAVY).replace('{{LOGO_WHITE}}', LOGO_WHITE)
def inline(m):
    p = (SRC.parent / m.group(2)).resolve()
    if m.group(2).startswith(('data:', 'http')) or not p.is_file():
        return m.group(0)
    mime = mimetypes.guess_type(str(p))[0] or 'application/octet-stream'
    return f'{m.group(1)}data:{mime};base64,' + base64.b64encode(p.read_bytes()).decode() + m.group(3)
html = re.sub(r'(src=")([^"]+)(")', inline, html)
left = re.findall(r'\{\{[^}]+\}\}', html)
if left:
    die('채우지 않은 자리표시: ' + ', '.join(sorted(set(left))[:8]))
out = OUT / f'{NAME}.html'
out.write_text(html, encoding='utf-8')
mb = len(html.encode()) / 1024 / 1024
print(f'완성: {out}  ({mb:.2f}MB, 글자 {len(uni)}자 내장)')
if mb > 15:
    print('경고: 16MB 아티팩트 한도에 가까움 — 이미지 크기를 줄이세요')
````

## 파일 3: check.py

````python
"""INU 실습 가이드형 검사: 화면 지면을 재고, A4 PDF를 뽑아 화면과 쪽마다 대조
사용: python3 check.py out/파일이름.html out
결과: out/파일이름.pdf, out/s#.png(쪽별), out/contact.png(한눈에 보기), 끝줄에 '결과: 통과' 또는 '결과: 고칠 곳 N건'
"""
import sys, pathlib, json
if len(sys.argv) < 3:
    print('사용법: python3 check.py out/파일이름.html out'); sys.exit(1)
HTML, OUT = pathlib.Path(sys.argv[1]).resolve(), pathlib.Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)
NAME = HTML.stem
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print('pip install playwright --break-system-packages 후, 브라우저가 없으면 playwright install chromium'); sys.exit(1)

JS = r"""() => {
  const mm = 96/25.4, R = [], info = window.__guideInfo, sel = window.__guideSel;
  const fontsOK = document.fonts.check("10pt Pretendard") && document.fonts.check("10pt D2Coding")
      && [...document.fonts].some(f => f.family.replace(/['"]/g,'') === 'Pretendard' && f.status === 'loaded');
  const sheets = [...document.querySelectorAll('.sheet')];
  sheets.forEach((s, i) => {
    const b = s.querySelector('.body'), BR = b.getBoundingClientRect(), z = BR.height / b.offsetHeight || 1;
    const kids = [...b.children].filter(c => c.getBoundingClientRect().height > 0);
    const cover = s.classList.contains('cover');
    let fill;
    if (cover) {           // 표지: 발행 줄(.cfoot)을 뺀 내용이 그 위 공간을 얼마나 채웠나
      const cf = b.querySelector('.cfoot'), cfTop = cf ? cf.getBoundingClientRect().top : BR.bottom;
      let bot = BR.top; kids.filter(c => c !== cf).forEach(c => bot = Math.max(bot, c.getBoundingClientRect().bottom));
      fill = (bot - BR.top) / (cfTop - BR.top - 4*mm*z) * 100;
    } else {
      let bot = BR.top; kids.forEach(c => bot = Math.max(bot, c.getBoundingClientRect().bottom));
      fill = (bot - BR.top) / BR.height * 100;
    }
    let lastBot = BR.top; kids.forEach(c => lastBot = Math.max(lastBot, c.getBoundingClientRect().bottom));
    const squished = kids.filter(c => c.scrollHeight > c.clientHeight + 2).length;   // 줄어들어 내용이 잘린 덩어리
    const over = Math.max(b.scrollHeight - b.clientHeight, Math.round((lastBot - BR.bottom) / z), squished ? 1 : 0) > 1 ? Math.max(b.scrollHeight - b.clientHeight, 2) : 0;
    const wide = [...s.querySelectorAll('pre,table,.card,.fx,.pc,.night,.callout,.tile')]
      .filter(e => e.scrollWidth > e.clientWidth + 1).map(e => e.className || e.tagName);
    // 단어 중간 줄바꿈: 띄어쓰기 없는 한 덩어리의 첫 글자와 끝 글자가 다른 줄
    const rg = document.createRange(), breaks = [], preBreaks = [];
    const w = document.createTreeWalker(s, NodeFilter.SHOW_TEXT); let n;
    while (n = w.nextNode()) {
      if (n.parentElement.closest('svg,script,style')) continue;
      const inPre = !!n.parentElement.closest('pre');
      const re = /\S{2,}/g; let m;
      while (m = re.exec(n.data)) {
        rg.setStart(n, m.index); rg.setEnd(n, m.index + 1); const a = rg.getClientRects()[0];
        rg.setStart(n, m.index + m[0].length - 1); rg.setEnd(n, m.index + m[0].length); const c = rg.getClientRects()[0];
        if (a && c && Math.abs(c.top - a.top) > 3) (inPre ? preBreaks : breaks).push(m[0].slice(0, 24));
      }
    }
    const widows = [...s.querySelectorAll(sel)].filter(el => !el.querySelector('div,ul,table,pre') && info(el).widow)
      .map(el => el.textContent.trim().slice(-16));
    const twoLine = [...s.querySelectorAll('.sh h1,.card > h3,.grp b,.pc .pt,.toc a b,.cd h4')]
      .filter(h => info(h).lines > 1).map(h => h.textContent.trim().slice(0, 20));
    const logo = cover ? !!s.querySelector('.brandrow img') : !!s.querySelector('.hd img');
    R.push({page: +s.dataset.page, cover, fill: Math.round(fill*10)/10, over, wide, breaks, preBreaks, widows, twoLine, logo});
  });
  const deadLinks = [...document.querySelectorAll('a[href^="#"]')].filter(a => !document.getElementById(a.getAttribute('href').slice(1))).length;
  const txt = document.body.innerText;
  return {fontsOK, R, deadLinks, n: sheets.length,
          banned: (txt.match(/평생교육/g)||[]).length, circled: (txt.match(/[①-⑳]/g)||[]).length,
          pages: sheets.map(s => s.dataset.page)};
}"""

fails, warns = [], []
with sync_playwright() as p:
    br = p.chromium.launch()
    pg = br.new_page(viewport={'width': 900, 'height': 1200}, device_scale_factor=150/96)
    pg.goto(HTML.as_uri())
    try:
        pg.wait_for_function("document.documentElement.dataset.fit==='done'", timeout=30000)
    except Exception:
        fails.append('조판 보정 스크립트가 끝나지 않음(html[data-fit=done] 없음) — 템플릿 스크립트를 지웠는지 확인')
    pg.wait_for_timeout(300)
    d = pg.evaluate(JS)
    for i, s in enumerate(pg.query_selector_all('.sheet'), 1):
        s.screenshot(path=str(OUT / f's{i}.png'))
    pg.emulate_media(media='print')
    pdf = OUT / f'{NAME}.pdf'
    pg.pdf(path=str(pdf), format='A4', print_background=True, prefer_css_page_size=True,
           margin={'top': '0', 'bottom': '0', 'left': '0', 'right': '0'})
    br.close()

if not d['fontsOK']:
    fails.append('글꼴이 내장되지 않음(Pretendard·D2Coding) — build.py로 빌드한 파일인지 확인')
if [str(i) for i in range(1, d['n'] + 1)] != d['pages']:
    fails.append(f"data-page가 1부터 차례대로가 아님: {d['pages']}")
last = d['n']
print('쪽  채움   넘침  비고')
for r in d['R']:
    need = 85 if (r['cover'] or r['page'] != last) else 50
    note = []
    if r['over'] > 1: fails.append(f"{r['page']}쪽 넘침 {r['over']}px"); note.append('넘침')
    if r['fill'] < need: fails.append(f"{r['page']}쪽 채움 {r['fill']}% < {need}%"); note.append('채움 부족')
    if r['wide']: fails.append(f"{r['page']}쪽 가로 넘침: {r['wide'][:3]}")
    if r['breaks']: fails.append(f"{r['page']}쪽 단어 중간 줄바꿈 {len(r['breaks'])}곳: {r['breaks'][:4]}")
    if r['preBreaks']: warns.append(f"{r['page']}쪽 복사 칸 안 긴 덩어리 줄바꿈 {len(r['preBreaks'])}곳(허용, 확인만): {r['preBreaks'][:3]}")
    if r['widows']: fails.append(f"{r['page']}쪽 마지막 줄 한 단어 {len(r['widows'])}곳: {r['widows'][:3]}")
    if r['twoLine']: fails.append(f"{r['page']}쪽 두 줄 제목: {r['twoLine'][:3]}")
    if not r['logo']: fails.append(f"{r['page']}쪽 로고 없음")
    print(f"{r['page']:>2}  {r['fill']:5.1f}%  {r['over']:>4}  {'표지' if r['cover'] else ''} {' '.join(note)}")
if d['deadLinks']: fails.append(f"이동할 곳 없는 목차 링크 {d['deadLinks']}개")
if d['banned']: fails.append(f"'평생교육' {d['banned']}곳 — 재직자 계속교육·직무역량 강화 등으로 바꿈")
if d['circled']: fails.append(f"동그라미 숫자 {d['circled']}곳 — 쓰지 않음")

# PDF 쪽 수와 화면·인쇄 대조
try:
    import pypdfium2 as pdfium
    from PIL import Image, ImageChops, ImageFilter
    import numpy as np
    doc = pdfium.PdfDocument(str(pdf))
    if len(doc) != d['n']:
        fails.append(f'PDF {len(doc)}쪽 ≠ 지면 {d["n"]}쪽 (빈 쪽 또는 쪽 밀림)')
    else:
        W = (210 * 4, 297 * 4)
        for i in range(len(doc)):
            a = doc[i].render(scale=150 / 72).to_pil().convert('L').resize(W, Image.BOX).filter(ImageFilter.GaussianBlur(2))
            b = Image.open(OUT / f's{i+1}.png').convert('L').resize(W, Image.BOX).filter(ImageFilter.GaussianBlur(2))
            diff = (np.asarray(ImageChops.difference(a, b)) > 24).mean() * 100
            if diff > 1.5:
                fails.append(f'{i+1}쪽 화면과 인쇄가 다름 {diff:.2f}% (정상 0.7% 미만, 3mm 밀리면 13% 이상)')
    # 한눈에 보기
    ims = [Image.open(OUT / f's{i}.png').convert('RGB') for i in range(1, d['n'] + 1)]
    w0, h0 = ims[0].size; sc = 0.36; cw, ch = int(w0 * sc), int(h0 * sc); cols = min(5, len(ims)); rows = (len(ims) + cols - 1) // cols
    sheet = Image.new('RGB', (cols * (cw + 12) + 12, rows * (ch + 12) + 12), (200, 205, 212))
    for k, im in enumerate(ims):
        sheet.paste(im.resize((cw, ch), Image.LANCZOS), (12 + (k % cols) * (cw + 12), 12 + (k // cols) * (ch + 12)))
    sheet.save(OUT / 'contact.png')
except ImportError:
    warns.append('pypdfium2·pillow·numpy가 없어 화면·인쇄 대조를 건너뜀(pip install pypdfium2 pillow numpy)')

print(f'PDF: {pdf}')
for w in warns: print('참고:', w)
if fails:
    for f in fails: print('고칠 곳:', f)
    print(f'결과: 고칠 곳 {len(fails)}건')
else:
    print('결과: 통과')
json.dump(d, open(OUT / 'check.json', 'w'), ensure_ascii=False)
````