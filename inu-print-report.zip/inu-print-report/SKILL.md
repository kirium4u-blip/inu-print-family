---
name: "inu-print-report"
description: "INU 산학협력단 지면형 보고서 — 한글 간행물처럼 줄이 맞는 A4 인쇄용 HTML 보고서와 PDF를 만든다. '지면형 보고서', 'SPRi 스타일', 'A4 인쇄용 HTML 보고서', '결재용 HTML 보고서' 요청에 사용. DOCX가 필요하면 inu-report-master."
---

# INU 지면형 보고서

화면형(인터랙티브) HTML이 아니라 **종이 A4가 기준인 HTML 보고서**를 만든다. SPRi AI 브리프(한글로 조판한 간행물)의 조판 규칙을 인천대 산학협력단 양식으로 옮긴 것이다. 겉보기는 단순하지만 품질은 눈에 안 보이는 조판에서 나온다: 어절 단위 줄바꿈, 마지막 줄 한 단어 금지, 띄어쓰기 고르기, 쪽마다 85% 이상 채움.

**최우선 기준(사용자가 정함):** 인쇄물이 A4 규격과 디자인 그대로 나와야 하고, 인쇄 전 화면에서도 규칙대로 맞아 있어야 한다. 화면과 인쇄(PDF)가 조금이라도 다르면 실패다. `check.py`가 PDF를 그림으로 그려 화면 지면과 쪽마다 대조한다.

**규칙의 강도:** 이 문서의 규칙은 두 가지다.
- **[필수]** 또는 표시 없는 규칙: 무조건 지킨다. `check.py`가 검사해서 어기면 "고칠 곳"으로 막는다.
- **[권장]**: 기본으로 따르되, 내용상 분명한 이유가 있으면 예외를 둘 수 있다. 검사에서 막지 않고 작성자가 판단한다. 예외를 두면 전달할 때 한 줄로 이유를 말한다.

산출물은 세 가지다.
1. 완성 HTML 파일
2. 같은 HTML을 A4로 인쇄한 PDF
3. 아티팩트 웹 페이지

## 작업 순서

1. **원고 확보**
   - 사용자가 준 자료(PDF·DOCX·엑셀·메모)에서 내용을 뽑는다. 원문 사실만 쓰고 수치를 지어내지 않는다.
   - 기존 보고서를 바꾸는 작업이면 문장은 그대로 두고 아래 표기 규칙만 적용한다.
2. **도구 파일 만들기**
   - 작업 폴더에 아래 「파일 1~3」을 글자 하나 바꾸지 말고 그대로 저장한다: `template.html`, `build.py`, `check.py`.
3. **로고**
   - 인천대 로고 이미지(흰 배경 JPG/PNG)가 필요하다. `/mnt/user-data/uploads/INU_로고.jpg`나 첨부 파일에서 찾는다.
   - 없으면 한 줄로 첨부를 요청한다.
   - 이전 지면형 보고서 PDF가 있으면 `pdfimages -j`로 로고를 뽑아 써도 된다.
   - 팀 가족회사 검색기 저장소(`inusanhak5/inu-family-search`, 공개)의 `inu_logo.png`도 공식 로고라 쓸 수 있다.
   - **투명 배경 PNG는 흰 배경에 합쳐 JPG로 저장한 뒤 쓴다.** build.py는 흰 배경 기준이라 투명 PNG를 그대로 넣으면 투명 부분이 검게 처리된다.
4. **원고 HTML 작성**
   - `template.html`을 복사해 `<title>`, `CONFIG`, 표지, 본문 `<section class="sheet">`들을 채운다. 쪽 나누기는 「쪽 구성」을 따른다.
5. **빌드**
   - `python3 build.py 원고.html 로고.jpg out 파일이름`
6. **검사**
   - `python3 check.py out/파일이름.html out`
   - "결과: 통과"가 나올 때까지 「고칠 곳 처리」대로 고치고 5~6을 반복한다.
7. **눈으로 확인**
   - `out/contact.png`(전체 쪽 한눈에 보기)를 열어 본다. 필요하면 쪽별 `s#.png`도 본다.
8. **전달**
   - `out/파일이름_artifact.html`을 아티팩트로 게시한다(같은 경로로 다시 게시하면 같은 링크가 갱신된다).
   - `out/파일이름.html`과 PDF를 파일로 보낸다.
   - 답변에는 쪽 수와 쪽별 채움률만 짧게 쓴다.

**검사 환경**
- `check.py`는 Python Playwright를 쓴다. 없으면 `pip install playwright --break-system-packages`을 실행하고, 브라우저가 없을 때만 `playwright install chromium`을 실행한다.
- 화면·인쇄 모양 대조에는 `pypdfium2`, PDF 링크 도착 쪽 확인에는 `pypdf`가 필요하다. 없으면 `pip install pypdfium2 pypdf --break-system-packages`. 설치가 안 되면 그 두 검사만 건너뛰었다고 전달할 때 말한다.
- 그래도 안 되면 HTML만 전달하고 검사를 못 했다고 말한다.

## 보고서 구조 (산학협력단 표준)

- **1쪽 표지 (`.cover`)**
  - 위쪽 네이비 면: 흰 로고, 보고 종류(pill), 제목 3줄 이내, 부제.
  - **골드 꺾쇠 두 개가 제목을 감싼다**(사용자가 고른 E안):
    - 위 꺾쇠는 제목 오른쪽 위, 아래 꺾쇠는 부제 아래 왼쪽에 둔다. 크기는 각 30mm다.
    - 제목 묶음은 파란 면 가운데보다 살짝 아래(`.ttl` bottom 50mm)에 놓고, 아래 꺾쇠와 부제 사이는 약 5mm 띄운다.
    - 위치는 템플릿 스크립트(`placeCover`)가 제목 길이에 맞춰 자동으로 잡는다.
    - 꺾쇠를 자르거나 종이 끝에 붙이지 않는다(사무실 프린터에서 가장자리 4~5mm가 잘리기 때문).
  - 아래쪽: 핵심 정보 4칸(`.facts`: 일시·장소·주관·참석 등), 목차(`.toc data-auto`, 장 시작 쪽을 자동으로 채움), 발행일·산학협력팀.
  - **목차 배치 [필수]:** 3칸으로 채우고 장이 늘면 줄이 늘어난다(6개 2줄, 9개 3줄, 12개 4줄).
    - 목차 제목은 반드시 한 줄이다. 3칸에서 두 줄로 꺾이는 제목이 하나라도 있으면 보정 스크립트가 2칸(`.toc.two`)으로 바꾸고, 그래도 넘치면 자간을 최대 -0.04em 좁힌다. 그래도 두 줄이면 장 제목 문구를 줄인다.
    - 목차가 4줄 이상이라 표지 아래가 넘치면 보정 스크립트가 간격(5mm→3.5mm→목차 줄 높이→2.5mm)을 단계적으로 좁힌다. 그래도 넘치면 장을 묶거나 핵심 정보 칸 문구를 줄인다.
  - 표지에 빈 공간을 남기지 않는다.
- **본문 장 구성:** Ⅰ. 보고 개요 → Ⅱ. 핵심 요약 → Ⅲ~. 본문 → 마지막 장 시사점 및 향후 추진 제언 → `— 끝 —`.
  - 앞의 개요·요약과 마지막 제언은 고정이다. 가운데 장의 수와 이름은 자료 내용에 맞춰 정한다(교육 결과면 운영 현황·만족도·성과, 출장이면 방문 기관·협의 내용·후속 조치 등).
  - **장 수 [권장]:** 6~8개를 목표로 한다. 10개 이상이면 장이 잘게 쪼개졌다는 신호로 보고 비슷한 장을 묶어 정리한다(예: 추진 배경·추진 경과 → 보고 개요, 1부·2부 → 주요 프로그램 내용, 만족도·예산 → 운영 성과). 나눠야 할 이유가 분명하면 12개까지 허용한다(12개까지 지면이 깨지지 않음을 확인함).
  - **`CONFIG.chapters` 한 줄 = 장 하나:** `['Ⅲ','참석자','참석자 구성']` = [로마 숫자, 색띠 탭 이름, 장 제목]. 탭 이름은 세로로 좁은 탭에 들어가므로 2~4글자로 짧게, 장 제목은 본문 장 머리·표지 목차에 쓰는 긴 이름이다. 영문 라벨(OVERVIEW 등)도 장 내용에 맞춰 정한다.
- **장 머리 (`.ch`):** 로마 숫자 + 영문 라벨(OVERVIEW, SUMMARY…) + 장 제목. 장마다 시작 쪽에 반드시 둔다. 쪽 중간에서 시작하면 위에 추가 여백이 자동으로 붙는다(「조판 규칙」의 장 머리 위 여백). `.no`의 로마 숫자가 `CONFIG.chapters`와 같아야 탭·목차 링크가 그 장 머리로 정확히 이동한다.
- **핵심 포인트 박스 (`.key`):**
  - 장마다 장 머리 바로 아래에 둔다.
  - ◦ 요약 문장 2개, 강조는 `<em>`.
  - Ⅱ장 박스 이름은 '한 줄 결론', 문장 1개는 `p.plain`.
  - Ⅵ장은 박스 대신 종합 결론을 맨 끝 `.key > .kb > p.concl`로 둔다.
- **절 제목 (`h2`):** "1. 절 제목". ①②③ 같은 동그라미 숫자는 쓰지 않는다.
- **본문 목록 (`ul.l`):**
  - 1단계는 ■ 네이비 사각형, 10pt.
  - 2단계(`ul.l2`, ● 9.5pt 가는 글씨)는 하위 설명이 실제로 있을 때만 쓴다.
  - 머리말은 `<b>`, 분류 태그는 `<span class="tag">`.
- **발표자 줄:** `<p class="who"><b>발표</b>소속 이름 직위</p>`
- **표:**
  - 머리 #D9E2F3, 짝수 행 #F2F2F2, 합계 행 `tr.sum`.
  - 한 칸 안 여러 줄은 `<div>`로 한 줄씩 쓰고 글머리 기호(•)는 쓰지 않는다.
  - 첫 열은 `td.h`, 숫자 열은 `td.c`.
- **숫자 지표가 4~8개면:** 표 대신 `.kpi` 타일(4열)로 보여 준다.
- **전체 중 구성 비율:** `.bar` 구성 막대(폭 %는 실제 비율로 계산)를 쓴다.
- **주석:** `<p class="note">※ …</p>`
- **다음 쪽으로 이어지는 절:** 새 쪽 맨 위에 `<p class="cont">2. 절 제목 (계속)</p>`.

## 표기 규칙 (사용자가 정한 것 — 반드시 지킴)

- **개조식 명사형 종결, 끝 마침표 없음:** 목록·핵심 포인트·주석·결론 모두 '~함', '~발표', '~필요'로 끝낸다. 한 항목 안에서 문장이 둘로 나뉠 때만 중간 마침표를 쓴다.
- **따옴표:** 굽은 따옴표 ‘ ’ “ ”를 쓴다. 문서·행사·법령 이름은 「 」로 감싼다.
- **날짜:** 공문서식 '2026. 10. 14.(수)'으로 쓴다(점 뒤 띄움).
- **단위:** 숫자와 단위를 붙인다('19개사', '46명').
- **'평생교육' 금지:** 재직자 계속교육, 직무역량 강화, 기업 맞춤형 인력양성 등으로 바꾼다(고칠 수 없는 원문 인용만 예외).
- **로고:** 모든 산출물에 넣는다. 밝은 바탕은 네이비, 어두운 바탕은 흰 글자 + 골드 심볼(템플릿에 이미 들어 있음).

## 조판 규칙 (템플릿과 build.py에 구현됨 — 끄지 말 것)

- **줄바꿈:** 어절 단위(`word-break:keep-all`) + 양쪽 정렬로 단어가 줄 끝에서 잘리지 않는다. build.py는 줄바꿈 보조 문자를 넣는다.
  - '간담회(제5차)'처럼 괄호가 붙은 말은 한 단어로 묶는다.
  - 가운뎃점은 앞에서는 줄을 바꾸지 않고, 뒤에서는 줄바꿈을 허용한다(줄 첫머리에 '·'가 오지 않게).
- **기본 자간:** -0.02em, 줄간격 160%.
- **문단 간격 위계:** 큰 덩어리일수록 간격을 넓혀 묶음이 눈에 보이게 한다.
  - 장 머리 위(쪽 중간에서 시작할 때) 약 12mm: 절 간격 4mm + 추가 여백 8mm
  - 절(`.sec`) 사이 4mm(넘치는 쪽만 `tight`로 3mm)
  - 1단계 항목 사이 2.1mm, 2단계 항목 사이 1.1mm
  - SPRi 원본은 ■ 앞이 약 3.4mm, ● 앞이 약 1.1mm였다.
- **장 머리 위 여백 [필수] (사용자 결정, 2026. 10. 19.):** 앞 절과 다음 장 머리 사이가 절과 절 사이(4mm)와 같으면 장이 앞 내용에 붙어 숨이 막혀 보인다. 장은 절보다 큰 단위이므로 간격도 커야 한다.
  - 쪽 중간에서 시작하는 장 머리에만 추가 여백 8mm를 둔다(CSS `.body > .ch:not(:first-child)`, 변수 `--chgap`). 쪽 맨 위에서 시작하는 장은 머리말 아래라 이미 여유가 있으므로 더하지 않는다.
  - 구분선·배경 띠 같은 장식은 더하지 않고 여백만으로 나눈다.
  - **다음 쪽으로 밀지 않는다:** 이 여백 때문에 장을 다음 쪽으로 넘기거나 쪽 나누기를 새로 만들지 않는다(사용자가 싫어함). 그 쪽이 넘치면 보정 스크립트 ⑦이 추가 여백을 4mm→2mm→0 순으로 먼저 줄인다.
  - 넘침 0, 쪽 채움 85% 이상 검사는 그대로다. `check.py` 결과에 쪽별 추가 여백이 표시되며, 8mm 미만이면 그 쪽이 꽉 차서 자동으로 줄어든 것이다.
- **줄 첫머리 문장부호 금지:** `line-break:strict`로 쉼표·닫는 괄호·가운뎃점이 줄 첫머리에 오지 않게 한다. 표 칸에서 손으로 줄을 나눌 때도 '·'는 앞줄 끝에 둔다(예: `산학협력단·<br>비전기업협회`).
- **마지막 줄 한 단어 금지:** 템플릿의 보정 스크립트가 해당 문단 자간을 최대 -0.03em 더 줄여 단어를 윗줄로 올린다. 안 되면 마지막 두 단어를 붙여 함께 내린다.
- **띄어쓰기 고르기:** 양쪽 정렬로 0.55em보다 넓게 벌어진 문단은 자간을 -0.045~+0.03em 안에서 다시 고른다.
- **제목 한 줄:** `h2`와 장 제목이 넘치면 자간을 줄여 한 줄로 맞춘다. 그래도 넘치면 제목 문구를 줄인다.
- **글자 크기 (바꾸지 않음):**

| 요소 | 크기 |
|---|---|
| 본문·핵심 포인트·결론 | 10pt |
| 2단계 | 9.5pt (300) |
| 표 | 9pt (칸이 좁아 줄이 넘치는 표만 해당 `table`에 `style="font-size:8.5pt"`) |
| 주석 | 8.5pt |
| 절 제목 | 11.5pt |
| 장 제목 | 17pt |

- **색띠 (`CONFIG.mode`):**
  - 기본값 `'single'`(사용자가 정한 기본값): 모든 쪽 오른쪽에 장 색인 탭을 둔다. 단면 출력·결재용이다.
  - 사용자가 '양면', '책자'를 말하면 `'book'`: 홀수쪽은 탭, 짝수쪽은 왼쪽에 발행물명.
- **색띠 탭 높이 [필수]:** 장 수에 맞춰 자동으로 나눈다. 위 24mm·아래 17mm를 뺀 256mm를 장 수로 나누되 최대 27mm다(6개는 27mm, 9개 27mm, 12개 약 21mm). 탭 글자가 탭보다 길면 보정 스크립트가 자간→글자 크기(최소 7pt) 순으로 줄이고, 그래도 넘치면 검사에서 실패하므로 탭 이름을 줄인다.
- **장 이동 링크 [필수] — 보이는 변화 0:** 색띠의 각 탭과 표지 목차의 각 줄은 누르면 그 장 머리로 이동하는 링크다(`href="#ch-N"`, 스크립트가 자동으로 만듦).
  - HTML에서 누르면 그 장으로 가고, 크롬으로 만든 PDF에서도 링크가 살아 있어 일반 PDF 뷰어(크롬·엣지·한컴·어도비)에서 누르면 그 쪽으로 간다.
  - 링크는 모양을 바꾸지 않는다: 밑줄·색 바뀜·마우스 올림 효과·눌림 애니메이션·버튼 모양을 넣지 않는다(마우스 커서가 손가락으로 바뀌는 것만 허용). 이것을 넣는 순간 화면형이 된다.
  - 종이 인쇄에는 아무 흔적이 없다. 링크를 넣기 전과 후의 PDF를 픽셀 단위로 비교해 완전히 같음을 확인했다(2026. 10. 15.).
  - 장 시작 쪽에 장 머리가 없으면 그 쪽 맨 위에 보이지 않는 1px 표지를 둔다. 크기 0인 표지는 크롬 PDF가 엉뚱한 쪽으로 보내므로 쓰지 않는다.
- **머리말·꼬리말:** 머리말은 왼쪽 네이비 로고 + 오른쪽 "인천대학교 산학협력단 산학협력팀" + 파란 선, 꼬리말은 "- N -".

## 쪽 구성과 고칠 곳 처리

- **쪽 단위로 쓴다:** 한 `<section class="sheet" data-page="N" data-ch="장번호">`가 종이 한 장이다. 한 쪽에 두 장이 걸치면 `data-ch="4,5"`(탭 두 개가 켜짐).
- **장 시작:** 장은 앞쪽 여백이 충분하면 쪽 중간에서 시작해도 된다. 쪽 중간에서 시작하는 장 머리 위에는 추가 여백(8mm)이 자동으로 붙는다. 여백을 얻으려고 장을 다음 쪽으로 넘기지 않는다. 표는 행 중간에서 쪽을 나누지 않는다.
- **검사 기준 (check.py가 판정):**
  - 넘침 0
  - 본문 쪽 채움 85% 이상(마지막 쪽은 50% 이상)
  - 단어 중간 줄바꿈 0, 마지막 줄 한 단어 0
  - 끝 마침표 0, 벌어진 띄어쓰기 0, 두 줄 제목 0
  - '— 끝 —'만 있는 쪽 없음
  - 표지 목차 두 줄 제목 0, 표지 아래 넘침 0, 색띠 탭 글자 넘침 0
  - 이동할 곳 없는 링크 0, PDF 링크가 맞는 쪽으로 감
  - 인쇄(PDF) 쪽 수 = 지면 수(빈 쪽·쪽 밀림 없음)
  - (표시만, 실패 아님) 쪽 중간 장 머리 추가 여백: 쪽별 mm 값
  - 화면과 인쇄 모양 일치: 쪽마다 PDF를 그림으로 그려 화면 지면과 대조하고, 다른 면적이 0.5%를 넘으면 실패(정상 문서는 0.01% 미만, 인쇄에서 본문이 3mm만 밀려도 14% 이상으로 잡힘)
- **인쇄 관련 실패가 날 때:**
  - 화면과 인쇄가 다르면 `@media print` 규칙이나 인쇄 때만 바뀌는 스타일을 손댄 것이다. 템플릿의 인쇄 규칙으로 되돌린다.
  - 쪽 수가 다르면 `.sheet` 밖에 놓인 요소나 높이가 297mm를 넘는 지면을 찾는다.
  - 링크 실패는 장 머리 `.no`의 로마 숫자와 `CONFIG.chapters`, `data-ch`가 맞는지 본다.
  - 템플릿을 그대로 빌드하면(본문이 Ⅰ장 한 쪽뿐) 나머지 장으로 갈 곳이 없어 링크 검사가 실패한다. 정상이다. 모든 장을 쓰면 통과한다.
- **넘칠 때 (이 순서로):**
  1. (자동) 쪽 중간 장 머리의 추가 여백이 8mm→4mm→2mm→0 순으로 먼저 줄어든다. 손댈 것 없음.
  2. 그래도 넘치면 그 쪽 `section`에 `class="sheet tight"`를 줘서 간격을 4mm에서 3mm로 줄인다.
  3. 맨 아래 덩어리(목록 일부·표·절)를 다음 쪽 맨 위로 옮기고 `(계속)` 줄을 단다.
  4. 칸이 좁은 표 하나만 8.5pt로 줄인다.
  - 글자 크기나 자간 규칙을 쪽 단위로 바꾸지 않는다.
- **85% 미만일 때:**
  1. 다음 쪽 첫 덩어리를 끌어올린다.
  2. 그래도 비면, 원고 내용에서 나온 종합 시사점 h2(◦ 5개)나 작은 보조 표를 더한다. 없는 사실은 만들지 않는다.
- **마지막 쪽:** `— 끝 —`(`.end`)는 마지막 쪽 바닥에 붙는다. 그 줄만 남는 쪽이 생기면 결론을 압축하거나 앞쪽 간격을 줄여 앞쪽에 붙인다.

## 왜 이 규칙인가 (SPRi 원본 측정 결과, 2026. 10.)

규칙을 고치고 싶어질 때 먼저 읽는다. SPRi AI 브리프 2026년 10월호(한글로 조판한 뒤 HTML로 저장한 것)의 줄 951개를 재서 얻은 근거다.

- **줄바꿈:** 문단이 다음 줄로 이어지는 381곳 중 단어 중간에서 끊긴 곳이 0곳이다. 어절 단위 줄 나눔과 양쪽 정렬 때문이다.
- **마지막 줄:** 여러 줄 문단 225개 중 마지막 줄에 한 단어만 남은 문단이 0개다. 짧은 마지막 줄도 늘 두 단어 이상이다.
  - 같은 크기·굵기의 본문 글자 모양이 30개 넘게 있고, 자간만 -0.06~+0.01em로 달랐다. 편집자가 문단마다 자간을 손으로 맞춘 흔적이다.
  - 이 스킬은 그 작업을 보정 스크립트로 자동화한다.
- **마침표:** 개조식 문장 421개 중 끝에 마침표가 있는 것은 3개뿐이다. 그래서 마침표를 찍지 않는다.
- **글자:** 본문 10pt 중간 굵기, 2단계 9.5pt 가는 글씨, 줄간격 160%, 기본 자간 -0.02~-0.04em.
- **판형:** 216×303mm(A4에 인쇄소 재단 여유 3mm를 더한 크기)다. 사무실 출력용인 이 스킬은 A4(210×297mm)를 쓴다.
- **채움:** 쪽마다 출처 위치가 208~249mm로 다르다. SPRi도 100% 채우는 게 아니라 85% 이상 수준이다.
- **SPRi와 다르게 가는 것:**
  - 날짜는 공문서식('2026. 10. 14.')을 쓴다.
  - 서체는 Noto Sans KR을 쓴다(KoPub돋움은 웹 폰트로 불러올 수 없다).
  - 색은 녹색 대신 인천대 네이비 계열이다.
- **기존 DOCX 보고서의 문제:** 1·3·4쪽 아래가 비던 문제를 쪽별 채움률 자동 검사로 해결한다.

## 파일 1: template.html

````html
<title>{{문서 이름: 두~네 단어}}</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;700;800;900&display=swap">
<style>
/* 지면형 보고서: A4(210×297mm) 종이 한 장 = .sheet. 바깥쪽 12mm 색띠(장 색인 탭), 본문 폭 168mm, 장 시작마다 장 머리 + 핵심 포인트 박스. 종이는 늘 흰색, 종이 뒤 배경만 테마를 따름 */
:root{
  --navy:#1F4E79; --blue:#2E75B6; --sky:#9DC3E6; --steel:#5B8DC9; --gray:#8A97A8; --mist:#D9E2F3; --pale:#EEF3FA; --gold:#FCB01B;
  --ink:#1B2330; --sub:#4A5566; --rule:#BFCBDA; --zebra:#F2F2F2; --paper:#FFFFFF;
  --desk:#E4E8EE; --desk-fg:#4A5566;
  --f:'Noto Sans KR','Noto Sans CJK KR','Malgun Gothic','맑은 고딕',sans-serif;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}}
:root[data-theme="dark"]{--desk:#161B22;--desk-fg:#AEB8C6;color-scheme:dark}
*{box-sizing:border-box}
body{background:var(--desk);color:var(--ink);font-family:var(--f);margin:0;word-break:keep-all;overflow-wrap:break-word;line-break:strict;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.doc{padding-block:24px 40px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
.stack{zoom:var(--z,1);display:flex;flex-direction:column;align-items:center;gap:10mm}
.sheet{position:relative;width:210mm;height:297mm;letter-spacing:-.02em;background:var(--paper);overflow:hidden;box-shadow:0 1px 2px rgba(20,30,50,.12),0 8px 24px rgba(20,30,50,.10);flex:none}

/* 공통 머리·꼬리·색띠 */
.hd{position:absolute;top:10mm;height:8mm;display:flex;align-items:flex-end;justify-content:space-between;border-bottom:.45mm solid var(--blue);padding-bottom:1.4mm}
.hd img{height:5.2mm;display:block}
.hd span{font-size:8pt;color:var(--sub);letter-spacing:.02em}
.ft{position:absolute;bottom:8mm;left:0;right:0;text-align:center;font-size:8.5pt;color:var(--sub)}
.band{position:absolute;top:0;bottom:0;width:12mm;background:var(--mist);display:flex;flex-direction:column;align-items:stretch}
.band .pub{writing-mode:vertical-rl;margin:30mm auto 0;font-size:8pt;font-weight:700;color:var(--navy);letter-spacing:.12em;white-space:nowrap}
.band .pub b{color:var(--blue);font-weight:500;margin-top:4mm}
.band .tab{height:var(--tabh,27mm);flex:none;display:flex;align-items:center;justify-content:center;writing-mode:vertical-rl;font-size:8pt;font-weight:500;color:var(--navy);border-bottom:.3mm solid #fff;letter-spacing:.06em;white-space:nowrap}
.band .tab:first-child{margin-top:24mm;border-top:.3mm solid #fff}
.band .tab.on{background:var(--navy);color:#fff;font-weight:700}
/* 탭·목차 링크: 누르면 그 장으로 이동. 보이는 변화 0 — 밑줄·색 바뀜·눌림 효과 없음(커서 모양만 손가락) */
a.tab,.toc a{text-decoration:none;color:inherit;-webkit-tap-highlight-color:transparent}
.band a.tab{color:var(--navy)}.band a.tab.on{color:#fff}
a.tab:focus:not(:focus-visible),.toc a:focus:not(:focus-visible){outline:none}
.band .tab.on::before{content:"";display:block;width:1.2mm;height:1.2mm;background:var(--gold);margin-bottom:1.6mm}
.body{position:absolute;top:24mm;bottom:17mm;overflow:hidden;display:flex;flex-direction:column;gap:4mm}
.odd .band{right:0}.odd .hd,.odd .body{left:20mm;right:22mm}
.even .band{left:0}.even .hd,.even .body{left:22mm;right:20mm}

/* 장 머리 */
.ch{display:flex;align-items:stretch;gap:3mm;border-bottom:.7mm solid var(--navy);padding-bottom:2mm}
.ch .no{width:11mm;background:var(--navy);color:#fff;font-size:16pt;font-weight:800;display:flex;align-items:center;justify-content:center}
.ch .tt{display:flex;flex-direction:column;justify-content:center}
.ch h1{margin:0;font-size:17pt;font-weight:800;line-height:1.15;letter-spacing:-.01em}
.ch .en{font-size:7.5pt;font-weight:700;color:var(--blue);letter-spacing:.22em}
.ch + .key{margin-top:.6mm}
/* 쪽 중간에서 시작하는 장 머리: 절 간격 4mm + 추가 8mm = 약 12mm(장 > 절 위계). 그 쪽이 넘치면 보정 스크립트 ⑦이 4→2→0mm로 줄임 — 쪽 나누기를 새로 만들지 않음 */
.body > .ch:not(:first-child){margin-top:var(--chgap,8mm)}
.tight .body{gap:3mm}.tight .sec{gap:1.8mm}

/* 핵심 포인트 박스 */
.key{border:.3mm solid var(--navy)}
.key .kh{background:var(--navy);color:#fff;font-size:8.5pt;font-weight:700;letter-spacing:.14em;padding:1.3mm 3mm;display:flex;justify-content:space-between}
.key .kh i{font-style:normal;color:var(--gold);letter-spacing:.04em;font-weight:500}
.key .kb{background:var(--pale);padding:2.4mm 3.4mm;display:flex;flex-direction:column;gap:1.2mm;font-size:10pt;line-height:1.55;font-weight:500}
.key .kb p{margin:0;padding-left:3.8mm;text-indent:-3.8mm}
.key .kb p::before{content:"◦";color:var(--navy);font-weight:800;display:inline-block;width:3.8mm;text-indent:0}
.key .kb p.plain{padding:0;text-indent:0}.key .kb p.plain::before{content:none}
.key .kb em{font-style:normal;color:var(--navy);font-weight:800}

/* 절 제목·본문 */
h2{margin:0;font-size:11.5pt;font-weight:800;color:var(--ink);display:flex;align-items:center;gap:2mm;padding-bottom:1.2mm;border-bottom:.25mm solid var(--rule)}
h2::before{content:"";width:2.6mm;height:2.6mm;background:var(--navy);flex:none}
h2 small{font-size:8.5pt;font-weight:500;color:var(--sub);margin-left:auto}
.sec{display:flex;flex-direction:column;gap:2.2mm}
.who{font-size:8.8pt;color:var(--sub);margin:-.6mm 0 0}
.who b{color:var(--navy);font-weight:700;margin-right:1.5mm}
ul.l{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:2.1mm;font-size:10pt;line-height:1.6}
ul.l li{padding-left:4mm;position:relative}
ul.l li::before{content:"";position:absolute;left:.6mm;top:.62em;width:1.5mm;height:1.5mm;background:var(--navy)}
ul.l b{color:var(--navy);font-weight:800;margin-right:1.2mm}
ul.l ul.l2{list-style:none;margin:1.1mm 0 0;padding:0;display:flex;flex-direction:column;gap:1.1mm;font-size:9.5pt;font-weight:300}
ul.l ul.l2 li{padding-left:3.6mm}
ul.l ul.l2 li::before{width:1.3mm;height:1.3mm;border-radius:50%;background:var(--navy);top:.66em}
.tag{display:inline-block;font-size:8pt;font-weight:700;color:var(--navy);border:.25mm solid var(--navy);padding:0 1.2mm;margin-right:1.2mm;line-height:1.45}
.cont{margin:0;font-size:8.6pt;font-weight:700;color:var(--blue);letter-spacing:.02em}
ul.l li,.key .kb p,.note,.concl{text-align:justify;text-justify:inter-word}
.note{font-size:8.5pt;color:var(--sub);line-height:1.5;margin:0;padding-left:3.4mm;text-indent:-3.4mm}

/* 표 */
table{width:100%;border-collapse:collapse;font-size:9pt;line-height:1.45;font-variant-numeric:tabular-nums}
thead th{background:var(--mist);color:var(--navy);font-weight:800;padding:1.3mm 1.6mm;border-top:.5mm solid var(--navy);border-bottom:.25mm solid var(--navy);letter-spacing:.04em}
td{padding:1.15mm 1.8mm;border-bottom:.2mm solid var(--rule);vertical-align:middle}
tbody tr:nth-child(even) td{background:var(--zebra)}
td.h{font-weight:700;text-align:center;color:var(--ink);white-space:nowrap}
td.c{text-align:center}
td div+div{margin-top:.5mm}
tr.sum td{background:var(--pale)!important;font-weight:800;color:var(--navy);border-top:.3mm solid var(--navy)}

/* 지표 타일·구성 막대 */
.kpi{display:grid;grid-template-columns:repeat(4,1fr);border-top:.5mm solid var(--navy);border-left:.2mm solid var(--rule)}
.kpi div{border-right:.2mm solid var(--rule);border-bottom:.2mm solid var(--rule);padding:2.2mm 2.6mm 2mm;display:flex;flex-direction:column;gap:.5mm}
.kpi strong{font-size:19pt;font-weight:900;color:var(--navy);line-height:1;font-variant-numeric:tabular-nums}
.kpi strong small{font-size:9pt;font-weight:700;margin-left:.6mm}
.kpi span{font-size:8.6pt;font-weight:700}
.kpi em{font-style:normal;font-size:7.6pt;color:var(--sub);line-height:1.4}
.bar{display:flex;height:9mm;font-size:8.2pt;font-weight:700;color:#fff}
.bar div{display:flex;align-items:center;justify-content:center;white-space:nowrap;border-right:.4mm solid #fff}
.legend{display:flex;justify-content:space-between;font-size:8pt;color:var(--sub);margin-top:1.2mm}
.end{text-align:center;font-size:10pt;font-weight:700;color:var(--navy);letter-spacing:.3em;margin-top:auto}
.concl{font-size:10pt;line-height:1.7;margin:0;text-align:justify}
.concl b{color:var(--navy);font-weight:800}

/* 표지 */
.cover .top{position:absolute;inset:0 0 auto 0;height:204mm;background:var(--navy);color:#fff;overflow:hidden}
.cover .cx{position:absolute;width:30mm;display:block}
.cover .brand{position:absolute;left:20mm;top:18mm;display:flex;align-items:center;gap:3.5mm}
.cover .brand img{height:11mm;display:block}
.cover .brand span{font-size:9.5pt;font-weight:700;letter-spacing:.06em;border-left:.3mm solid rgba(255,255,255,.5);padding-left:3.5mm;line-height:1.4}
.cover .issue{position:absolute;right:20mm;top:20mm;text-align:right;font-size:8.5pt;letter-spacing:.18em;color:var(--sky);font-weight:700}
.cover .issue b{display:block;color:#fff;font-size:15pt;letter-spacing:.02em;margin-top:1mm}
.cover .ttl{position:absolute;left:20mm;bottom:50mm;right:60mm}
.cover .pill{display:inline-block;background:var(--gold);color:var(--navy);font-size:9pt;font-weight:800;padding:1mm 3mm;letter-spacing:.08em}
.cover h1{margin:5mm 0 0;font-size:30pt;font-weight:900;line-height:1.22;letter-spacing:-.02em}
.cover .subt{margin:5mm 0 0;font-size:11.5pt;color:var(--sky);font-weight:500}
.cover .low{position:absolute;left:20mm;right:20mm;top:214mm;bottom:14mm;display:flex;flex-direction:column;gap:5mm}
.facts{display:grid;grid-template-columns:repeat(4,1fr);border-top:.5mm solid var(--navy)}
.facts div{padding:2.4mm 3mm 0 0;display:flex;flex-direction:column;gap:1mm}
.facts dt{font-size:7.6pt;font-weight:800;color:var(--blue);letter-spacing:.16em}
.facts dd{margin:0;font-size:9pt;font-weight:700;line-height:1.45}
.toc{display:grid;grid-template-columns:repeat(3,1fr);gap:0 6mm}
.toc.two{grid-template-columns:repeat(2,1fr)}
.toc a{display:flex;align-items:baseline;gap:2mm;padding:1.6mm 0;border-bottom:.2mm solid var(--rule);font-size:9.2pt}
.toc i{font-style:normal;font-weight:900;color:var(--navy);width:6mm}
.toc span{font-weight:700}
.toc b{margin-left:auto;font-weight:500;color:var(--sub);font-variant-numeric:tabular-nums}
.toch{font-size:7.6pt;font-weight:800;color:var(--blue);letter-spacing:.16em;margin-bottom:-3mm}
.cover .foot{margin-top:auto;display:flex;justify-content:space-between;align-items:flex-end;font-size:8.6pt;color:var(--sub);border-top:.25mm solid var(--rule);padding-top:2.4mm}
.cover .foot b{color:var(--navy);font-size:10pt}

@media print{
  @page{size:A4;margin:0}
  body{background:#fff}
  .doc{padding:0}
  .stack{zoom:1!important;gap:0}
  .sheet{box-shadow:none;break-after:page}
}
</style>

<div class="doc"><div class="stack">

<!-- ===== 표지 (1쪽) ===== -->
<section class="sheet cover" data-page="1">
  <div class="top">
    <img class="cx tr" src="{{CHEV_TR}}" alt=""><img class="cx bl" src="{{CHEV_BL}}" alt="">
    <div class="brand"><img src="{{LOGO_WHITE}}" alt="INU"><span>인천대학교<br>산학협력단</span></div>
    <div class="issue">INU 산학협력 리포트<b>2026. 10.</b></div>
    <div class="ttl">
      <span class="pill">결과 보고</span>
      <h1>2026 제○차<br>○○○○ 간담회<br>개최 결과 보고서</h1>
      <p class="subt">부제 한 줄</p>
    </div>
  </div>
  <div class="low">
    <dl class="facts" style="margin:0">
      <div><dt>일시</dt><dd>2026. 10. 14.(수)<br>10:30~14:00</dd></div>
      <div><dt>장소</dt><dd>장소 1행<br>장소 2행</dd></div>
      <div><dt>주관</dt><dd>산학협력단</dd></div>
      <div><dt>참석</dt><dd>총 00명</dd></div>
    </dl>
    <div class="toch">CONTENTS</div>
    <div class="toc" data-auto></div>
    <div class="foot"><span>발행일 2026년 10월 14일</span><b>인천대학교 산학협력단 산학협력팀</b></div>
  </div>
</section>

<!-- ===== 본문 쪽: data-page=쪽번호, data-ch=이 쪽에 걸친 장 번호(쉼표로 여러 개) ===== -->
<section class="sheet" data-page="2" data-ch="1">
 <div class="body">
  <div class="ch"><div class="no">Ⅰ</div><div class="tt"><span class="en">OVERVIEW</span><h1>보고 개요</h1></div></div>
  <div class="key"><div class="kh">핵심 포인트<i>Ⅰ. 보고 개요</i></div><div class="kb">
    <p>장 요약 문장 1 — 강조할 말은 <em>em</em>으로</p>
    <p>장 요약 문장 2</p>
  </div></div>
  <div class="sec"><h2>1. 절 제목</h2>
   <p class="who"><b>발표</b>소속 이름 직위</p>
   <ul class="l">
    <li><b>머리말</b>1단계 문장, 개조식 명사형으로 끝내고 마침표 없음
      <ul class="l2"><li>2단계 보충 설명(있을 때만)</li></ul></li>
    <li><span class="tag">태그</span>분류 태그가 붙는 항목</li>
   </ul>
   <table><colgroup><col style="width:24mm"><col></colgroup>
    <thead><tr><th>구 분</th><th>내 용</th></tr></thead>
    <tbody>
     <tr><td class="h">항목</td><td><div>한 칸 안 여러 줄은</div><div>div로 한 줄씩</div></td></tr>
     <tr class="sum"><td class="h">합 계</td><td>00명</td></tr>
    </tbody></table>
   <p class="note">※ 주석 문장</p></div>
  <div class="sec"><h2>2. 숫자 지표</h2>
   <div class="kpi">
    <div><strong>46<small>명</small></strong><span>지표 이름</span><em>보충 설명</em></div>
    <div><strong>19<small>개사</small></strong><span>지표 이름</span><em>보충 설명</em></div>
    <div><strong>9<small>명</small></strong><span>지표 이름</span><em>보충 설명</em></div>
    <div><strong>7<small>개 조</small></strong><span>지표 이름</span><em>보충 설명</em></div>
   </div>
   <div class="bar">
    <div style="width:60%;background:var(--navy)">구성 A 60</div>
    <div style="width:25%;background:var(--blue)">구성 B 25</div>
    <div style="width:15%;background:var(--gold);color:var(--navy);border-right:0">C 15</div>
   </div></div>
 </div>
</section>

<!-- 다음 쪽으로 이어지는 절은 맨 위에 <p class="cont">2. 절 제목 (계속)</p> -->
<!-- 마지막 쪽 .body 끝에는 <div class="end">— 끝 —</div> (margin-top:auto로 바닥에 붙음) -->

</div></div>

<script>
/* 문서 설정: 스킬이 문서마다 채움 */
var CONFIG={
  mode:'single',                 /* 'single' = 모든 쪽 오른쪽 장 색인 탭(단면 결재용, 기본) / 'book' = 홀수쪽 탭·짝수쪽 발행물명(양면 책자용) */
  title:'2026 제○차 ○○○○ 간담회 결과 보고서',
  pub:'INU 산학협력 리포트', issue:'2026. 10.',
  team:'인천대학교 산학협력단 산학협력팀',
  chapters:[ ['Ⅰ','개요','보고 개요'], ['Ⅱ','요약','핵심 요약'], ['Ⅲ','참석자','참석자 구성'],
             ['Ⅳ','프로그램','주요 프로그램 내용'], ['Ⅴ','네트워킹','네트워킹 및 현장 논의'], ['Ⅵ','제언','시사점 및 향후 추진 제언'] ]
};
(function(){
  var C=CONFIG, first={}, n=C.chapters.length;
  var sheets=[].slice.call(document.querySelectorAll('.sheet[data-ch]'));
  sheets.forEach(function(s){ s.dataset.ch.split(',').map(Number).forEach(function(c){ if(!first[c]) first[c]=+s.dataset.page; }); });
  /* 장 이동 표지(id="ch-N"): 장 시작 쪽의 장 머리(.ch)에, 장 머리가 없으면 그 쪽 맨 위에 보이지 않는 1px 표지를 둠(크기 0이면 크롬 PDF가 엉뚱한 쪽으로 보냄) */
  C.chapters.forEach(function(c,i){
    var s=document.querySelector('.sheet[data-page="'+first[i+1]+'"]'); if(!s)return;
    var hd=[].filter.call(s.querySelectorAll('.ch'),function(h){var no=h.querySelector('.no');return no&&no.textContent.trim()===c[0];})[0];
    if(hd){hd.id='ch-'+(i+1);return;}
    var m=document.createElement('i'); m.id='ch-'+(i+1); m.style.cssText='position:absolute;top:0;left:0;width:1px;height:1px'; s.prepend(m);
  });
  /* 탭 높이: 장 수에 맞춰 자동 분할 — 위 24mm·아래 17mm를 뺀 256mm를 장 수로 나누되 최대 27mm */
  var tabh=Math.min(27,256/n).toFixed(2)+'mm';
  sheets.forEach(function(s){
    var p=+s.dataset.page, chs=s.dataset.ch.split(',').map(Number), tabs=C.mode==='single'||p%2===1;
    s.classList.add(tabs?'odd':'even');
    var band=document.createElement('div'); band.className='band'; band.style.setProperty('--tabh',tabh);
    band.innerHTML = tabs ? C.chapters.map(function(c,i){return '<a class="tab'+(chs.indexOf(i+1)>=0?' on':'')+'" href="#ch-'+(i+1)+'">'+c[0]+' '+c[1]+'</a>';}).join('')
                          : '<div class="pub">'+C.pub+'<b>'+C.issue+'</b></div>';
    var hd=document.createElement('div'); hd.className='hd';
    hd.innerHTML='<img src="{{LOGO_NAVY}}" alt="INU"><span>'+((C.mode==='single'||tabs)?C.team:C.title)+'</span>';
    var ft=document.createElement('div'); ft.className='ft'; ft.textContent='- '+p+' -';
    s.prepend(band); s.appendChild(hd); s.appendChild(ft);
  });
  /* 표지 목차: 3칸 기본. 제목이 두 줄로 꺾이면 조판 보정 단계에서 2칸(.two)으로 바꿈 */
  var toc=document.querySelector('.toc[data-auto]');
  if(toc) toc.innerHTML=C.chapters.map(function(c,i){return '<a href="#ch-'+(i+1)+'"><i>'+c[0]+'</i><span>'+c[2]+'</span><b>'+(first[i+1]||'')+'</b></a>';}).join('');
  /* 표지 꺾쇠(사용자 결정 E안): 위 꺾쇠는 제목 오른쪽 위, 아래 꺾쇠는 부제 아래 왼쪽 — 두 꺾쇠가 제목을 감쌈. 제목 길이에 맞춰 자동 배치 */
  function placeCover(){
    var top=document.querySelector('.cover .top'); if(!top)return;
    var h=top.querySelector('h1'), sub=top.querySelector('.subt'), tr=top.querySelector('.cx.tr'), bl=top.querySelector('.cx.bl'); if(!h||!tr||!bl)return;
    var T=top.getBoundingClientRect(), z=(T.width/top.offsetWidth)||1, mm=96/25.4, r=document.createRange(); r.selectNodeContents(h);
    var R=[].slice.call(r.getClientRects()), right=Math.max.apply(null,R.map(function(x){return x.right;})), tp=Math.min.apply(null,R.map(function(x){return x.top;}));
    var S=(sub||h).getBoundingClientRect();
    tr.style.left=((right-T.left)/z+13*mm-30*mm)+'px'; tr.style.top=((tp-T.top)/z-5*mm)+'px';
    bl.style.left=(6*mm)+'px'; bl.style.top=((S.bottom-T.top)/z+12*mm-30*mm)+'px';
  }
  placeCover(); if(document.fonts&&document.fonts.ready)document.fonts.ready.then(placeCover);
  function fitz(){ var w=document.documentElement.clientWidth-32; document.documentElement.style.setProperty('--z',Math.min(1,w/794).toFixed(4)); }
  fitz(); addEventListener('resize',fitz);
  addEventListener('beforeprint',function(){document.documentElement.style.setProperty('--z','1');});
  addEventListener('afterprint',fitz);
})();
</script>

<script>
/* 조판 보정(수정 금지): ① 마지막 줄 한 단어 금지 — 자간 최대 -0.03em 추가로 끌어올리고, 안 되면 마지막 두 단어를 붙여 함께 내림 ② 벌어진 띄어쓰기 고르기 ③ 제목 한 줄 유지 … ⑦ 쪽 중간 장 머리 추가 여백 자동 축소. 끝나면 html[data-fit=done] */
(function(){
  function chars(el){var a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n;while(n=w.nextNode())for(var i=0;i<n.data.length;i++)a.push([n,i]);return a;}
  var rg=document.createRange();
  function top(c){rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);var r=rg.getClientRects();return r.length?r[r.length-1].top:null;}
  function info(el){var A=chars(el),txt=A.map(function(c){return c[0].data[c[1]];}).join('');var e=txt.replace(/\s+$/,'').length-1;if(e<1)return{lines:1,widow:false};
    var lt=top(A[e]),s=e;while(s>0){var ch=txt[s-1];if(/\s/.test(ch)){s--;continue;}var t=top(A[s-1]);if(t===null||Math.abs(t-lt)>2)break;s--;}
    var first=top(A[0]),lines=1,prev=first;for(var i=1;i<=e;i++){if(/\s/.test(txt[i]))continue;var t=top(A[i]);if(t!==null&&t-prev>2){lines++;prev=t;}}
    return{lines:lines,widow:lines>1&&!/\s/.test(txt.slice(s,e+1).trim()),A:A,txt:txt,s:s};}
  function em(el){return parseFloat(getComputedStyle(el).letterSpacing)/parseFloat(getComputedStyle(el).fontSize)||0;}
  function glue(el,I){var k=I.txt.slice(0,I.s).replace(/\s+$/,'').length;var c=I.A[k];if(c&&c[0].data[c[1]]===' '){c[0].data=c[0].data.slice(0,c[1])+String.fromCharCode(160)+c[0].data.slice(c[1]+1);}}
  function run(){
    document.querySelectorAll('.sheet:not(.cover) ul.l li, .sheet .key .kb p, .sheet .note, .sheet .who, .sheet td, .sheet .kpi em').forEach(function(el){
      if(el.querySelector('br,div,ul'))return;
      var I=info(el);if(!I.widow)return;var base=em(el),L=I.lines;
      for(var d=.005;d<=.0301;d+=.005){el.style.letterSpacing=(base-d).toFixed(3)+'em';var J=info(el);if(!J.widow&&J.lines<=L)return;}
      el.style.letterSpacing='';glue(el,info(el));});
    document.querySelectorAll('.sheet td > div').forEach(function(el){var I=info(el);if(!I.widow)return;var base=em(el),L=I.lines;
      for(var d=.005;d<=.0301;d+=.005){el.style.letterSpacing=(base-d).toFixed(3)+'em';var J=info(el);if(!J.widow&&J.lines<=L)return;}
      el.style.letterSpacing='';glue(el,info(el));});
    /* ③ 양쪽 정렬로 띄어쓰기가 과하게 벌어진 줄(0.55em 초과)은 자간을 -0.045~+0.03em 범위에서 골라 간격을 고르게 */
    function gap(el){var fs=parseFloat(getComputedStyle(el).fontSize),w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n,sp=[];
      while(n=w.nextNode())for(var i=0;i<n.data.length;i++){if(n.data[i]!==' ')continue;rg.setStart(n,i);rg.setEnd(n,i+1);var rc=rg.getClientRects()[0];if(rc&&rc.width>0)sp.push([rc.width/fs,rc.top]);}
      if(!sp.length)return 0;var lt=Math.max.apply(null,sp.map(function(x){return x[1];})),m=0;sp.forEach(function(x){if(Math.abs(x[1]-lt)>2&&x[0]>m)m=x[0];});return m;}
    document.querySelectorAll('.sheet:not(.cover) ul.l li, .sheet .key .kb p, .sheet .note, .sheet .concl').forEach(function(el){
      if(el.querySelector('ul')||gap(el)<=.55)return;var cur=el.style.letterSpacing,base=em(el),L=info(el).lines,best=[gap(el),cur];
      for(var d=-.045;d<=.0301;d+=.005){el.style.letterSpacing=(base+d).toFixed(3)+'em';var I=info(el);if(I.widow||I.lines>L)continue;var g=gap(el);if(g<best[0])best=[g,el.style.letterSpacing];}
      el.style.letterSpacing=best[1];});
    document.querySelectorAll('.sheet:not(.cover) h2, .sheet .ch h1').forEach(function(h){var base=em(h);for(var d=0;d<=.0401&&info(h).lines>1;d+=.005)h.style.letterSpacing=(base-d).toFixed(3)+'em';});
    /* ④ 표지 목차 한 줄 유지: 3칸에서 두 줄로 꺾이는 제목이 있으면 2칸으로, 그래도 넘치면 자간을 최대 -0.04em 좁힘 */
    var toc=document.querySelector('.cover .toc');
    if(toc){var spans=[].slice.call(toc.querySelectorAll('span')),wr=function(){return spans.filter(function(x){return info(x).lines>1;});};
      if(wr().length)toc.classList.add('two');
      wr().forEach(function(x){var b=em(x);for(var d=.005;d<=.0401&&info(x).lines>1;d+=.005)x.style.letterSpacing=(b-d).toFixed(3)+'em';});}
    /* ⑤ 표지 아래(사실 4칸·목차·발행일) 넘침 방지: 목차가 4줄 이상이면 간격을 단계적으로 좁힘 */
    var low=document.querySelector('.cover .low');
    if(low){var ov=function(){var lb=low.getBoundingClientRect().bottom;return [].some.call(low.children,function(c){return c.getBoundingClientRect().bottom>lb+1;});};
      var steps=[function(){low.style.gap='3.5mm';},function(){if(toc)[].forEach.call(toc.querySelectorAll('a'),function(a){a.style.paddingTop=a.style.paddingBottom='1.1mm';});},function(){low.style.gap='2.5mm';}];
      for(var k=0;k<steps.length&&ov();k++)steps[k]();}
    /* ⑥ 색띠 탭 글자 맞춤: 탭 높이보다 글자가 길면 자간→글자 크기(최소 7pt) 순으로 줄임 */
    document.querySelectorAll('.band .tab').forEach(function(t){
      var over=function(){return t.scrollHeight>t.clientHeight+1;};
      for(var d=.05;d>=-.02&&over();d-=.01)t.style.letterSpacing=d.toFixed(2)+'em';
      for(var f=7.75;f>=7&&over();f-=.25)t.style.fontSize=f+'pt';});
    /* ⑦ 쪽 중간 장 머리 추가 여백: 그 쪽이 넘치면 4mm→2mm→0 순으로 줄여 장이 다음 쪽으로 밀리지 않게 함 */
    document.querySelectorAll('.sheet:not(.cover) .body').forEach(function(b){
      if(!b.querySelector(':scope>.ch:not(:first-child)'))return;
      var ov=function(){return b.scrollHeight>b.clientHeight+1;},steps=['4mm','2mm','0mm'];
      for(var k=0;k<steps.length&&ov();k++)b.style.setProperty('--chgap',steps[k]);});
    document.documentElement.dataset.fit='done';}
  (document.fonts&&document.fonts.ready?document.fonts.ready:Promise.resolve()).then(function(){requestAnimationFrame(run);});
})();
</script>
````

## 파일 2: build.py

````python
"""지면형 보고서 빌드: python3 build.py 원고.html INU_로고.jpg 출력폴더 파일이름
- 로고(흰 배경 JPG/PNG)에서 네이비·흰색 로고와 골드 꺾쇠 두 개(표지용)를 만들어 data URI로 넣음
- 본문 글자에 줄바꿈 보조 문자 삽입: 글자+( / )+글자는 붙이고(WJ), 가운뎃점은 앞에 붙이고 뒤에서만 줄바꿈 허용(ZWSP)
- 출력: <이름>.html(완성 문서), <이름>_artifact.html(아티팩트 게시용 조각)"""
import re, sys, os, io, base64
import numpy as np
from PIL import Image
src_path, logo_path, out_dir, name = sys.argv[1:5]
os.makedirs(out_dir, exist_ok=True)

def logo_variants(path):
    im = np.asarray(Image.open(path).convert('RGB')).astype(float)
    r, g, b = im[..., 0], im[..., 1], im[..., 2]
    warm = (r > g) & (r > b + 30)                       # 골드 심볼
    alpha = np.clip((255 - im.min(axis=2)) / 228, 0, 1)  # 흰 배경 → 투명
    GOLD = im[warm & (alpha > .9)].mean(0) if (warm & (alpha > .9)).any() else np.array([252, 176, 27])
    def png(img, w):
        img = img.resize((w, max(1, int(img.height * w / img.width))), Image.LANCZOS)
        buf = io.BytesIO(); img.save(buf, 'PNG', optimize=True)
        return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()
    def make(letter, sym_only=False):
        out = np.zeros(im.shape[:2] + (4,), np.uint8)
        out[..., :3] = np.where(warm[..., None], GOLD, letter)
        out[..., 3] = (alpha * 255).astype(np.uint8)
        if sym_only: out[~warm, 3] = 0
        img = Image.fromarray(out, 'RGBA'); return img.crop(img.getbbox())
    def chevron(sym, part):                              # 골드 심볼을 대각선으로 나눠 꺾쇠 한 개씩
        a = np.asarray(sym).copy(); H, W = a.shape[:2]
        yy, xx = np.mgrid[0:H, 0:W]; upper = xx / W > yy / H
        a[(~upper) if part == 'tr' else upper, 3] = 0
        p = Image.fromarray(a, 'RGBA'); return p.crop(p.getbbox())
    sym = make(np.array([0, 0, 0]), sym_only=True)
    return {'LOGO_NAVY': png(make(np.array([0x1F, 0x4E, 0x79])), 270), 'LOGO_WHITE': png(make(np.array([255, 255, 255])), 270),
            'CHEV_TR': png(chevron(sym, 'tr'), 220), 'CHEV_BL': png(chevron(sym, 'bl'), 220)}

src = open(src_path, encoding='utf-8').read()
for k, v in logo_variants(logo_path).items():
    src = src.replace('{{' + k + '}}', v)

WJ, ZW = chr(0x2060), chr(0x200B)   # 단어 잇기(WJ), 줄바꿈 허용(ZWSP) — 보이지 않는 문자라 chr()로 씀
def tx(t):
    t = re.sub(r'([가-힣A-Za-z0-9])\(', lambda m: m.group(1) + WJ + '(', t)
    t = re.sub(r'\)([가-힣A-Za-z0-9])', lambda m: ')' + WJ + m.group(1), t)
    t = re.sub(r'([가-힣A-Za-z0-9])·([가-힣A-Za-z0-9])', lambda m: m.group(1) + WJ + '·' + ZW + m.group(2), t)
    return t
a = src.index('</style>'); b = src.index('<script>')
src = src[:a] + re.sub(r'>([^<]+)<', lambda m: '>' + tx(m.group(1)) + '<', src[a:b]) + src[b:]

open(os.path.join(out_dir, name + '_artifact.html'), 'w', encoding='utf-8').write(src)
m = re.search(r'</style>', src)
full = ('<!DOCTYPE html>\n<html lang="ko">\n<head>\n<meta charset="utf-8">\n'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        + src[:m.end()] + '\n</head>\n<body>' + src[m.end():] + '\n</body>\n</html>\n')
open(os.path.join(out_dir, name + '.html'), 'w', encoding='utf-8').write(full)
print('OK', os.path.join(out_dir, name + '.html'))
````

## 파일 3: check.py

````python
"""지면형 보고서 검사 + PDF: python3 check.py 완성문서.html 출력폴더
통과 기준: 넘침 0 · 본문 쪽 채움 85% 이상(마지막 쪽 50% 이상) · 단어 중간 줄바꿈 0 · 마지막 줄 한 단어 0
         · 개조식 끝 마침표 0 · 벌어진 띄어쓰기(0.6em 초과) 0 · 두 줄 제목 0 · '— 끝 —'만 있는 쪽 없음
         · 표지 목차 제목 한 줄 · 표지 아래 넘침 0 · 색띠 탭 글자 넘침 0 · 탭·목차 링크 대상 모두 있음
         · 인쇄(PDF) 쪽 수 = 지면 수 · PDF 안 링크 살아 있음 · 화면과 인쇄(PDF) 모양 일치
출력: 쪽별 PNG(s1.png…), 한눈에 보기(contact.png), PDF(<이름>.pdf), 결과 표"""
import sys, os, json
from playwright.sync_api import sync_playwright
from PIL import Image
html, out = os.path.abspath(sys.argv[1]), sys.argv[2]
os.makedirs(out, exist_ok=True)
JS = r"""() => {
 const rg=document.createRange(), R={pages:[],midword:[],widow:[],period:[],gaps:[],titles:[],toc:[],cover:[],tabs:[],links:[],nlinks:0,dest:{}};
 const chars=el=>{const a=[],w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode())for(let i=0;i<n.data.length;i++)a.push([n,i]);return a;};
 const top=c=>{rg.setStart(c[0],c[1]);rg.setEnd(c[0],c[1]+1);const r=rg.getClientRects();return r.length?r[r.length-1].top:null;};
 document.querySelectorAll('.sheet').forEach(s=>{const b=s.querySelector('.body');if(!b){R.pages.push({p:+s.dataset.page,cover:1});return;}
   const br=b.getBoundingClientRect();let last=0,endOnly=true;b.querySelectorAll(':scope>*').forEach(c=>{if(c.classList.contains('end'))return;endOnly=false;last=Math.max(last,c.getBoundingClientRect().bottom);});
   R.pages.push({p:+s.dataset.page,overflow:b.scrollHeight-b.clientHeight,fill:Math.round((last-br.top)/br.height*100),endOnly:endOnly&&!!b.querySelector('.end')});});
 const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let n;
 while(n=w.nextNode()){if(n.data.trim().length<2||n.parentElement.closest('.band,.cover'))continue;let pt=null;
   for(let i=0;i<n.length;i++){const t=top([n,i]);if(t===null)continue;if(pt!==null&&t>pt+3){const a=n.data[i-1],c=n.data[i];if(/[가-힣A-Za-z0-9]/.test(a)&&/[가-힣A-Za-z0-9]/.test(c))R.midword.push(n.data.slice(Math.max(0,i-8),i)+'|'+n.data.slice(i,i+6));}pt=t;}}
 document.querySelectorAll('.sheet:not(.cover) :is(ul.l li, .key .kb p, .note, .who, .concl, td, td>div, .kpi em)').forEach(el=>{
   if(el.querySelector('br,div,ul'))return;const A=chars(el),txt=A.map(c=>c[0].data[c[1]]).join(''),e=txt.replace(/\s+$/,'').length-1;if(e<1)return;
   const lt=top(A[e]);let s=e;while(s>0){if(/\s/.test(txt[s-1])){s--;continue;}const t=top(A[s-1]);if(t===null||Math.abs(t-lt)>2)break;s--;}
   if(s>0&&Math.abs(top(A[0])-lt)>2&&!/\s/.test(txt.slice(s,e+1).trim()))R.widow.push(txt.slice(s,e+1));});
 document.querySelectorAll('.sheet:not(.cover) :is(ul.l li, .key .kb p, .note, .concl, td>div, td:not(:has(div)))').forEach(el=>{let t='';el.childNodes.forEach(c=>{if(c.nodeName!=='UL')t+=c.textContent;});if(/[가-힣)]\.\s*$/.test(t))R.period.push(t.trim().slice(-20));});
 document.querySelectorAll('.sheet:not(.cover) :is(ul.l li, .key .kb p, .note, .concl)').forEach(el=>{if(el.querySelector('ul'))return;const fs=parseFloat(getComputedStyle(el).fontSize),sp=[];const w2=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let m;
   while(m=w2.nextNode())for(let i=0;i<m.length;i++){if(m.data[i]!==' ')continue;rg.setStart(m,i);rg.setEnd(m,i+1);const rc=rg.getClientRects()[0];if(rc&&rc.width>0)sp.push([rc.width/fs,rc.top,m.data.slice(Math.max(0,i-10),i+10)]);}
   if(!sp.length)return;const lt=Math.max(...sp.map(x=>x[1]));sp.forEach(x=>{if(Math.abs(x[1]-lt)>2&&x[0]>.6)R.gaps.push(x[0].toFixed(2)+' '+x[2]);});});
 document.querySelectorAll('.sheet:not(.cover) :is(h2, .ch h1)').forEach(h=>{const A=chars(h).filter(c=>!/\s/.test(c[0].data[c[1]]));if(A.length&&Math.abs(top(A[0])-top(A[A.length-1]))>3)R.titles.push(h.textContent.slice(0,40));});
 const tw=el=>{const A=chars(el).filter(c=>!/\s/.test(c[0].data[c[1]]));return A.length&&Math.abs(top(A[0])-top(A[A.length-1]))>3;};
 document.querySelectorAll('.cover .toc span').forEach(x=>{if(tw(x))R.toc.push(x.textContent);});
 const low=document.querySelector('.cover .low');if(low){const lb=low.getBoundingClientRect().bottom;low.querySelectorAll(':scope>*').forEach(c=>{const d=c.getBoundingClientRect().bottom-lb;if(d>1)R.cover.push((c.className||c.tagName)+' '+Math.round(d)+'px');});}
 document.querySelectorAll('.band .tab').forEach(t=>{if(t.scrollHeight>t.clientHeight+1)R.tabs.push(t.closest('.sheet').dataset.page+'쪽 '+t.textContent);});
 R.chgap=[];document.querySelectorAll('.sheet:not(.cover) .body>.ch:not(:first-child)').forEach(h=>{R.chgap.push(h.closest('.sheet').dataset.page+'쪽 '+(parseFloat(getComputedStyle(h).marginTop)*25.4/96).toFixed(0)+'mm');});
 document.querySelectorAll('a[href^="#"]').forEach(a=>{R.nlinks++;const id=a.getAttribute('href').slice(1),t=document.getElementById(id);if(!t)R.links.push(a.textContent.trim()+' → '+a.getAttribute('href'));else R.dest[id]=+t.closest('.sheet').dataset.page;});
 return R;}"""
with sync_playwright() as p:
    try: br = p.chromium.launch()
    except Exception:
        br = p.chromium.launch(executable_path=next((x for x in ['/opt/pw-browsers/chromium', '/usr/bin/chromium', '/usr/bin/chromium-browser'] if os.path.exists(x)), None))
    pg = br.new_page(viewport={'width': 1000, 'height': 1200}, device_scale_factor=1.5)
    pg.goto('file://' + html); pg.wait_for_function("document.documentElement.dataset.fit==='done'", timeout=30000); pg.wait_for_timeout(200)
    R = pg.evaluate(JS)
    sheets = pg.query_selector_all('.sheet')
    for i, s in enumerate(sheets, 1): s.screenshot(path=f'{out}/s{i}.png')
    pdf = os.path.join(out, os.path.splitext(os.path.basename(html))[0] + '.pdf')
    pg.pdf(path=pdf, format='A4', print_background=True, prefer_css_page_size=True)
    br.close()
# 인쇄 확인: PDF 쪽 수·링크·화면과 모양 일치(PDF를 그림으로 그려 화면 지면과 비교)
import re
raw = open(pdf, 'rb').read()
pdf_links = len(re.findall(rb'/Subtype\s*/Link', raw))
pdf_pages, diffs = None, []
try:
    import pypdfium2 as pdfium
    from PIL import ImageChops, ImageFilter
    doc = pdfium.PdfDocument(pdf); pdf_pages = len(doc)
    for i in range(min(pdf_pages, len(sheets))):
        a = Image.open(f'{out}/s{i+1}.png').convert('L')
        b = doc[i].render(scale=a.width / doc[i].get_width()).to_pil().convert('L').resize(a.size)
        a2, b2 = [x.resize((x.width // 3, x.height // 3)).filter(ImageFilter.GaussianBlur(1)) for x in (a, b)]
        d = ImageChops.difference(a2, b2).point(lambda v: 255 if v > 48 else 0)
        diffs.append(round(d.histogram()[255] / (d.width * d.height) * 100, 3))
except ImportError:
    pdf_pages = len(re.findall(rb'/Type\s*/Page[^s]', raw)); print('(화면·인쇄 모양 비교 생략: pip install pypdfium2)')
ims = [Image.open(f'{out}/s{i}.png') for i in range(1, len(sheets) + 1)]
w, h = ims[0].size; sc = 0.32; ims = [im.resize((int(w * sc), int(h * sc))) for im in ims]; w, h = ims[0].size
cols = min(4, len(ims)); rows = -(-len(ims) // cols)
sheet = Image.new('RGB', (cols * w + (cols - 1) * 10, rows * h + (rows - 1) * 10), '#777')
for i, im in enumerate(ims): sheet.paste(im, ((i % cols) * (w + 10), (i // cols) * (h + 10)))
sheet.save(f'{out}/contact.png')
body = [x for x in R['pages'] if not x.get('cover')]
fails = []
for i, x in enumerate(body):
    lim = 50 if i == len(body) - 1 else 85
    if x['overflow'] > 0: fails.append(f"{x['p']}쪽 넘침 {x['overflow']}px")
    if x['fill'] < lim: fails.append(f"{x['p']}쪽 채움 {x['fill']}% (<{lim}%)")
    if x['endOnly']: fails.append(f"{x['p']}쪽에 '— 끝 —'만 있음")
try:
    from pypdf import PdfReader
    rd = PdfReader(pdf); nd = {k.lstrip('/'): rd.get_destination_page_number(v) + 1 for k, v in rd.named_destinations.items()}
    for k, v in R['dest'].items():
        if nd.get(k) != v: fails.append(f"PDF 링크 {k}가 {nd.get(k)}쪽으로 감 (맞는 쪽 {v})")
except ImportError: print('(PDF 링크 도착 쪽 확인 생략: pip install pypdf)')
if pdf_pages != len(sheets): fails.append(f"인쇄 쪽 수 {pdf_pages} ≠ 지면 {len(sheets)}쪽 (빈 쪽 또는 쪽 밀림)")
if R['nlinks'] and pdf_links < R['nlinks']: fails.append(f"PDF 링크 {pdf_links}개 < 문서 링크 {R['nlinks']}개")
for i, v in enumerate(diffs, 1):
    if v > 0.5: fails.append(f"{i}쪽 화면과 인쇄 모양 다름 ({v}%)")
for k, label in [('toc', '표지 목차 두 줄 제목'), ('cover', '표지 아래 넘침'), ('tabs', '색띠 탭 글자 넘침(탭 이름을 줄일 것)'), ('links', '이동할 곳 없는 링크'), ('midword', '단어 중간 줄바꿈'), ('widow', '마지막 줄 한 단어'), ('period', '끝 마침표'), ('gaps', '벌어진 띄어쓰기'), ('titles', '두 줄 제목')]:
    if R[k]: fails.append(f"{label} {len(R[k])}곳: {R[k][:5]}")
print('쪽별 채움:', ' '.join(f"{x['p']}쪽 {x['fill']}%" + (f"(넘침 {x['overflow']})" if x['overflow'] else '') for x in body))
print('쪽 중간 장 머리 추가 여백:', ', '.join(R['chgap']) or '해당 없음', '(8mm 미만은 그 쪽이 꽉 차서 자동으로 줄어든 것)')
print('PDF:', pdf, '| 지면', len(sheets), '쪽 · 인쇄', pdf_pages, '쪽 · 링크', pdf_links, '개 · 화면/인쇄 차이(%)', diffs)
print('결과: 통과' if not fails else '결과: 고칠 곳\n - ' + '\n - '.join(fails))
````